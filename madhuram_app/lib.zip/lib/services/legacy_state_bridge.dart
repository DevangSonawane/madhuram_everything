import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:redux/redux.dart';

import '../providers/legacy_session_providers.dart';
import '../store/app_state.dart';

class LegacyStateBridge {
  LegacyStateBridge._();

  static final LegacyStateBridge instance = LegacyStateBridge._();

  StreamSubscription<AppState>? _subscription;

  void attach(Store<AppState> store, ProviderContainer container) {
    _subscription?.cancel();
    _subscription = store.onChange.listen((state) {
      _sync(state, container);
    });
    _sync(store.state, container);
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
    _subscription = null;
  }

  void _sync(AppState state, ProviderContainer container) {
    container.read(authSessionProvider.notifier).sync(state.auth.user);
    container.read(projectSessionProvider.notifier).sync(
          projects: state.project.projects,
          selectedProject: state.project.selectedProject,
          isLoading: state.project.loading,
        );
    container.read(themeSessionProvider.notifier).sync(state.theme.mode);
    container
        .read(notificationSessionProvider.notifier)
        .sync(state.notification);
  }
}
