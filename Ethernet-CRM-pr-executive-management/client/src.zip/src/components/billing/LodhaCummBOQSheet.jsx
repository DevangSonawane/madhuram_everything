import React, { useMemo } from "react";
import { Input } from "@/components/ui/input";
import { formatCurrencyINR } from "@/lib/numberFormat";

const toNumber = (value) => {
  if (value == null || value === "") return 0;
  const n = Number(String(value).replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : 0;
};

const PhaseRow = ({ label, phaseKey, item, phaseWeight, readonly, onQtyChange }) => {
  const prevDone = toNumber(item?.[`prev_${phaseKey}_qty`]);
  const currDone = toNumber(item?.[`curr_${phaseKey}_qty`]);
  const cummDone = prevDone + currDone;

  const rate = toNumber(item?.rate);
  const prevBoq = prevDone * phaseWeight;
  const currBoq = currDone * phaseWeight;
  const cummBoq = cummDone * phaseWeight;

  const prevAmt = prevBoq * rate;
  const currAmt = currBoq * rate;
  const cummAmt = cummBoq * rate;

  return (
    <tr className="bg-white">
      <td className="border px-2 py-1 text-xs text-muted-foreground" colSpan={2}>{label}</td>
      <td className="border px-2 py-1 text-right text-xs">{item?.wo_qty ?? ""}</td>
      <td className="border px-2 py-1 text-right text-xs">{prevDone.toFixed(2)}</td>
      <td className="border px-1 py-1 text-right text-xs bg-[#EBF5FB]">
        <Input
          className="h-7 text-right text-xs"
          value={String(item?.[`curr_${phaseKey}_qty`] ?? "")}
          disabled={readonly}
          onChange={(e) => onQtyChange(phaseKey, e.target.value)}
        />
      </td>
      <td className="border px-2 py-1 text-right text-xs">{cummDone.toFixed(2)}</td>
      <td className="border px-2 py-1 text-right text-xs">{prevBoq.toFixed(2)}</td>
      <td className="border px-2 py-1 text-right text-xs">{currBoq.toFixed(2)}</td>
      <td className="border px-2 py-1 text-right text-xs">{cummBoq.toFixed(2)}</td>
      <td className="border px-2 py-1 text-center text-xs">{item?.uom || ""}</td>
      <td className="border px-2 py-1 text-right text-xs">{rate ? rate.toFixed(2) : ""}</td>
      <td className="border px-2 py-1 text-right text-xs">{formatCurrencyINR(prevAmt)}</td>
      <td className="border px-2 py-1 text-right text-xs">{formatCurrencyINR(currAmt)}</td>
      <td className="border px-2 py-1 text-right text-xs">{formatCurrencyINR(cummAmt)}</td>
    </tr>
  );
};

export default function LodhaCummBOQSheet({ formData, onBoqItemsChange, phaseWeights, readonly }) {
  const items = Array.isArray(formData?.boq_items) ? formData.boq_items : [];

  const totals = useMemo(() => {
    const sum = { prev: 0, curr: 0, cumm: 0 };
    items.forEach((item) => {
      const rate = toNumber(item?.rate);
      const addPhase = (key, weight) => {
        const prev = toNumber(item?.[`prev_${key}_qty`]) * weight * rate;
        const curr = toNumber(item?.[`curr_${key}_qty`]) * weight * rate;
        sum.prev += prev;
        sum.curr += curr;
        sum.cumm += prev + curr;
      };
      addPhase("supply", phaseWeights?.supply ?? 0.6);
      addPhase("install", phaseWeights?.install ?? 0.25);
      addPhase("tc", phaseWeights?.tc ?? 0.1);
      addPhase("handover", phaseWeights?.handover ?? 0.05);
    });
    return sum;
  }, [items, phaseWeights]);

  const gst = {
    prev: totals.prev * 0.18,
    curr: totals.curr * 0.18,
    cumm: totals.cumm * 0.18,
  };

  const onQtyChange = (index, phaseKey, nextValue) => {
    const nextItems = items.slice();
    const row = { ...(nextItems[index] || {}) };
    row[`curr_${phaseKey}_qty`] = nextValue;
    nextItems[index] = row;
    onBoqItemsChange(nextItems);
  };

  if (!items.length) {
    return (
      <div className="rounded-md border p-4 text-sm text-muted-foreground">
        No BOQ items found. Import BOQ in the AMEND BOQ tab, then come back to fill quantities.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border p-4 text-sm">
        <div className="grid grid-cols-1 gap-1 md:grid-cols-2">
          <div>
            <div className="font-semibold">Company Name & Address</div>
            <div className="text-muted-foreground">From company defaults</div>
          </div>
          <div className="md:text-right">
            <div className="font-semibold">Reference</div>
            <div className="text-muted-foreground">{formData?.invoice_number || "-"}</div>
          </div>
          <div>
            <div className="font-semibold">Work Order No.</div>
            <div className="text-muted-foreground">{formData?.work_order_number || "-"}</div>
          </div>
          <div className="md:text-right">
            <div className="font-semibold">Work Order Date</div>
            <div className="text-muted-foreground">{formData?.work_order_date || "-"}</div>
          </div>
          <div>
            <div className="font-semibold">Project & Building Name</div>
            <div className="text-muted-foreground">{formData?.building_name || "-"}</div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[1400px] border-collapse">
          <thead>
            <tr className="bg-muted/50">
              <th className="border px-2 py-2 text-xs text-center">Sr.No</th>
              <th className="border px-2 py-2 text-xs text-center">Description of Work</th>
              <th className="border px-2 py-2 text-xs text-center">Current WO Qty</th>
              <th className="border px-2 py-2 text-xs text-center">Work Done - Prev</th>
              <th className="border px-2 py-2 text-xs text-center">Work Done - Curr</th>
              <th className="border px-2 py-2 text-xs text-center">Work Done - Cumm</th>
              <th className="border px-2 py-2 text-xs text-center">BOQ Qty - Prev</th>
              <th className="border px-2 py-2 text-xs text-center">BOQ Qty - Curr</th>
              <th className="border px-2 py-2 text-xs text-center">BOQ Qty - Cumm</th>
              <th className="border px-2 py-2 text-xs text-center">U.O.M.</th>
              <th className="border px-2 py-2 text-xs text-center">Rate / U.O.M.</th>
              <th className="border px-2 py-2 text-xs text-center">Amount - Prev</th>
              <th className="border px-2 py-2 text-xs text-center">Amount - Curr</th>
              <th className="border px-2 py-2 text-xs text-center">Amount - Cumm</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => (
              <React.Fragment key={`${item?.item_no}-${idx}`}>
                <tr className="bg-[#E2EFDA] font-semibold">
                  <td className="border px-2 py-1 text-xs text-center">{item?.item_no || idx + 1}</td>
                  <td className="border px-2 py-1 text-xs" colSpan={13}>
                    {item?.description || "-"}
                  </td>
                </tr>

                <PhaseRow
                  label="Supply @ 60%"
                  phaseKey="supply"
                  item={item}
                  phaseWeight={phaseWeights?.supply ?? 0.6}
                  readonly={readonly}
                  onQtyChange={(phaseKey, v) => onQtyChange(idx, phaseKey, v)}
                />
                <PhaseRow
                  label="Install @ 25%"
                  phaseKey="install"
                  item={item}
                  phaseWeight={phaseWeights?.install ?? 0.25}
                  readonly={readonly}
                  onQtyChange={(phaseKey, v) => onQtyChange(idx, phaseKey, v)}
                />
                <PhaseRow
                  label="Testing @ 10%"
                  phaseKey="tc"
                  item={item}
                  phaseWeight={phaseWeights?.tc ?? 0.1}
                  readonly={readonly}
                  onQtyChange={(phaseKey, v) => onQtyChange(idx, phaseKey, v)}
                />
                <PhaseRow
                  label="Handover @ 5%"
                  phaseKey="handover"
                  item={item}
                  phaseWeight={phaseWeights?.handover ?? 0.05}
                  readonly={readonly}
                  onQtyChange={(phaseKey, v) => onQtyChange(idx, phaseKey, v)}
                />
              </React.Fragment>
            ))}

            <tr className="bg-muted/30 font-semibold">
              <td className="border px-2 py-2 text-sm text-right" colSpan={11}>TOTAL</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.prev)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.curr)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.cumm)}</td>
            </tr>
            <tr className="bg-muted/10">
              <td className="border px-2 py-2 text-sm text-right font-semibold" colSpan={11}>GST 18%</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(gst.prev)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(gst.curr)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(gst.cumm)}</td>
            </tr>
            <tr className="bg-muted/10 font-semibold">
              <td className="border px-2 py-2 text-sm text-right" colSpan={11}>AMOUNT</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.prev + gst.prev)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.curr + gst.curr)}</td>
              <td className="border px-2 py-2 text-right text-sm">{formatCurrencyINR(totals.cumm + gst.cumm)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

