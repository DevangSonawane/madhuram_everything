import React, { useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatCurrencyINR } from "@/lib/numberFormat";

const cell = "border border-black px-1 py-1 text-[10px]";
const headerCell = "border border-black bg-[#D9D9D9] px-1 py-1 text-center font-semibold text-[9px]";

export default function LodhaTaxInvoiceSheet({ formData, computed, onChange, readonly }) {
  const cgstRate = (Number(formData?.cgst_rate) || 0.09) * 100;
  const sgstRate = (Number(formData?.sgst_rate) || 0.09) * 100;

  const amountInWords = computed?.amount_in_words || "";
  const taxableValue = computed?.taxable_value || 0;
  const cgstAmount = computed?.cgst_amount || 0;
  const sgstAmount = computed?.sgst_amount || 0;
  const totalInvoice = computed?.total_invoice_amount || 0;

  const invoiceMeta = useMemo(() => ({
    invoice_number: formData?.invoice_number || "",
    invoice_date: formData?.invoice_date || "",
    supplier_gstin: formData?.supplier_gstin || "",
    company_name: formData?.company_name || "",
    company_address: formData?.company_address || "",
    bill_to_name: formData?.bill_to_name || "",
    bill_to_address: formData?.bill_to_address || "",
    bill_to_gstin: formData?.bill_to_gstin || "",
    bill_to_state: formData?.bill_to_state || "",
    bill_to_state_code: formData?.bill_to_state_code || "",
    work_order_number: formData?.work_order_number || "",
    work_order_date: formData?.work_order_date || "",
    plant_name: formData?.plant_name || "",
    ra_number: formData?.ra_number || "",
    place_of_supply: formData?.place_of_supply || "",
    work_description: formData?.work_description || "PLUMBING WORKS",
    sac_code: formData?.sac_code || "998322",
  }), [formData]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <div className="space-y-1">
          <Label>RA Bill No</Label>
          <Input
            value={invoiceMeta.ra_number}
            disabled={readonly}
            onChange={(e) => onChange({ ra_number: e.target.value })}
            placeholder='3'
          />
        </div>
        <div className="space-y-1">
          <Label>Invoice No</Label>
          <Input
            value={invoiceMeta.invoice_number}
            disabled={readonly}
            onChange={(e) => onChange({ invoice_number: e.target.value })}
            placeholder="ME/PROJECT-PL/3"
          />
        </div>
        <div className="space-y-1">
          <Label>Invoice Date</Label>
          <Input
            type="date"
            value={invoiceMeta.invoice_date}
            disabled={readonly}
            onChange={(e) => onChange({ invoice_date: e.target.value })}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[1200px] border-collapse border-2 border-black">
          <tbody>
            <tr>
              <td className="border border-black p-2 text-center" colSpan={14}>
                <div className="text-[14px] font-bold">{invoiceMeta.company_name || " "}</div>
                <div className="text-[11px]">{invoiceMeta.company_address || " "}</div>
              </td>
            </tr>
            <tr>
              <td className="border border-black py-2 text-center font-serif text-[22px] font-bold" colSpan={14}>
                TAX INVOICE
              </td>
            </tr>

            <tr>
              <td className={`${cell}`} colSpan={7}>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>Invoice No :</div>
                  <div className="font-semibold">{invoiceMeta.invoice_number || "-"}</div>
                  <div>Invoice Date :</div>
                  <div className="font-semibold">{invoiceMeta.invoice_date || "-"}</div>
                  <div>GSTIN :</div>
                  <div className="font-semibold">{invoiceMeta.supplier_gstin || "-"}</div>
                </div>
              </td>
              <td className={`${cell}`} colSpan={7}>
                <div className="text-[10px] font-semibold">Receiver Details:</div>
                <div className="text-[10px]">{invoiceMeta.bill_to_name || "-"}</div>
                <div className="text-[10px] whitespace-pre-wrap">{invoiceMeta.bill_to_address || "-"}</div>
                <div className="text-[10px]">Place of Supply: {invoiceMeta.place_of_supply || "-"}</div>
              </td>
            </tr>

            <tr>
              <td className={`${cell}`} colSpan={14}>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <div><span className="font-semibold">Buyer:</span> {invoiceMeta.bill_to_name || "-"}</div>
                    <div className="whitespace-pre-wrap">{invoiceMeta.bill_to_address || "-"}</div>
                    <div>State Name: {invoiceMeta.bill_to_state || "-"}</div>
                    <div>State Code: {invoiceMeta.bill_to_state_code || "-"}</div>
                    <div>GSTIN: {invoiceMeta.bill_to_gstin || "-"}</div>
                  </div>
                  <div>
                    <div>WO No: <span className="font-semibold">{invoiceMeta.work_order_number || "-"}</span> DT <span className="font-semibold">{invoiceMeta.work_order_date || "-"}</span></div>
                    <div>PLANT NAME: <span className="font-semibold">{invoiceMeta.plant_name || "-"}</span></div>
                    <div>BILL NO: <span className="font-semibold">RA {invoiceMeta.ra_number || "-"}</span></div>
                  </div>
                </div>
              </td>
            </tr>

            <tr>
              <td className={headerCell}>SN</td>
              <td className={headerCell}>Description of Service/Goods</td>
              <td className={headerCell}>SAC/HSN Code</td>
              <td className={headerCell}>UOM</td>
              <td className={headerCell}>Qty</td>
              <td className={headerCell}>Rate</td>
              <td className={headerCell}>Total Value</td>
              <td className={headerCell}>Discount</td>
              <td className={headerCell}>Taxable Value</td>
              <td className={headerCell}>CGST Rate</td>
              <td className={headerCell}>CGST Amt</td>
              <td className={headerCell}>SGST Rate</td>
              <td className={headerCell}>SGST Amt</td>
              <td className={headerCell}>IGST/Cess</td>
            </tr>

            <tr>
              <td className={`${cell} text-center`}>1</td>
              <td className={`${cell} text-left`}>{invoiceMeta.work_description}</td>
              <td className={`${cell} text-center`}>{invoiceMeta.sac_code}</td>
              <td className={`${cell} text-center`}></td>
              <td className={`${cell} text-right`}></td>
              <td className={`${cell} text-right`}></td>
              <td className={`${cell} text-right`}>{formatCurrencyINR(taxableValue)}</td>
              <td className={`${cell} text-right`}>0</td>
              <td className={`${cell} text-right`}>{formatCurrencyINR(taxableValue)}</td>
              <td className={`${cell} text-center`}>{cgstRate.toFixed(0)}%</td>
              <td className={`${cell} text-right`}>{formatCurrencyINR(cgstAmount)}</td>
              <td className={`${cell} text-center`}>{sgstRate.toFixed(0)}%</td>
              <td className={`${cell} text-right`}>{formatCurrencyINR(sgstAmount)}</td>
              <td className={`${cell} text-center`}>0</td>
            </tr>

            <tr>
              <td className={`${cell} text-center font-semibold`} colSpan={6}>Total</td>
              <td className={`${cell} text-right font-semibold`}>{formatCurrencyINR(taxableValue)}</td>
              <td className={`${cell} text-right`}></td>
              <td className={`${cell} text-right font-semibold`}>{formatCurrencyINR(taxableValue)}</td>
              <td className={`${cell} text-center`}></td>
              <td className={`${cell} text-right font-semibold`}>{formatCurrencyINR(cgstAmount)}</td>
              <td className={`${cell} text-center`}></td>
              <td className={`${cell} text-right font-semibold`}>{formatCurrencyINR(sgstAmount)}</td>
              <td className={`${cell} text-center`}>0</td>
            </tr>

            <tr>
              <td className={`${cell}`} colSpan={14}>
                <div className="text-[10px]">
                  <span className="font-semibold">Total Invoice Value (In figure):</span> {formatCurrencyINR(totalInvoice)}
                </div>
              </td>
            </tr>
            <tr>
              <td className={`${cell}`} colSpan={14}>
                <div className="text-[10px]">
                  <span className="font-semibold">Total Invoice Value (In words):</span> {amountInWords || "-"}
                </div>
              </td>
            </tr>

            <tr>
              <td className={`${cell} bg-gray-50`} colSpan={14}>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-[10px] italic">
                    Declaration: We declare that this invoice shows the actual price of the goods/services described and that all particulars are true and correct.
                  </div>
                  <div className="text-right text-[10px]">
                    <div className="font-semibold">For MADHURAM ENTERPRISES</div>
                    <div className="mt-6">Authorised Signatory</div>
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

