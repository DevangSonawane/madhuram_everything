import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Loader2, Plus, Save, X } from "lucide-react";
import { api } from "@/lib/api";
import { useProject } from "@/contexts/useProject";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { UnitSelect, convertQuantity } from "@/components/forms/UnitSelect";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const URGENCY_OPTIONS = ["High", "Medium", "Low"];

const createEmptyItem = () => ({
  material_description: "",
  unit: "NOS",
  req_qty: "",
  make: "",
  place_of_utilisation: "",
});

const parseIntegerOrNull = (value) => {
  if (value == null || value === "") return null;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  return parsed;
};

const formatPrNumber = (pr = {}) => {
  const sourceDate = pr.date || pr.created_at || new Date().toISOString();
  const parsed = new Date(sourceDate);
  const yyyy = parsed.getFullYear();
  const mm = String(parsed.getMonth() + 1).padStart(2, "0");
  const dd = String(parsed.getDate()).padStart(2, "0");
  const datePart = Number.isNaN(parsed.getTime()) ? "0000-00-00" : `${yyyy}-${mm}-${dd}`;
  const sequence = pr.pr_id || pr.id || "0";
  const project = pr.project_id || pr.projectId || "0";
  return `PR-${datePart}-${sequence}-${project}`;
};

const formatDateToken = (value) => {
  const parsed = new Date(value || new Date().toISOString());
  if (Number.isNaN(parsed.getTime())) return "0000-00-00";
  const yyyy = parsed.getFullYear();
  const mm = String(parsed.getMonth() + 1).padStart(2, "0");
  const dd = String(parsed.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

export default function PurchaseRequestCreate() {
  const navigate = useNavigate();
  const { projectId } = useParams();
  const { selectedProject, projects } = useProject();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [sampleOptions, setSampleOptions] = useState([]);
  const [loadingSamples, setLoadingSamples] = useState(false);
  const [prOptions, setPrOptions] = useState([]);
  const [loadingSampleItems, setLoadingSampleItems] = useState(false);
  const [projectOptions, setProjectOptions] = useState([]);
  const [loadingProjects, setLoadingProjects] = useState(false);
  const [prItemSearch, setPrItemSearch] = useState("");
  const [loadingProjectMeta, setLoadingProjectMeta] = useState(false);
  const [sampleCatalogItems, setSampleCatalogItems] = useState([]);
  const [prItemSearchOpen, setPrItemSearchOpen] = useState(false);

  const defaultProjectId = useMemo(
    () => parseIntegerOrNull(projectId) || parseIntegerOrNull(selectedProject?.project_id || selectedProject?.id),
    [projectId, selectedProject]
  );

  const [form, setForm] = useState({
    project_id: defaultProjectId ? String(defaultProjectId) : "",
    sample_id: "",
    project_name: selectedProject?.project_name || selectedProject?.name || "",
    workorder_no: "",
    location: "",
    mirno: "",
    urgency: "Medium",
    date: new Date().toISOString().slice(0, 10),
    approved_by: "",
    remarks: "",
    items: [createEmptyItem()],
  });

  const selectedSampleMissing = useMemo(
    () => form.sample_id && !sampleOptions.some((sample) => String(sample.sample_id || sample.id) === form.sample_id),
    [form.sample_id, sampleOptions]
  );

  const matchesPrItemSearch = (item) => {
    const q = String(prItemSearch || "").trim().toLowerCase();
    if (!q) return true;
    const desc = String(item?.material_description ?? "").toLowerCase();
    const make = String(item?.make ?? "").toLowerCase();
    const place = String(item?.place_of_utilisation ?? "").toLowerCase();
    const unit = String(item?.unit ?? "").toLowerCase();
    return desc.includes(q) || make.includes(q) || place.includes(q) || unit.includes(q);
  };

  const prItemSuggestions = useMemo(() => {
    const q = String(prItemSearch || "").trim().toLowerCase();
    const keyFor = (v) => String(v || "").trim().toLowerCase();
    const unique = new Map(); // key -> item

    (Array.isArray(sampleCatalogItems) ? sampleCatalogItems : []).forEach((it) => {
      const k = keyFor(it?.material_description);
      if (!k) return;
      if (!unique.has(k)) unique.set(k, it);
    });

    const all = Array.from(unique.values());
    if (!q) return all.slice(0, 10);
    return all
      .filter((it) => matchesPrItemSearch(it))
      .slice(0, 10);
  }, [sampleCatalogItems, prItemSearch]);

  const autoPrNumber = useMemo(() => {
    const project = parseIntegerOrNull(form.project_id) || defaultProjectId || 0;
    const selectedDate = form.date || new Date().toISOString().slice(0, 10);
    const dateToken = formatDateToken(selectedDate);
    const sequence = (
      Array.isArray(prOptions)
        ? prOptions.filter((pr) => {
            const sameProject = String(pr?.project_id || pr?.projectId || "") === String(project);
            const sameDate = formatDateToken(pr?.date || pr?.created_at) === dateToken;
            return sameProject && sameDate;
          }).length
        : 0
    ) + 1;
    return `PR-${dateToken}-${sequence}-${project}`;
  }, [form.project_id, form.date, prOptions, defaultProjectId]);

  const effectiveProjectId = useMemo(
    () => parseIntegerOrNull(form.project_id) || defaultProjectId,
    [form.project_id, defaultProjectId]
  );

  useEffect(() => {
    setLoadingProjects(true);
    const byId = new Map();
    (Array.isArray(projects) ? projects : []).forEach((project) => {
      const id = project?.project_id ?? project?.id;
      if (id == null || id === "") return;
      byId.set(String(id), project);
    });
    setProjectOptions(Array.from(byId.values()));
    setLoadingProjects(false);
  }, [projects]);

  useEffect(() => {
    const currentProjectId = String(form.project_id || "").trim();
    if (!currentProjectId) return;

    const selectedFromOptions = projectOptions.find(
      (project) => String(project.project_id || project.id) === currentProjectId
    );
    const resolvedProjectName =
      selectedFromOptions?.project_name ||
      selectedFromOptions?.name ||
      selectedProject?.project_name ||
      selectedProject?.name ||
      "";
    const resolvedLocation =
      String(selectedFromOptions?.location || selectedProject?.location || "").trim();
    const resolvedWorkOrderNo =
      String(selectedFromOptions?.wo_number || selectedProject?.wo_number || "").trim();

    setForm((prev) => {
      let changed = false;
      const next = { ...prev };

      if (resolvedProjectName && String(prev.project_name || "") !== String(resolvedProjectName)) {
        next.project_name = resolvedProjectName;
        changed = true;
      }

      if (!String(prev.location || "").trim() && resolvedLocation) {
        next.location = resolvedLocation;
        changed = true;
      }

      if (!String(prev.workorder_no || "").trim() && resolvedWorkOrderNo) {
        next.workorder_no = resolvedWorkOrderNo;
        changed = true;
      }

      return changed ? next : prev;
    });
  }, [form.project_id, form.project_name, projectOptions, selectedProject]);

  useEffect(() => {
    let mounted = true;
    const loadProjectMeta = async () => {
      const pid = parseIntegerOrNull(form.project_id);
      if (!pid) return;

      // Only fetch if we still don't have these derived fields.
      if (String(form.workorder_no || "").trim() && String(form.location || "").trim()) return;

      setLoadingProjectMeta(true);
      try {
        const res = await api.getProjectById(pid);
        if (!mounted) return;
        if (!res?.success) return;
        const p = res.data?.project || res.data?.data || res.data;
        if (!p) return;
        const wo = String(p?.wo_number || "").trim();
        const loc = String(p?.location || "").trim();
        setForm((prev) => ({
          ...prev,
          workorder_no: String(prev.workorder_no || "").trim() ? prev.workorder_no : wo,
          location: String(prev.location || "").trim() ? prev.location : loc,
        }));
      } finally {
        if (mounted) setLoadingProjectMeta(false);
      }
    };
    loadProjectMeta();
    return () => {
      mounted = false;
    };
  }, [form.project_id, form.workorder_no, form.location]);

  useEffect(() => {
    let mounted = true;

    const loadSamples = async () => {
      setLoadingSamples(true);
      try {
        const result = effectiveProjectId
          ? await api.getSamplesByProject(effectiveProjectId)
          : await api.getSamples();

        if (!mounted) return;
        if (!result.success || !Array.isArray(result.data)) {
          setSampleOptions([]);
          return;
        }

        const byId = new Map();
        result.data.forEach((sample) => {
          const id = sample?.sample_id ?? sample?.id;
          if (id == null || id === "") return;
          byId.set(String(id), sample);
        });
        setSampleOptions(Array.from(byId.values()));
      } catch {
        if (mounted) setSampleOptions([]);
      } finally {
        if (mounted) setLoadingSamples(false);
      }
    };

    loadSamples();
    return () => {
      mounted = false;
    };
  }, [effectiveProjectId]);

  useEffect(() => {
    let mounted = true;

    const loadPrOptions = async () => {
      try {
        if (!effectiveProjectId) {
          setPrOptions([]);
          return;
        }

        const result = await api.getPrsByProject(effectiveProjectId);

        if (!mounted) return;
        if (!result.success || !Array.isArray(result.data)) {
          setPrOptions([]);
          return;
        }

        const byId = new Map();
        result.data.forEach((pr) => {
          const id = pr?.pr_id ?? pr?.id;
          if (id == null || id === "") return;
          byId.set(String(id), pr);
        });
        setPrOptions(Array.from(byId.values()));
      } catch {
        if (mounted) setPrOptions([]);
      }
    };

    loadPrOptions();
    return () => {
      mounted = false;
    };
  }, [effectiveProjectId]);

  const setField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const setItemField = (index, field, value) => {
    setForm((prev) => {
      const next = [...prev.items];
      next[index] = { ...next[index], [field]: value };
      return { ...prev, items: next };
    });
  };

  const addItem = () => {
    setForm((prev) => ({ ...prev, items: [...prev.items, createEmptyItem()] }));
  };

  const removeItem = (index) => {
    setForm((prev) => {
      if (prev.items.length <= 1) return prev;
      return { ...prev, items: prev.items.filter((_, i) => i !== index) };
    });
  };

  const goBackToList = () => {
    navigate(`/${projectId}/purchase-requests`);
  };

  const parseArrayField = (value) => {
    if (Array.isArray(value)) return value;
    if (typeof value === "string") {
      try {
        const parsed = JSON.parse(value);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  };

  const mapSampleItemsToFormItems = (itemDescription) => {
    const parsedItems = parseArrayField(itemDescription);
    if (parsedItems.length === 0) return [createEmptyItem()];

    const mapped = parsedItems
      .map((item) => {
        const addFields = parseArrayField(item?.add_fields);
        return {
          material_description: String(
            item?.material_description || item?.description || item?.item || item?.name || ""
          ).trim(),
          unit: String(item?.unit || item?.uom || item?.UOM || "NOS").trim() || "NOS",
          req_qty:
            item?.quantity == null
              ? item?.qty == null
                ? item?.req_qty == null
                  ? ""
                  : String(item.req_qty)
                : String(item.qty)
              : String(item.quantity),
          make: String(item?.make || item?.brand || "").trim(),
          place_of_utilisation: String(item?.place_of_utilisation || item?.place || "").trim(),
        };
      })
      .filter((item) => item.material_description || item.req_qty);

    return mapped.length > 0 ? mapped : [createEmptyItem()];
  };

  const applySelectedSampleToForm = (sample) => {
    if (!sample) return;

    const mappedItems = mapSampleItemsToFormItems(sample.item_description);
    setForm((prev) => ({ ...prev, items: mappedItems }));
    setSampleCatalogItems(mappedItems);
    toast({
      title: "Sample items loaded",
      description: `${mappedItems.length} item${mappedItems.length === 1 ? "" : "s"} loaded into PR Items.`,
    });
  };

  const addCatalogItemToPr = (catalogItem) => {
    if (!catalogItem) return;
    setForm((prev) => ({
      ...prev,
      items: [...prev.items, { ...createEmptyItem(), ...catalogItem }],
    }));
  };

  const handleSampleChange = async (value) => {
    if (value === "none") {
      setField("sample_id", "");
      return;
    }

    setField("sample_id", value);

    const selectedSample = sampleOptions.find((sample) => String(sample.sample_id || sample.id) === String(value));
    if (selectedSample && parseArrayField(selectedSample.item_description).length > 0) {
      // Prefill location + project id from the selected sample.
      setForm((prev) => {
        const nextProjectId = selectedSample?.project_id ?? selectedSample?.projectId ?? prev.project_id;
        const resolvedProject =
          projectOptions.find((p) => String(p?.project_id ?? p?.id ?? "") === String(nextProjectId)) || null;
        return {
          ...prev,
          project_id: nextProjectId != null && nextProjectId !== "" ? String(nextProjectId) : prev.project_id,
          project_name: resolvedProject?.project_name || resolvedProject?.name || prev.project_name,
          location: prev.location || String(selectedSample?.site_name || "").trim(),
          workorder_no: String(prev.workorder_no || "").trim()
            ? prev.workorder_no
            : String(resolvedProject?.wo_number || "").trim(),
        };
      });
      applySelectedSampleToForm(selectedSample);
      return;
    }

    setLoadingSampleItems(true);
    try {
      const result = await api.getSampleById(value);
      if (!result.success) {
        toast({
          title: "Failed to load sample items",
          description: result.error || "Could not fetch selected sample details.",
          variant: "destructive",
        });
        return;
      }

      const fetched = result.data || {};
      setForm((prev) => {
        const nextProjectId = fetched?.project_id ?? fetched?.projectId ?? prev.project_id;
        const resolvedProject =
          projectOptions.find((p) => String(p?.project_id ?? p?.id ?? "") === String(nextProjectId)) || null;
        return {
          ...prev,
          project_id: nextProjectId != null && nextProjectId !== "" ? String(nextProjectId) : prev.project_id,
          project_name: resolvedProject?.project_name || resolvedProject?.name || prev.project_name,
          location: prev.location || String(fetched?.site_name || "").trim(),
          workorder_no: String(prev.workorder_no || "").trim()
            ? prev.workorder_no
            : String(resolvedProject?.wo_number || "").trim(),
        };
      });
      applySelectedSampleToForm(fetched);
    } catch {
      toast({
        title: "Failed to load sample items",
        description: "Could not fetch selected sample details.",
        variant: "destructive",
      });
    } finally {
      setLoadingSampleItems(false);
    }
  };

  const handleProjectChange = (value) => {
    if (value === "none") {
      setForm((prev) => ({ ...prev, project_id: "", project_name: "" }));
      return;
    }
    const selected = projectOptions.find((project) => String(project.project_id || project.id) === String(value));
    setForm((prev) => ({
      ...prev,
      project_id: String(value),
      project_name: selected?.project_name || selected?.name || prev.project_name,
      location: prev.location || String(selected?.location || "").trim(),
      workorder_no: String(selected?.wo_number || "").trim() || prev.workorder_no,
    }));
  };

  const handleSubmit = async () => {
    const normalizedProjectId = parseIntegerOrNull(form.project_id);
    if (!normalizedProjectId) {
      toast({
        title: "Validation failed",
        description: "Project ID is required and must be a positive integer.",
        variant: "destructive",
      });
      return;
    }

    if (!parseIntegerOrNull(form.sample_id)) {
      toast({
        title: "Validation failed",
        description: "Sample is required. Please select a sample to load PR items.",
        variant: "destructive",
      });
      return;
    }

    if (!String(form.project_name || "").trim()) {
      toast({
        title: "Validation failed",
        description: "Project name is required.",
        variant: "destructive",
      });
      return;
    }

    const cleanedItems = form.items
      .map((item) => {
        const reqQty = Number(item.req_qty);
        const payload = {
          material_description: String(item.material_description || "").trim(),
          unit: String(item.unit || "").trim() || "NOS",
          req_qty: reqQty,
          make: String(item.make || "").trim(),
          place_of_utilisation: String(item.place_of_utilisation || "").trim(),
        };
        return payload;
      })
      .filter((item) => item.material_description && Number.isFinite(item.req_qty) && item.req_qty > 0);

    if (cleanedItems.length === 0) {
      toast({
        title: "Validation failed",
        description: "Add at least one item with description and quantity.",
        variant: "destructive",
      });
      return;
    }

    try {
      setSubmitting(true);

      const payload = {
        project_id: normalizedProjectId,
        sample_id: parseIntegerOrNull(form.sample_id),
        project_name: String(form.project_name || "").trim(),
        workorder_no: String(form.workorder_no || "").trim(),
        location: String(form.location || "").trim(),
        mirno: String(form.mirno || "").trim(),
        urgency: form.urgency || "Medium",
        date: form.date || new Date().toISOString().slice(0, 10),
        approved_by: String(form.approved_by || "").trim(),
        remarks: String(form.remarks || "").trim(),
        items: cleanedItems,
      };

      const result = await api.createPr(payload);
      if (!result.success) {
        toast({
          title: "Create failed",
          description: result.error || "Unable to create PR.",
          variant: "destructive",
        });
        return;
      }

      const createdPr = result.data || {};
      const generatedPrNumber = formatPrNumber({
        ...createdPr,
        project_id: createdPr.project_id || normalizedProjectId,
        date: createdPr.date || form.date,
      });
      toast({
        title: "PR created",
        description: `Purchase request created successfully. ${generatedPrNumber}`,
      });
      goBackToList();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-border bg-gradient-to-r from-emerald-50 via-teal-50 to-white p-6 md:p-8 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800/70">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <h1 className="text-3xl font-bold tracking-tight">Create Purchase Request</h1>
            <p className="mt-1 text-sm text-muted-foreground">Create PR in a dedicated page flow.</p>
          </div>
          <Button variant="outline" onClick={goBackToList} className="w-full sm:w-auto">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to PR List
          </Button>
        </div>
      </section>

      <Card>
        <CardHeader>
          <CardTitle>PR Header</CardTitle>
          <CardDescription>Fill required project details and optional attachments.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Project ID *</Label>
            <Select value={form.project_id || "none"} onValueChange={handleProjectChange}>
              <SelectTrigger>
                <SelectValue placeholder={loadingProjects ? "Loading projects..." : "Select Project ID"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {projectOptions.map((project) => {
                  const id = String(project.project_id || project.id);
                  const label = project.project_name || project.name || `Project ${id}`;
                  return (
                    <SelectItem key={id} value={id}>
                      {`${id} - ${label}`}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Project Name *</Label>
            <Input value={form.project_name} readOnly />
          </div>
          <div className="space-y-2">
            <Label>Sample ID</Label>
            <Select
              value={form.sample_id || "none"}
              onValueChange={handleSampleChange}
            >
              <SelectTrigger>
                <SelectValue placeholder={loadingSamples ? "Loading samples..." : "Optional"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {selectedSampleMissing ? (
                  <SelectItem value={form.sample_id}>Sample #{form.sample_id} (current)</SelectItem>
                ) : null}
                {sampleOptions.map((sample) => {
                  const id = String(sample.sample_id || sample.id);
                  const label = sample.work_done || sample.site_name || sample.building_name || `Sample #${id}`;
                  return (
                    <SelectItem key={id} value={id}>
                      {`#${id} - ${label}`}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>PR Number</Label>
            <Input value={autoPrNumber} readOnly />
          </div>
          <div className="space-y-2">
            <Label>Work Order No</Label>
            <Input value={form.workorder_no} onChange={(e) => setField("workorder_no", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>MIR No</Label>
            <Input
              value={form.mirno}
              onChange={(e) => setField("mirno", e.target.value)}
              placeholder="Optional"
            />
          </div>
          <div className="space-y-2">
            <Label>Urgency</Label>
            <Select value={form.urgency} onValueChange={(value) => setField("urgency", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select urgency" />
              </SelectTrigger>
              <SelectContent>
                {URGENCY_OPTIONS.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Date</Label>
            <Input type="date" value={form.date} onChange={(e) => setField("date", e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Approved By</Label>
            <Input value={form.approved_by} onChange={(e) => setField("approved_by", e.target.value)} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Location</Label>
            <Input value={form.location} onChange={(e) => setField("location", e.target.value)} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Remarks</Label>
            <Textarea value={form.remarks} onChange={(e) => setField("remarks", e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>PR Items</CardTitle>
          <CardDescription>
            {loadingSampleItems
              ? "Loading items from selected sample..."
              : "Items are sourced from the selected sample."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-2 md:grid-cols-[1fr_auto] md:items-end">
            <div className="space-y-2 relative">
              <Label>Search Items</Label>
              <Input
                value={prItemSearch}
                onChange={(e) => setPrItemSearch(e.target.value)}
                onFocus={() => setPrItemSearchOpen(true)}
                onBlur={() => setTimeout(() => setPrItemSearchOpen(false), 120)}
                placeholder="Search by description, make, place, or unit…"
              />
              {prItemSearchOpen && prItemSuggestions.length > 0 ? (
                <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-md">
                  <div className="max-h-56 overflow-auto p-1">
                    {prItemSuggestions.map((sug, idx) => {
                      const title = String(sug?.material_description || "").trim();
                      const subtitleParts = [
                        sug?.make ? `Name: ${sug.make}` : "",
                        sug?.unit ? `Unit: ${sug.unit}` : "",
                        sug?.place_of_utilisation ? `Place: ${sug.place_of_utilisation}` : "",
                      ].filter(Boolean);
                      const subtitle = subtitleParts.join(" • ");
                      return (
                        <button
                          key={`${title || "item"}-${idx}`}
                          type="button"
                          className="w-full text-left rounded-sm px-2 py-2 hover:bg-muted focus:bg-muted focus:outline-none"
                          onMouseDown={(e) => {
                            // Prevent input blur before selection.
                            e.preventDefault();
                          }}
                          onClick={() => {
                            addCatalogItemToPr(sug);
                            setPrItemSearch(title);
                            setPrItemSearchOpen(false);
                          }}
                        >
                          <div className="text-sm font-medium truncate">{title || "-"}</div>
                          {subtitle ? (
                            <div className="text-xs text-muted-foreground truncate">{subtitle}</div>
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}
            </div>
            <Button variant="outline" size="sm" onClick={addItem} className="w-full sm:w-auto">
              <Plus className="mr-2 h-4 w-4" /> Add Row
            </Button>
          </div>
          {form.items.map((item, index) => (
            matchesPrItemSearch(item) ? (
            <Card key={`item-${index}`}>
              <CardContent className="grid gap-4 p-4 md:grid-cols-6">
                <div className="md:col-span-6">
                  <Label className="mb-1 block text-xs">Material Description *</Label>
                  <Input
                    value={item.material_description}
                    onChange={(e) => setItemField(index, "material_description", e.target.value)}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="mb-1 block text-xs">Unit</Label>
                  <UnitSelect
                    value={item.unit}
                    onValueChange={(value) => {
                      const converted = convertQuantity(item.req_qty, item.unit, value);
                      setItemField(index, "unit", value);
                      if (converted != null) {
                        setItemField(index, "req_qty", converted);
                      }
                    }}
                    triggerClassName="h-9"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="mb-1 block text-xs">Qty *</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={item.req_qty}
                    onChange={(e) => setItemField(index, "req_qty", e.target.value)}
                  />
                </div>
                <div className="md:col-span-3">
                  <Label className="mb-1 block text-xs">Name</Label>
                  <Input value={item.make} onChange={(e) => setItemField(index, "make", e.target.value)} />
                </div>
                <div className="md:col-span-3">
                  <Label className="mb-1 block text-xs">Place of Utilisation</Label>
                  <Input
                    value={item.place_of_utilisation}
                    onChange={(e) => setItemField(index, "place_of_utilisation", e.target.value)}
                  />
                </div>
                <div className="md:col-span-6 flex">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeItem(index)}
                    disabled={form.items.length <= 1}
                    className="w-full sm:w-auto sm:ml-auto"
                  >
                    <X className="mr-2 h-4 w-4" /> Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
            ) : null
          ))}
        </CardContent>
      </Card>

      <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
        <Button variant="outline" onClick={goBackToList} disabled={submitting}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={submitting}>
          {submitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" /> Create PR
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
