import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import * as XLSX from "xlsx";
import { ArrowLeft, CheckCircle2, Loader2, Trash2, UploadCloud, XCircle } from "lucide-react";
import { api } from "@/lib/api";
import { useResolvedProject } from "@/hooks/useResolvedProject";
import { useProject } from "@/contexts/useProject";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const NAVY = "#1a3a6b";
const CURRENCY_FORMATTER = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 2,
});

const formatInr = (value) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return "-";
  return CURRENCY_FORMATTER.format(parsed);
};

const formatNumber = (value) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return "-";
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(parsed);
};

const toTrimmed = (value) => String(value ?? "").replace(/\u00A0/g, " ").trim();

const normalizeForMatch = (value) =>
  toTrimmed(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

// PR matching normalization (must mirror spec)
const normalizeForPrMatch = (value) =>
  toTrimmed(value)
    .toLowerCase()
    .replace(/['"()]/g, "")
    .replace(/\s+/g, " ")
    .replace(/(\d+)\s*mm/g, "$1mm")
    .replace(/(\d+)\s*x\s*(\d+)/gi, "$1x$2")
    .replace(/\bdeg\.?/gi, "deg")
    .trim();

const prTokens = (value) =>
  normalizeForPrMatch(value)
    .split(" ")
    .map((t) => t.trim())
    .filter((t) => t.length > 1);

const extractUniquePrItems = (prs) => {
  const list = Array.isArray(prs) ? prs : [];
  const all = list
    .flatMap((pr) => (Array.isArray(pr?.items) ? pr.items : []))
    .map((item) => ({
      material_description: String(item?.material_description || "").trim(),
      unit: item?.unit ?? "",
      req_qty: item?.req_qty ?? null,
      make: item?.make ?? "",
      pr_id: item?.pr_id ?? item?.prId ?? pr?.pr_id ?? pr?.id ?? null,
    }))
    .filter((item) => item.material_description);

  return Array.from(new Map(all.map((i) => [i.material_description.toLowerCase(), i])).values());
};

const matchAgainstPrItems = (parsedItem, prItems) => {
  const parsedDescription = String(parsedItem?.description || "").trim();
  const parsedLower = parsedDescription.toLowerCase();
  const parsedNorm = normalizeForPrMatch(parsedDescription);
  const parsedTokenSet = new Set(prTokens(parsedDescription));

  const candidates = Array.isArray(prItems) ? prItems : [];

  // 1) exact
  const exact = candidates.find((pr) => pr.material_description.toLowerCase() === parsedLower) || null;
  if (exact) {
    return { matchStatus: "matched", matchedPrItem: exact, matchScore: 1, matchType: "exact" };
  }

  // 2) normalized exact
  const normalized = candidates.find((pr) => normalizeForPrMatch(pr.material_description) === parsedNorm) || null;
  if (normalized) {
    return { matchStatus: "matched", matchedPrItem: normalized, matchScore: 1, matchType: "normalized" };
  }

  // 3) substring (normalized)
  const substring = candidates.find((pr) => {
    const prNorm = normalizeForPrMatch(pr.material_description);
    return prNorm && (parsedNorm.includes(prNorm) || prNorm.includes(parsedNorm));
  }) || null;
  if (substring) {
    return { matchStatus: "matched", matchedPrItem: substring, matchScore: 0.85, matchType: "substring" };
  }

  // 4) token overlap >= 70%
  let best = null;
  candidates.forEach((pr) => {
    const prTok = prTokens(pr.material_description);
    if (prTok.length === 0 || parsedTokenSet.size === 0) return;
    const overlap = prTok.filter((t) => parsedTokenSet.has(t)).length;
    const score = overlap / Math.max(prTok.length, parsedTokenSet.size);
    if (best == null || score > best.score) {
      best = { score, prItem: pr };
    }
  });
  if (best && best.score >= 0.7) {
    return { matchStatus: "matched", matchedPrItem: best.prItem, matchScore: best.score, matchType: "token" };
  }

  return { matchStatus: "unmatched", matchedPrItem: null, matchScore: 0, matchType: null };
};

const isXlsxFile = (file) => {
  const name = String(file?.name || "").toLowerCase();
  const type = String(file?.type || "").toLowerCase();
  return (
    name.endsWith(".xlsx") ||
    type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
    type === "application/octet-stream"
  );
};

const statusMeta = (statusRaw) => {
  const status = String(statusRaw || "pending").toLowerCase();
  if (status === "approved") return { label: "approved", badgeClass: "bg-emerald-600 text-white" };
  if (status === "rejected") return { label: "rejected", badgeClass: "bg-rose-600 text-white" };
  if (status === "draft") return { label: "draft", badgeClass: "bg-slate-700 text-white" };
  return { label: "pending", badgeClass: "bg-amber-500 text-white" };
};

const splitLabelValue = (line) => {
  const raw = toTrimmed(line);
  if (!raw) return "";
  const idx = raw.indexOf(":-");
  if (idx === -1) return raw;
  return raw.slice(idx + 2).trim();
};

const isSectionLabel = (value) => /^[A-Z]$/.test(toTrimmed(value));
const isNumericSr = (value) => /^\d+$/.test(toTrimmed(value));

const toNumberOrNull = (value) => {
  if (value === "" || value == null) return null;
  const parsed = Number(String(value).replace(/,/g, "").trim());
  return Number.isFinite(parsed) ? parsed : null;
};

const pickFirstSheetRows = (workbook) => {
  const sheetName = workbook.SheetNames?.[0];
  if (!sheetName) return [];
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) return [];
  return XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
};

const findHeaderRowIndex = (rows) => {
  // Prefer the row with "Sr. No." and "UOM" present.
  for (let i = 0; i < Math.min(rows.length, 12); i += 1) {
    const row = rows[i] || [];
    const normalized = row.map((c) => normalizeForMatch(c));
    const hasSr = normalized.some((c) => c === "sr no" || c === "sr. no" || c === "sr no.");
    const hasUom = normalized.some((c) => c === "uom");
    const hasQty = normalized.some((c) => c === "total qty" || c === "qty" || c === "totalqty");
    if (hasSr && hasUom && hasQty) return i;
  }
  return 6; // default as per spec
};

const parseVendorColumns = (rows, vendorRowIdx, headerRowIdx) => {
  const vendorRow = rows[vendorRowIdx] || [];
  const headerRow = rows[headerRowIdx] || [];
  const subLabelRow = rows[vendorRowIdx + 1] || [];

  const vendors = [];
  let col = 5;
  let emptyPairs = 0;

  while (col < Math.max(vendorRow.length, headerRow.length)) {
    const name = toTrimmed(vendorRow[col]);
    const nextHeader = normalizeForMatch(headerRow[col] || "");
    const looksLikeRateHeader = nextHeader === "rate";

    if (!name && !looksLikeRateHeader) {
      emptyPairs += 1;
      if (emptyPairs >= 2) break;
      col += 2;
      continue;
    }

    emptyPairs = 0;
    const below = toTrimmed(subLabelRow[col]);
    const belowNorm = normalizeForMatch(below);
    const subLabelFromBelow = below && belowNorm !== "rate" && belowNorm !== "amount" ? below : "";
    const sideCandidate = toTrimmed(vendorRow[col + 1]);
    const sideNorm = normalizeForMatch(sideCandidate);
    const subLabelFromSide = sideCandidate && sideNorm !== "amount" && sideNorm !== "rate" ? sideCandidate : "";
    const subLabel = subLabelFromBelow || subLabelFromSide || "";

    vendors.push({
      name: name || `Vendor ${vendors.length + 1}`,
      subLabel,
      rateColIndex: col,
      amountColIndex: col + 1,
    });
    col += 2;
  }

  return vendors;
};

const parseComparisonWorkbook = (workbook) => {
  const rows = pickFirstSheetRows(workbook);
  const meta = {
    companyName: splitLabelValue(rows?.[0]?.[0] || ""),
    projectName: splitLabelValue(rows?.[1]?.[0] || ""),
    indentNo: splitLabelValue(rows?.[2]?.[0] || ""),
    indentDate: splitLabelValue(rows?.[3]?.[0] || ""),
    comparisonDate: splitLabelValue(rows?.[4]?.[0] || ""),
  };

  const vendorRowIdx = 5;
  const headerRowIdx = findHeaderRowIndex(rows);
  const vendors = parseVendorColumns(rows, vendorRowIdx, headerRowIdx);

  const sections = [];
  let currentSection = null;

  const dataStart = Math.max(headerRowIdx + 1, 7);

  for (let r = dataStart; r < rows.length; r += 1) {
    const row = rows[r] || [];
    const srRaw = toTrimmed(row[0]);

    const c1 = normalizeForMatch(row?.[1] || "");
    const c2 = normalizeForMatch(row?.[2] || "");
    const c0 = normalizeForMatch(row?.[0] || "");
    if (c1.includes("subtotal") || c2.includes("subtotal") || (!c0 && c1 === "subtotal")) break;

    if (isSectionLabel(srRaw)) {
      const sectionDescription = toTrimmed(row[2] || row[1] || "");
      currentSection = {
        sectionLabel: srRaw,
        sectionDescription: sectionDescription || "-",
        items: [],
      };
      sections.push(currentSection);
      continue;
    }

    if (isNumericSr(srRaw)) {
      if (!currentSection) {
        currentSection = { sectionLabel: "", sectionDescription: "", items: [] };
        sections.push(currentSection);
      }

      const vendorData = vendors.map((vendor, vendorIndex) => ({
        vendorIndex,
        vendorName: vendor.name,
        rate: toNumberOrNull(row[vendor.rateColIndex]),
        amount: toNumberOrNull(row[vendor.amountColIndex]),
      }));

      currentSection.items.push({
        srNo: Number(srRaw),
        hsnCode: toTrimmed(row[1]),
        description: toTrimmed(row[2]),
        totalQty: toNumberOrNull(row[3]),
        uom: toTrimmed(row[4]),
        vendorData,
      });
      continue;
    }

    // Keep scanning until footer; ignore blank / unrecognized rows.
  }

  return { meta, vendors, sections };
};

export default function VendorComparisonUpload({ inLayout = false }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { projectId } = useParams();
  const resolvedProject = useResolvedProject();
  const { projects, selectedProject } = useProject();

  const fileInputRef = useRef(null);
  const initialProjectId = resolvedProject.projectId || String(selectedProject?.id || selectedProject?.project_id || "");
  const [activeProjectId, setActiveProjectId] = useState(initialProjectId);

  const [file, setFile] = useState(null);
  const [parsing, setParsing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("pending");
  const [uploadedAt, setUploadedAt] = useState(null);

  const [comparisonId, setComparisonId] = useState(null);
  const [parsed, setParsed] = useState(null);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [matched, setMatched] = useState([]);
  const [unmatched, setUnmatched] = useState([]);
  const [matchedSections, setMatchedSections] = useState([]);
  const [unmatchedSections, setUnmatchedSections] = useState([]);
  const [prCount, setPrCount] = useState(0);
  const [prItemCount, setPrItemCount] = useState(0);
  const [totalParsedCount, setTotalParsedCount] = useState(0);
  const [vendorCompareMap, setVendorCompareMap] = useState({});

  const isStandalone = !inLayout && location.pathname.includes("/vendor-comparison/upload");
  const containerClass = isStandalone
    ? "content-shell px-3 sm:px-4 md:px-8 pt-3 sm:pt-4 md:pt-8"
    : "space-y-6";

  const projectOptions = useMemo(() => {
    const list = Array.isArray(projects) ? projects : [];
    return list
      .map((p) => ({
        id: String(p?.id || p?.project_id || "").trim(),
        label: p?.name || p?.project_name || `Project ${p?.id || p?.project_id || ""}`,
      }))
      .filter((p) => p.id);
  }, [projects]);

  useEffect(() => {
    if (activeProjectId) return;
    if (initialProjectId) setActiveProjectId(initialProjectId);
  }, [activeProjectId, initialProjectId]);

  const canUpload = Boolean(file) && Boolean(activeProjectId) && !uploading && !parsing;
  const statusBadge = statusMeta(status);

  const lowestRateByItem = useMemo(() => {
    const map = new Map();
    const sections = parsed?.sections || [];
    sections.forEach((section) => {
      (section.items || []).forEach((item) => {
        const rates = (item.vendorData || []).map((v) => v.rate).filter((v) => Number.isFinite(v));
        map.set(item.srNo, rates.length ? Math.min(...rates) : null);
      });
    });
    return map;
  }, [parsed]);

  const vendorTotals = useMemo(() => {
    const vendors = parsed?.vendors || [];
    const totalsArray = vendors.map(() => 0);
    const sections = parsed?.sections || [];

    sections.forEach((section) => {
      (section.items || []).forEach((item) => {
        (item.vendorData || []).forEach((vd) => {
          const idx = vd?.vendorIndex;
          const amount = vd?.amount;
          if (!Number.isInteger(idx) || idx < 0 || idx >= totalsArray.length) return;
          if (!Number.isFinite(amount)) return;
          totalsArray[idx] += amount;
        });
      });
    });

    const numericTotals = totalsArray.map((v) => (Number.isFinite(v) ? v : null));
    const candidates = numericTotals
      .map((value, index) => ({ value, index }))
      .filter((entry) => entry.value != null);
    if (candidates.length === 0) return { totals: numericTotals, minIndex: -1, maxIndex: -1 };

    candidates.sort((a, b) => a.value - b.value);
    const minIndex = candidates[0].index;
    const maxIndex = candidates[candidates.length - 1].index;
    return { totals: numericTotals, minIndex, maxIndex };
  }, [parsed]);

  const handlePickFile = useCallback(() => {
    setError("");
    fileInputRef.current?.click();
  }, []);

  const handleFileChange = useCallback((event) => {
    const next = event.target.files?.[0] || null;
    event.target.value = "";
    setError("");
    if (!next) return;
    if (!isXlsxFile(next)) {
      setError("Please upload a valid .xlsx file.");
      return;
    }
    setFile(next);
  }, []);

  const clearFile = useCallback(() => {
    setFile(null);
    setParsed(null);
    setMatched([]);
    setUnmatched([]);
    setMatchedSections([]);
    setUnmatchedSections([]);
    setPrCount(0);
    setPrItemCount(0);
    setTotalParsedCount(0);
    setVendorCompareMap({});
    setComparisonId(null);
    setStatus("pending");
    setUploadedAt(null);
    setError("");
  }, []);

  const fetchVendorCompareMap = useCallback(async (vendorsOverride = null) => {
    setCatalogLoading(true);
    try {
      const vendors = Array.isArray(vendorsOverride) ? vendorsOverride : (parsed?.vendors || []);
      if (vendors.length === 0) return;

      const results = await Promise.all(
        vendors.map(async (vendor) => {
          const result = await api.compareVendorPriceListItems({
            limit: 500,
            offset: 0,
            project_id: activeProjectId ? Number(activeProjectId) : undefined,
            q: vendor.name,
          });
          const groups = Array.isArray(result?.data?.groups) ? result.data.groups : [];
          return { vendorName: vendor.name, success: Boolean(result?.success), groups };
        })
      );

      const vendorMap = {};
      results.forEach((entry) => {
        vendorMap[entry.vendorName] = { success: entry.success, groups: entry.groups };
      });
      setVendorCompareMap(vendorMap);
    } finally {
      setCatalogLoading(false);
    }
  }, [activeProjectId, parsed?.vendors]);

  const applyPrMatching = useCallback((parsedModel, prItems) => {
    const matchedFlat = [];
    const unmatchedFlat = [];
    const matchedGrouped = [];
    const unmatchedGrouped = [];

    const sections = Array.isArray(parsedModel?.sections) ? parsedModel.sections : [];
    let total = 0;

    sections.forEach((section) => {
      const items = Array.isArray(section?.items) ? section.items : [];
      const matchedItems = [];
      const unmatchedItems = [];

      items.forEach((item) => {
        total += 1;
        const match = matchAgainstPrItems(item, prItems);
        const enriched = { ...item, ...match };
        if (match.matchStatus === "matched") {
          matchedItems.push(enriched);
          matchedFlat.push({ ...enriched, sectionLabel: section.sectionLabel, sectionDescription: section.sectionDescription });
        } else {
          unmatchedItems.push(enriched);
          unmatchedFlat.push({ ...enriched, sectionLabel: section.sectionLabel, sectionDescription: section.sectionDescription });
        }
      });

      if (matchedItems.length > 0) {
        matchedGrouped.push({
          sectionLabel: section.sectionLabel,
          sectionDescription: section.sectionDescription,
          items: matchedItems,
        });
      }
      if (unmatchedItems.length > 0) {
        unmatchedGrouped.push({
          sectionLabel: section.sectionLabel,
          sectionDescription: section.sectionDescription,
          items: unmatchedItems,
        });
      }
    });

    setTotalParsedCount(total);
    setMatched(matchedFlat);
    setUnmatched(unmatchedFlat);
    setMatchedSections(matchedGrouped);
    setUnmatchedSections(unmatchedGrouped);
  }, []);

  const handleUploadAndParse = useCallback(async () => {
    if (!canUpload || !file) return;
    setError("");
    setParsing(true);
    setUploading(true);

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: "array" });
      const parsedModel = parseComparisonWorkbook(workbook);

      const uploadResult = await api.uploadVendorComparisonFiles([file]);
      if (!uploadResult?.success) {
        setError(uploadResult?.error || "Upload failed.");
        return;
      }
      const uploadedFiles = Array.isArray(uploadResult.data) ? uploadResult.data : Array.isArray(uploadResult.data?.data) ? uploadResult.data.data : [];
      const primary = uploadedFiles[0] || null;
      if (!primary?.file_url && !primary?.url) {
        setError("Upload succeeded but server did not return a file URL.");
        return;
      }

      const createPayload = {
        project_id: Number(activeProjectId),
        pricelist: (Array.isArray(parsedModel?.sections) ? parsedModel.sections : [])
          .flatMap((section) => (Array.isArray(section?.items) ? section.items : []))
          .flatMap((item) => {
            const itemDescription = String(item?.description || "").trim();
            if (!itemDescription) return [];
            const vendorData = Array.isArray(item?.vendorData) ? item.vendorData : [];
            return vendorData
              .map((vd) => {
                const vendorName = String(vd?.vendorName || "").trim();
                if (!vendorName) return null;
                return {
                  vendor_name: vendorName,
                  item_description: itemDescription,
                  total_qty: item?.totalQty ?? null,
                  unit: String(item?.uom || "").trim(),
                  hsn: String(item?.hsnCode || "").trim(),
                  rate: vd?.rate ?? null,
                  amount: vd?.amount ?? null,
                };
              })
              .filter(Boolean);
          }),
        upload_document: [
          {
            file_name: primary.file_name || primary.name || file.name,
            file_url: primary.file_url || primary.url,
          },
        ],
      };

      const approvedVendorName = (() => {
        const pricelist = Array.isArray(createPayload.pricelist) ? createPayload.pricelist : [];
        if (pricelist.length === 0) return "";
        const totals = new Map();
        pricelist.forEach((row) => {
          const vendorName = String(row?.vendor_name || "").trim();
          if (!vendorName) return;
          const amount = Number(row?.amount);
          const qty = Number(row?.total_qty);
          const rate = Number(row?.rate);
          const computed = Number.isFinite(amount) ? amount : (Number.isFinite(qty) && Number.isFinite(rate) ? qty * rate : 0);
          totals.set(vendorName, (totals.get(vendorName) || 0) + (Number.isFinite(computed) ? computed : 0));
        });
        const entries = Array.from(totals.entries()).filter(([, total]) => Number.isFinite(total));
        if (entries.length === 0) return "";
        entries.sort((a, b) => a[1] - b[1]);
        return entries[0]?.[0] || "";
      })();

      const finalPayload = approvedVendorName
        ? {
          ...createPayload,
          pricelist: createPayload.pricelist.filter(
            (row) => String(row?.vendor_name || "").trim() === approvedVendorName
          ),
        }
        : createPayload;

      const createResult = await api.createVendorComparison(finalPayload);
      if (!createResult?.success) {
        setError(createResult?.error || "Failed to create vendor comparison record.");
        return;
      }
      const created = createResult.data || {};
      const id = created?.id ?? created?.vendor_comparison_id ?? created?.comparison_id ?? null;
      if (id != null) setComparisonId(String(id));
      setStatus(String(created?.status || "pending"));
      setUploadedAt(created?.created_at || created?.createdAt || new Date().toISOString());

      setParsed(parsedModel);

      await fetchVendorCompareMap(parsedModel.vendors);

      const prResult = await api.getPrsByProject(Number(activeProjectId));
      const prList = Array.isArray(prResult?.data)
        ? prResult.data
        : Array.isArray(prResult?.data?.data)
          ? prResult.data.data
          : Array.isArray(prResult?.data?.rows)
            ? prResult.data.rows
            : [];
      setPrCount(prList.length);
      const uniquePrItems = extractUniquePrItems(prList);
      setPrItemCount(uniquePrItems.length);
      applyPrMatching(parsedModel, uniquePrItems);
    } catch (e) {
      setError(e?.message || "Unable to parse this Excel file.");
    } finally {
      setUploading(false);
      setParsing(false);
    }
  }, [activeProjectId, applyPrMatching, canUpload, fetchVendorCompareMap, file]);

  const updateStatus = useCallback(
    async (nextStatus) => {
      if (!comparisonId) return;
      setError("");
      try {
        const result = await api.updateVendorComparison(comparisonId, { status: nextStatus });
        if (!result?.success) {
          setError(result?.error || "Unable to update status.");
          return;
        }
        setStatus(nextStatus);
        navigate("/vendor-comparison");
      } catch {
        setError("Unable to update status.");
      }
    },
    [comparisonId, navigate]
  );

  const deleteRecord = useCallback(async () => {
    if (!comparisonId) return;
    setError("");
    try {
      const result = await api.deleteVendorComparison(comparisonId);
      if (!result?.success) {
        setError(result?.error || "Unable to delete.");
        return;
      }
      clearFile();
    } catch {
      setError("Unable to delete.");
    }
  }, [clearFile, comparisonId]);

  const matchTypeBadge = useCallback((type) => {
    const t = String(type || "").toLowerCase();
    if (t === "exact") return { label: "Exact", className: "bg-emerald-100 text-emerald-900 border-emerald-200" };
    if (t === "normalized") return { label: "Normalized", className: "bg-sky-100 text-sky-900 border-sky-200" };
    if (t === "substring") return { label: "Partial", className: "bg-amber-100 text-amber-900 border-amber-200" };
    if (t === "token") return { label: "Token", className: "bg-amber-100 text-amber-900 border-amber-200" };
    return { label: "-", className: "bg-muted text-muted-foreground border-border" };
  }, []);

  return (
    <div className={`${containerClass} pb-24`}>
      <style>{`
        @media print {
          .vc-actionbar { display: none !important; }
          .vc-upload { display: none !important; }
          body { background: white !important; }
        }
      `}</style>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Vendor Comparison Upload</h1>
          <p className="text-muted-foreground mt-2">
            Upload an Excel vendor comparison sheet (.xlsx), review it exactly like the Excel, match items to catalog, then approve or reject.
          </p>
        </div>
        <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
          <Button variant="outline" onClick={() => navigate(-1)} className="w-full sm:w-auto">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back
          </Button>
          {comparisonId ? (
            <Badge className={statusBadge.badgeClass}>Status: {statusBadge.label}</Badge>
          ) : (
            <Badge variant="outline">Project: {projectId || "All"}</Badge>
          )}
        </div>
      </div>

      <Card className="vc-upload">
        <CardHeader>
          <CardTitle>Upload Excel</CardTitle>
          <CardDescription>Accepts only `.xlsx` files in the defined vendor comparison format.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-2">
              <div className="text-sm font-medium">Project</div>
              <Select value={activeProjectId || ""} onValueChange={(value) => setActiveProjectId(value)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a project" />
                </SelectTrigger>
                <SelectContent>
                  {projectOptions.map((p) => (
                    <SelectItem key={`project-${p.id}`} value={p.id}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="text-sm font-medium">File</div>
              <div
                className="group relative flex min-h-[108px] cursor-pointer items-center justify-center rounded-lg border border-dashed bg-background p-4 text-center transition hover:border-primary/60 hover:shadow-sm"
                onClick={handlePickFile}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const dropped = e.dataTransfer.files?.[0] || null;
                  if (!dropped) return;
                  if (!isXlsxFile(dropped)) {
                    setError("Please drop a valid .xlsx file.");
                    return;
                  }
                  setFile(dropped);
                }}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  className="hidden"
                  onChange={handleFileChange}
                />
                <div className="space-y-1">
                  <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary transition group-hover:bg-primary/15">
                    <UploadCloud className="h-5 w-5" />
                  </div>
                  <div className="text-sm font-medium">Drag & drop an .xlsx, or click to browse</div>
                  <div className="text-xs text-muted-foreground">Excel only · 1 file</div>
                </div>
              </div>
            </div>
          </div>

          {file ? (
            <div className="flex flex-col gap-2 rounded-lg border bg-card/50 p-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <div className="truncate text-sm font-medium">{file.name}</div>
                <div className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</div>
              </div>
              <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
                <Button variant="ghost" onClick={clearFile} className="w-full sm:w-auto">
                  <Trash2 className="mr-2 h-4 w-4" /> Remove
                </Button>
                <Button
                  onClick={handleUploadAndParse}
                  disabled={!canUpload}
                  className="w-full sm:w-auto bg-gradient-to-r from-primary to-sky-500 text-white shadow hover:opacity-95"
                >
                  {parsing || uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                  Upload & Parse
                </Button>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {error ? (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      {parsed ? (
        <div className="space-y-4">
          <div className="rounded-lg border bg-background p-4">
            <div className="grid gap-3 md:grid-cols-5">
              <div>
                <div className="text-xs text-muted-foreground">Company Name</div>
                <div className="font-medium">{parsed.meta.companyName || "-"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Project Name</div>
                <div className="font-medium">{parsed.meta.projectName || "-"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Indent No</div>
                <div className="font-medium">{parsed.meta.indentNo || "-"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Indent Date</div>
                <div className="font-medium">{parsed.meta.indentDate || "-"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Comparison Date</div>
                <div className="font-medium">{parsed.meta.comparisonDate || "-"}</div>
              </div>
            </div>
          </div>

          <div className="rounded-lg border bg-background p-3 text-sm">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-muted-foreground">
                <span className="font-medium text-foreground">{matched.length}</span> of{" "}
                <span className="font-medium text-foreground">{totalParsedCount}</span> items matched to PR products ·{" "}
                <span className="font-medium text-foreground">{unmatched.length}</span> unmatched
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">Project: {activeProjectId || "—"}</Badge>
                <Badge variant="outline">Matched against {prCount} PRs</Badge>
                <Badge variant="outline">Unique PR items: {prItemCount}</Badge>
              </div>
            </div>
          </div>

          {/** Matched table */}
          <div className="rounded-lg border overflow-hidden">
            <div className="px-4 py-3 text-sm font-semibold text-white" style={{ background: "#047857" }}>
              ✅ Matched Items ({matched.length}) — found in Purchase Requests
            </div>
            <div className="overflow-auto bg-white">
              <table className="w-full border-collapse text-sm">
                <thead className="sticky top-0 z-20">
                  <tr>
                    <th colSpan={5} style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-left font-bold text-white">
                      &nbsp;
                    </th>
                    {parsed.vendors.map((vendor, i) => {
                      const isLowestTotal = vendorTotals.minIndex === i;
                      const isHighestTotal = vendorTotals.maxIndex === i;
                      const bg = isLowestTotal ? "#047857" : isHighestTotal ? "#be123c" : NAVY;
                      return (
                        <th
                          key={`matched-vendor-${vendor.name}-${i}`}
                          colSpan={2}
                          className="border px-3 py-2 text-center font-bold text-white"
                          style={{ background: bg }}
                        >
                          <div className="truncate">{vendor.name}</div>
                          {vendor.subLabel ? <div className="mt-0.5 text-xs italic text-white/80">{vendor.subLabel}</div> : null}
                        </th>
                      );
                    })}
                    <th rowSpan={2} style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-left font-bold text-white min-w-[280px]">
                      PR Match
                    </th>
                  </tr>
                  <tr>
                    {["Sr. No.", "HSN Code", "Item Description", "Total Qty", "UOM"].map((h) => (
                      <th
                        key={`matched-head-${h}`}
                        style={{ background: NAVY }}
                        className={`border border-white/10 px-3 py-2 text-left font-bold text-white ${
                          h === "Sr. No."
                            ? "sticky left-0 z-30 w-[76px]"
                            : h === "HSN Code"
                              ? "sticky left-[76px] z-30 w-[100px]"
                              : h === "Item Description"
                                ? "sticky left-[176px] z-30 min-w-[360px]"
                                : ""
                        }`}
                      >
                        {h}
                      </th>
                    ))}
                    {parsed.vendors.map((_, i) => (
                      <React.Fragment key={`matched-head-v-${i}`}>
                        <th style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-right font-bold text-white">
                          Rate
                        </th>
                        <th style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-right font-bold text-white">
                          Amount
                        </th>
                      </React.Fragment>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {matchedSections.map((section, sIdx) => (
                    <React.Fragment key={`matched-sec-${section.sectionLabel || sIdx}`}>
                      {section.sectionLabel ? (
                        <tr>
                          <td colSpan={5 + parsed.vendors.length * 2 + 1} className="border px-3 py-2 font-semibold" style={{ color: NAVY, background: "rgba(26,58,107,0.06)" }}>
                            {section.sectionLabel} — {section.sectionDescription}
                          </td>
                        </tr>
                      ) : null}
                      {(section.items || []).map((item, idx) => {
                        const isOdd = idx % 2 === 1;
                        const lowestRate = lowestRateByItem.get(item.srNo) ?? null;
                        const badge = matchTypeBadge(item.matchType);
                        return (
                          <tr key={`matched-item-${section.sectionLabel}-${item.srNo}`} className={`${isOdd ? "bg-emerald-50/40" : "bg-white"} `}>
                            <td className={`border px-3 py-2 sticky left-0 z-10 w-[76px] font-medium ${isOdd ? "bg-emerald-50/40" : "bg-white"}`}>{item.srNo}</td>
                            <td className={`border px-3 py-2 sticky left-[76px] z-10 w-[100px] ${isOdd ? "bg-emerald-50/40" : "bg-white"}`}>{item.hsnCode || "-"}</td>
                            <td className={`border px-3 py-2 sticky left-[176px] z-10 min-w-[360px] ${isOdd ? "bg-emerald-50/40" : "bg-white"}`}>{item.description || "-"}</td>
                            <td className="border px-3 py-2 text-right font-mono">{item.totalQty == null ? "-" : formatNumber(item.totalQty)}</td>
                            <td className="border px-3 py-2">{item.uom || "-"}</td>
                            {(item.vendorData || []).map((v, vIdx) => {
                              const isLowest = lowestRate != null && v.rate != null && v.rate === lowestRate;
                              return (
                                <React.Fragment key={`matched-vd-${item.srNo}-${vIdx}`}>
                                  <td className={`border px-3 py-2 text-right font-mono ${isLowest ? "bg-emerald-100 text-emerald-900" : ""}`}>{v.rate == null ? "-" : formatInr(v.rate)}</td>
                                  <td className="border px-3 py-2 text-right font-mono">{v.amount == null ? "-" : formatInr(v.amount)}</td>
                                </React.Fragment>
                              );
                            })}
                            <td className="border px-3 py-2">
                              <div className="text-xs text-muted-foreground">PR #{item.matchedPrItem?.pr_id ?? "-"}</div>
                              <div className="mt-1 text-sm font-medium">{item.matchedPrItem?.material_description || "-"}</div>
                              <span className={`mt-1 inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] ${badge.className}`}>{badge.label}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/** Unmatched table */}
          <div className="rounded-lg border overflow-hidden">
            <div className="px-4 py-3 text-sm font-semibold text-white" style={{ background: "#b45309" }}>
              ⚠️ Unmatched Items ({unmatched.length}) — not found in any Purchase Request
            </div>
            <div className="overflow-auto bg-white">
              <table className="w-full border-collapse text-sm">
                <thead className="sticky top-0 z-20">
                  <tr>
                    <th colSpan={5} style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-left font-bold text-white">
                      &nbsp;
                    </th>
                    {parsed.vendors.map((vendor, i) => (
                      <th key={`unmatched-vendor-${vendor.name}-${i}`} colSpan={2} className="border px-3 py-2 text-center font-bold text-white" style={{ background: NAVY }}>
                        <div className="truncate">{vendor.name}</div>
                        {vendor.subLabel ? <div className="mt-0.5 text-xs italic text-white/80">{vendor.subLabel}</div> : null}
                      </th>
                    ))}
                    <th rowSpan={2} style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-left font-bold text-white min-w-[280px]">
                      PR Match
                    </th>
                  </tr>
                  <tr>
                    {["Sr. No.", "HSN Code", "Item Description", "Total Qty", "UOM"].map((h) => (
                      <th
                        key={`unmatched-head-${h}`}
                        style={{ background: NAVY }}
                        className={`border border-white/10 px-3 py-2 text-left font-bold text-white ${
                          h === "Sr. No."
                            ? "sticky left-0 z-30 w-[76px]"
                            : h === "HSN Code"
                              ? "sticky left-[76px] z-30 w-[100px]"
                              : h === "Item Description"
                                ? "sticky left-[176px] z-30 min-w-[360px]"
                                : ""
                        }`}
                      >
                        {h}
                      </th>
                    ))}
                    {parsed.vendors.map((_, i) => (
                      <React.Fragment key={`unmatched-head-v-${i}`}>
                        <th style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-right font-bold text-white">
                          Rate
                        </th>
                        <th style={{ background: NAVY }} className="border border-white/10 px-3 py-2 text-right font-bold text-white">
                          Amount
                        </th>
                      </React.Fragment>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {unmatchedSections.map((section, sIdx) => (
                    <React.Fragment key={`unmatched-sec-${section.sectionLabel || sIdx}`}>
                      {section.sectionLabel ? (
                        <tr>
                          <td colSpan={5 + parsed.vendors.length * 2 + 1} className="border px-3 py-2 font-semibold" style={{ color: NAVY, background: "rgba(26,58,107,0.06)" }}>
                            {section.sectionLabel} — {section.sectionDescription}
                          </td>
                        </tr>
                      ) : null}
                      {(section.items || []).map((item, idx) => {
                        const isOdd = idx % 2 === 1;
                        const lowestRate = lowestRateByItem.get(item.srNo) ?? null;
                        return (
                          <tr key={`unmatched-item-${section.sectionLabel}-${item.srNo}`} className={isOdd ? "bg-amber-50/40" : "bg-white"}>
                            <td className={`border px-3 py-2 sticky left-0 z-10 w-[76px] font-medium border-l-4 border-amber-400 ${isOdd ? "bg-amber-50/40" : "bg-white"}`}>{item.srNo}</td>
                            <td className={`border px-3 py-2 sticky left-[76px] z-10 w-[100px] ${isOdd ? "bg-amber-50/40" : "bg-white"}`}>{item.hsnCode || "-"}</td>
                            <td className={`border px-3 py-2 sticky left-[176px] z-10 min-w-[360px] ${isOdd ? "bg-amber-50/40" : "bg-white"}`}>{item.description || "-"}</td>
                            <td className="border px-3 py-2 text-right font-mono">{item.totalQty == null ? "-" : formatNumber(item.totalQty)}</td>
                            <td className="border px-3 py-2">{item.uom || "-"}</td>
                            {(item.vendorData || []).map((v, vIdx) => {
                              const isLowest = lowestRate != null && v.rate != null && v.rate === lowestRate;
                              return (
                                <React.Fragment key={`unmatched-vd-${item.srNo}-${vIdx}`}>
                                  <td className={`border px-3 py-2 text-right font-mono ${isLowest ? "bg-emerald-100 text-emerald-900" : ""}`}>{v.rate == null ? "-" : formatInr(v.rate)}</td>
                                  <td className="border px-3 py-2 text-right font-mono">{v.amount == null ? "-" : formatInr(v.amount)}</td>
                                </React.Fragment>
                              );
                            })}
                            <td className="border px-3 py-2 text-muted-foreground">
                              — No match found
                            </td>
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : null}

      <div className="vc-actionbar fixed bottom-0 left-0 right-0 z-40 border-t bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1400px] flex-col gap-2 p-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-2">
            <Button variant="outline" onClick={() => navigate(-1)}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <Badge className={statusBadge.badgeClass}>Status: {statusBadge.label}</Badge>
            {comparisonId ? <Badge variant="outline">ID: {comparisonId}</Badge> : null}
            <div className="text-xs text-muted-foreground sm:ml-2">
              {file ? <span className="mr-2">File: {file.name}</span> : null}
              {uploadedAt ? <span>Uploaded: {new Date(uploadedAt).toLocaleString()}</span> : null}
            </div>
          </div>
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
            <Button
              onClick={() => updateStatus("rejected")}
              disabled={!comparisonId}
              className="border border-rose-200 bg-rose-50 text-rose-900 hover:bg-rose-100"
            >
              <XCircle className="mr-2 h-4 w-4" /> Reject
            </Button>
            <Button
              onClick={() => updateStatus("approved")}
              disabled={!comparisonId}
              className="bg-emerald-600 text-white hover:bg-emerald-700"
            >
              <CheckCircle2 className="mr-2 h-4 w-4" /> Approve
            </Button>
            <Button variant="outline" onClick={deleteRecord} disabled={!comparisonId}>
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
