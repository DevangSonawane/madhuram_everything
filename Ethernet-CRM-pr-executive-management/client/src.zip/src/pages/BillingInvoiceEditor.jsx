import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import ProjectSpreadsheet from "@/components/ProjectSpreadsheet";
import { Button } from "@/components/ui/button";
import { useProject } from "@/contexts/useProject";

export default function BillingInvoiceEditor() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const backHref = projectId ? `/${projectId}/billing` : "/billing";
  const { selectedProject, projects } = useProject();

  const resolvedProjectId = React.useMemo(() => {
    const toIntOrNull = (value) => {
      if (value == null) return null;
      const n = Number(value);
      if (!Number.isFinite(n)) return null;
      if (!Number.isInteger(n)) return null;
      if (n <= 0) return null;
      return n;
    };

    const routeKey = projectId != null ? String(projectId).trim() : "";
    const fromRoute = toIntOrNull(routeKey);
    if (fromRoute) return fromRoute;

    const fromSelected = toIntOrNull(selectedProject?.project_id ?? selectedProject?.id);
    if (fromSelected) return fromSelected;

    if (routeKey && Array.isArray(projects) && projects.length > 0) {
      const match = projects.find((p) => {
        const keys = [
          p?.slug,
          p?.project_id,
          p?.id,
          p?.project_name,
          p?.name,
        ]
          .map((x) => String(x ?? "").trim().toLowerCase())
          .filter(Boolean);
        return keys.includes(routeKey.toLowerCase());
      });
      return toIntOrNull(match?.project_id ?? match?.id);
    }

    return null;
  }, [projectId, projects, selectedProject?.id, selectedProject?.project_id]);

  return (
    <div className="fixed inset-0 z-50 bg-background">
      <div className="absolute left-4 top-4 z-50">
        <Button variant="outline" onClick={() => navigate(backHref)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
      </div>
      <div className="h-full w-full pt-0">
        <ProjectSpreadsheet
          projectId={resolvedProjectId}
          title="Billing Invoice Workbook"
          workbookTitle="Madhuram Sheet"
          showHeader={false}
          showDownload
          wrapperClassName="h-full w-full"
          bodyClassName="relative h-full w-full"
        />
      </div>
    </div>
  );
}
