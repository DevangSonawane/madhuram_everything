import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { api } from "@/lib/api";
import { Loader2, ArrowLeft, Eye, FileText, Image as ImageIcon, Pencil } from "lucide-react";

export default function SamplePreview() {
  const { id, projectId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [sample, setSample] = useState(null);
  const [attachmentOpen, setAttachmentOpen] = useState(false);
  const [displayItems, setDisplayItems] = useState([]);
  const [relatedLoading, setRelatedLoading] = useState(false);
  const [relatedPrs, setRelatedPrs] = useState([]);
  const [relatedPos, setRelatedPos] = useState([]);
  const [relatedDcs, setRelatedDcs] = useState([]);
  const [relatedDcsByPoId, setRelatedDcsByPoId] = useState(() => new Map());

  const parseMaybe = (val, fallback) => {
    if (typeof val === 'string') {
      try {
        return JSON.parse(val);
      } catch {
        return fallback;
      }
    }
    return val ?? fallback;
  };

  const pickSampleFilePath = (value) => {
    if (!value) return "";
    if (typeof value === "string") {
      const trimmed = value.trim();
      if (!trimmed) return "";
      try {
        const parsed = JSON.parse(trimmed);
        return pickSampleFilePath(parsed);
      } catch {
        return trimmed;
      }
    }
    if (Array.isArray(value)) {
      const first = value.find((entry) => typeof entry === "string" && entry.trim());
      return first ? first.trim() : "";
    }
    if (typeof value === "object") {
      const candidates = [
        value.filePath,
        value.file_path,
        value.path,
        value.url,
        value.sample_file,
        value.sampleFile,
      ];
      return pickSampleFilePath(candidates.find(Boolean));
    }
    return "";
  };

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await api.getSampleById(id);
        if (!res.success) {
          setSample(null);
          return;
        }

        const raw = res.data;
        const s = Array.isArray(raw)
          ? raw.find((row) => String(row?.sample_id ?? row?.id ?? "") === String(id)) || raw[0]
          : raw?.sample || raw?.data || raw;
        if (!s) {
          setSample(null);
          return;
        }

        const loc = parseMaybe(s.location, {});
        const items = parseMaybe(s.item_description ?? s.items ?? s.item_descriptions, []);
        const adds = parseMaybe(s.add_fields, []);
        const sampleFileRaw =
          s.sample_file ??
          s.sample_file_path ??
          s.sample_files ??
          s.files ??
          s.file_path ??
          s.attachment ??
          s.attachment_path ??
          "";
        const sampleFile = pickSampleFilePath(sampleFileRaw);

        const toDisplayItems = (rawItems) => {
          const list = Array.isArray(rawItems) ? rawItems : [];
          if (list.length === 0) return [];

          const fieldVal = (row, key) => {
            const fields = parseMaybe(row?.add_fields, []);
            if (!Array.isArray(fields)) return "";
            const found = fields.find((f) => String(f?.key || "").trim() === key);
            return found?.value ?? "";
          };

          // If items are stored as { add_fields: [...] } rows (Samples create flow), normalize for preview table.
          const looksLikeAddFields = list.some((row) => row && typeof row === "object" && Array.isArray(row.add_fields));
          if (looksLikeAddFields) {
            return list.map((row, index) => {
              const sr = row?.sr_no ?? row?.srno ?? row?.srNo ?? String(index + 1);
              const description =
                fieldVal(row, "description") ||
                fieldVal(row, "item") ||
                fieldVal(row, "material_description") ||
                "";
              const qty =
                fieldVal(row, "selected_qty") ||
                fieldVal(row, "qty") ||
                fieldVal(row, "quantity") ||
                "";
              const rate = fieldVal(row, "rate") || "";
              const amount = fieldVal(row, "amount") || fieldVal(row, "value") || "";
              const computedValue = (() => {
                const q = Number(String(qty).replace(/,/g, "").trim());
                const r = Number(String(rate).replace(/,/g, "").trim());
                if (Number.isFinite(q) && Number.isFinite(r)) return String(q * r);
                return "";
              })();
              return {
                sr_no: sr,
                description,
                quantity: qty,
                value: computedValue || amount,
              };
            });
          }

          // Otherwise assume items are already normalized.
          return list.map((row, index) => ({
            sr_no: row?.sr_no ?? row?.srno ?? row?.srNo ?? String(index + 1),
            description: row?.description ?? row?.material_description ?? row?.item ?? row?.name ?? "",
            quantity: row?.quantity ?? row?.qty ?? row?.req_qty ?? "",
            value: row?.value ?? row?.amount ?? "",
          }));
        };

        const normalizedDisplayItems = toDisplayItems(items);
        setDisplayItems(normalizedDisplayItems);

        setSample({
          sample_id: s.sample_id || s.id,
          project_id: s.project_id,
          building_name: s.building_name || "",
          site_name: s.site_name || "",
          work_done: s.work_done || "",
          sample_file: sampleFile,
          location: loc && typeof loc === 'object' ? loc : {},
          item_description: Array.isArray(items) ? items : [],
          add_fields: Array.isArray(adds) ? adds : [],
          created_at: s.created_at,
          updated_at: s.updated_at,
        });
      } catch {
        setSample(null);
        setDisplayItems([]);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id, projectId]);

  useEffect(() => {
    const loadRelated = async () => {
      const sampleId = sample?.sample_id;
      const pid = sample?.project_id;
      if (!sampleId || !pid) {
        setRelatedPrs([]);
        setRelatedPos([]);
        setRelatedDcs([]);
        setRelatedDcsByPoId(new Map());
        return;
      }

      setRelatedLoading(true);
      try {
        // Prefer the dedicated relationship endpoint so the preview stays consistent with backend links.
        const backRes = await api.getBackpathBySample(sampleId, { page: 1, limit: 200 });
        const payload = backRes?.success ? (backRes.data ?? backRes) : null;
        const prs = Array.isArray(payload?.prs) ? payload.prs : [];
        const pos = Array.isArray(payload?.pos) ? payload.pos : [];
        const dcs = Array.isArray(payload?.dcs) ? payload.dcs : [];
        setRelatedPrs(prs);
        setRelatedPos(pos);
        setRelatedDcs(dcs);

        const poIdSet = new Set(pos.map((po) => String(po?.po_id ?? po?.id ?? "")).filter(Boolean));
        const map = new Map();
        dcs.forEach((dc) => {
          const poId = String(dc?.po_id ?? dc?.poId ?? "");
          if (!poId) return;
          // If we got a PO list, only attach DCs that belong to those POs.
          if (poIdSet.size > 0 && !poIdSet.has(poId)) return;
          const list = map.get(poId) || [];
          list.push(dc);
          map.set(poId, list);
        });
        setRelatedDcsByPoId(map);
      } finally {
        setRelatedLoading(false);
      }
    };
    loadRelated();
  }, [sample?.sample_id, sample?.project_id]);

  const getConnectedByLabel = (pr) => {
    const raw =
      pr?.connected_by ||
      pr?.connectedBy ||
      pr?.linked_by ||
      pr?.linkedBy ||
      pr?.created_by_name ||
      pr?.createdByName ||
      pr?.created_by ||
      pr?.createdBy ||
      pr?.user_name ||
      pr?.username ||
      pr?.user ||
      pr?.created_user ||
      pr?.createdUser ||
      "";
    if (!raw) return "-";
    if (typeof raw === "string") return raw.trim() || "-";
    if (typeof raw === "object") {
      const name = raw?.name || raw?.username || raw?.email || raw?.user_name || "";
      return String(name || "-").trim() || "-";
    }
    return String(raw).trim() || "-";
  };

  const fileUrl = sample?.sample_file ? api.getApiFileUrl(sample.sample_file) : null;
  const lower = String(sample?.sample_file || "").toLowerCase();
  const fileName = sample?.sample_file ? String(sample.sample_file).split('/').pop() : '';
  const isImage = lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.gif') || lower.endsWith('.webp');
  const isPdf = lower.endsWith('.pdf');
  const fileTypeLabel = isImage ? 'Image' : isPdf ? 'PDF' : 'File';
  const formatDate = (value) => {
    if (!value) return '-';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return String(value);
    return d.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
  };

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 px-4 pb-8 sm:px-6 lg:px-10">
      <div className="rounded-3xl border border-border/60 bg-gradient-to-r from-background via-background to-muted/40 p-6 shadow-sm sm:p-7">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Badge variant="outline" className="mb-3 border-primary/30 bg-primary/5 text-primary">Sample Management</Badge>
            <h1 className="text-3xl font-bold tracking-tight">Sample Preview</h1>
            <p className="text-muted-foreground mt-2">Detailed view and attachment inspection</p>
          </div>
          <div className="flex w-full gap-2 sm:w-auto">
            <Button variant="outline" onClick={() => navigate(-1)} className="w-full sm:w-auto">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <Button onClick={() => navigate(`/${projectId}/samples/edit/${id}`)} className="w-full sm:w-auto" disabled={!sample}>
              <Pencil className="mr-2 h-4 w-4" /> Edit
            </Button>
          </div>
        </div>
      </div>

      <Card className="border-border/60 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle>Sample #{id}</CardTitle>
              <CardDescription>Preview data synced from sample record</CardDescription>
            </div>
            {sample?.sample_id && (
              <Badge variant="secondary" className="px-3 py-1">ID: {sample.sample_id}</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-14">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : !sample ? (
            <div className="rounded-xl border border-dashed p-8 text-center text-muted-foreground">Sample not found</div>
          ) : (
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="space-y-6 lg:col-span-8">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Project</div>
                    <div className="mt-1 text-sm font-semibold">{sample.project_id || '-'}</div>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Created</div>
                    <div className="mt-1 text-sm font-semibold">{formatDate(sample.created_at)}</div>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Updated</div>
                    <div className="mt-1 text-sm font-semibold">{formatDate(sample.updated_at)}</div>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Building</div>
                    <div className="mt-1 text-sm font-semibold">{sample.building_name || '-'}</div>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Site</div>
                    <div className="mt-1 text-sm font-semibold">{sample.site_name || '-'}</div>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <div className="text-xs uppercase tracking-wide text-muted-foreground">Work Done</div>
                    <div className="mt-1 text-sm font-semibold">{sample.work_done || '-'}</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Location</div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    <div className="rounded-lg border p-3 text-sm">{sample?.location?.floor || sample?.location?.address_line1 || '-'}</div>
                    <div className="rounded-lg border p-3 text-sm">{sample?.location?.block || sample?.location?.city || '-'}</div>
                    <div className="rounded-lg border p-3 text-sm">{sample?.location?.wing || sample?.location?.state || '-'}</div>
                    <div className="rounded-lg border p-3 text-sm">{sample?.location?.coordinates || sample?.location?.country || '-'}</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Item Description</div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[100px]">Sr No</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead className="w-[160px] text-right">Quantity</TableHead>
                        <TableHead className="w-[160px] text-right">Value</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {displayItems.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="py-8 text-center text-muted-foreground">No item rows available</TableCell>
                        </TableRow>
                      ) : (
                        displayItems.map((row, idx) => (
                          <TableRow key={idx}>
                            <TableCell>{row.sr_no || '-'}</TableCell>
                            <TableCell>{row.description || '-'}</TableCell>
                            <TableCell className="text-right">{row.quantity || '-'}</TableCell>
                            <TableCell className="text-right">{row.value || '-'}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Additional Fields</div>
                  {(sample.add_fields || []).length === 0 ? (
                    <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">No additional fields</div>
                  ) : (
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      {(sample.add_fields || []).map((f, idx) => (
                        <div key={idx} className="rounded-lg border p-3">
                          <div className="text-xs uppercase tracking-wide text-muted-foreground">{f.key || 'Field'}</div>
                          <div className="mt-1 text-sm font-medium">{f.value || '-'}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">PR / PO / DC</div>
                  {relatedLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin" /> Loading related records…
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Card className="border-border/60">
                        <CardHeader className="pb-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <CardTitle className="text-sm">Purchase Requests</CardTitle>
                            <Badge variant="secondary">{relatedPrs.length} PR(s)</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                        {relatedPrs.length === 0 ? (
                          <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                            No PR linked to this sample.
                          </div>
                        ) : (
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="w-[140px]">PR No</TableHead>
                                <TableHead className="w-[160px]">Date</TableHead>
                                <TableHead className="w-[220px]">Connected By</TableHead>
                                <TableHead>Project</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {relatedPrs.map((pr, idx) => (
                                <TableRow key={String(pr?.pr_id ?? pr?.id ?? idx)}>
                                  <TableCell className="font-medium">
                                    {pr?.workorder_no || pr?.indent_no || pr?.pr_no || pr?.pr_number || pr?.pr_id || pr?.id || "-"}
                                  </TableCell>
                                  <TableCell>{pr?.date ? formatDate(pr.date) : "-"}</TableCell>
                                  <TableCell>{getConnectedByLabel(pr)}</TableCell>
                                  <TableCell className="text-muted-foreground">{pr?.project_name || "-"}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        )}
                        </CardContent>
                      </Card>

                      <Card className="border-border/60">
                        <CardHeader className="pb-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <CardTitle className="text-sm">Purchase Orders / DC</CardTitle>
                            <Badge variant="secondary">{relatedPos.length} PO(s)</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                        {relatedPos.length === 0 ? (
                          <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                            No Purchase Orders linked to this sample.
                          </div>
                        ) : relatedPrs.length > 0 ? (
                          <div className="space-y-4">
                            {(() => {
                              const prIndentFor = (pr) =>
                                String(pr?.workorder_no || pr?.indent_no || pr?.pr_no || pr?.pr_number || pr?.pr_id || pr?.id || "").trim();
                              const poIndentFor = (po) => String(po?.indent_no || "").trim();

                              const groups = relatedPrs.map((pr) => {
                                const indent = prIndentFor(pr);
                                const rows = indent
                                  ? relatedPos.filter((po) => poIndentFor(po) && poIndentFor(po) === indent)
                                  : [];
                                return { pr, indent, pos: rows };
                              });

                              const usedPoIds = new Set(
                                groups.flatMap((g) => g.pos.map((po) => String(po?.po_id ?? po?.id ?? "")).filter(Boolean))
                              );
                              const otherPos = relatedPos.filter((po) => {
                                const poId = String(po?.po_id ?? po?.id ?? "");
                                if (!poId) return true;
                                return !usedPoIds.has(poId);
                              });

                              const renderPoTable = (pos) => (
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead className="w-[110px]">PR</TableHead>
                                      <TableHead className="w-[140px]">PO</TableHead>
                                      <TableHead className="w-[140px]">PO Date</TableHead>
                                      <TableHead>Vendor</TableHead>
                                      <TableHead className="w-[120px] text-right">Total</TableHead>
                                      <TableHead className="w-[110px]">Status</TableHead>
                                      <TableHead className="w-[220px]">DC</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {pos.map((po, index) => {
                                      const poId = String(po?.po_id ?? po?.id ?? "");
                                      const dcs = poId ? (relatedDcsByPoId.get(poId) || []) : [];
                                      const dcLabel = dcs.length
                                        ? dcs
                                            .map((dc) => dc?.challan_number || dc?.dc_number || dc?.dc_no || dc?.dc_id || "")
                                            .filter(Boolean)
                                            .join(", ")
                                        : "-";
                                      return (
                                        <TableRow key={poId || po?.order_no || String(index)}>
                                          <TableCell>{po?.indent_no || "-"}</TableCell>
                                          <TableCell>{po?.order_no || poId || "-"}</TableCell>
                                          <TableCell>{po?.po_date || "-"}</TableCell>
                                          <TableCell>{po?.vendor_name || "-"}</TableCell>
                                          <TableCell className="text-right">{po?.total_amount ?? "-"}</TableCell>
                                          <TableCell>{po?.status || "-"}</TableCell>
                                          <TableCell>{dcLabel}</TableCell>
                                        </TableRow>
                                      );
                                    })}
                                  </TableBody>
                                </Table>
                              );

                              return (
                                <>
                                  {groups.map(({ pr, indent, pos }) => (
                                    <div key={String(pr?.pr_id ?? pr?.id ?? indent)} className="space-y-2">
                                      <div className="flex flex-wrap items-center justify-between gap-2">
                                        <div className="text-sm font-medium">
                                          PR: {pr?.workorder_no || pr?.indent_no || pr?.pr_no || pr?.pr_number || pr?.pr_id || pr?.id || "-"}
                                        </div>
                                        <Badge variant="secondary">{pos.length} PO(s)</Badge>
                                      </div>
                                      {pos.length === 0 ? (
                                        <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                                          No PO found for this PR.
                                        </div>
                                      ) : (
                                        renderPoTable(pos)
                                      )}
                                    </div>
                                  ))}
                                  {otherPos.length > 0 ? (
                                    <div className="space-y-2">
                                      <div className="flex flex-wrap items-center justify-between gap-2">
                                        <div className="text-sm font-medium">Other PO(s)</div>
                                        <Badge variant="secondary">{otherPos.length} PO(s)</Badge>
                                      </div>
                                      {renderPoTable(otherPos)}
                                    </div>
                                  ) : null}
                                </>
                              );
                            })()}
                          </div>
                        ) : (
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="w-[110px]">PR</TableHead>
                                <TableHead className="w-[140px]">PO</TableHead>
                                <TableHead className="w-[140px]">PO Date</TableHead>
                                <TableHead>Vendor</TableHead>
                                <TableHead className="w-[120px] text-right">Total</TableHead>
                                <TableHead className="w-[110px]">Status</TableHead>
                                <TableHead className="w-[220px]">DC</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {relatedPos.map((po, index) => {
                                const poId = String(po?.po_id ?? po?.id ?? "");
                                const dcs = poId ? (relatedDcsByPoId.get(poId) || []) : [];
                                const dcLabel = dcs.length
                                  ? dcs.map((dc) => dc?.challan_number || dc?.dc_number || dc?.dc_no || dc?.dc_id || '').filter(Boolean).join(', ')
                                  : '-';
                                return (
                                  <TableRow key={poId || po?.order_no || String(index)}>
                                    <TableCell>{po?.indent_no || '-'}</TableCell>
                                    <TableCell>{po?.order_no || poId || '-'}</TableCell>
                                    <TableCell>{po?.po_date || '-'}</TableCell>
                                    <TableCell>{po?.vendor_name || '-'}</TableCell>
                                    <TableCell className="text-right">{po?.total_amount ?? '-'}</TableCell>
                                    <TableCell>{po?.status || '-'}</TableCell>
                                    <TableCell>{dcLabel}</TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        )}
                        </CardContent>
                      </Card>

                      <Card className="border-border/60">
                        <CardHeader className="pb-3">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <CardTitle className="text-sm">Delivery Challans (DC)</CardTitle>
                            <Badge variant="secondary">{relatedDcs.length} DC(s)</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          {relatedDcs.length === 0 ? (
                            <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                              No DC linked to this sample.
                            </div>
                          ) : (
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead className="w-[200px]">DC No</TableHead>
                                  <TableHead className="w-[180px]">Date</TableHead>
                                  <TableHead className="w-[140px]">Status</TableHead>
                                  <TableHead className="w-[220px]">PO</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {relatedDcs.map((dc, idx) => {
                                  const dcId = dc?.dc_id ?? dc?.id ?? idx;
                                  const dcNo = dc?.challan_number || dc?.dc_number || dc?.dc_no || dc?.dcId || dc?.dc_id || dc?.id || "-";
                                  const poId = String(dc?.po_id ?? dc?.poId ?? "").trim();
                                  const po = poId ? relatedPos.find((p) => String(p?.po_id ?? p?.id ?? "") === poId) : null;
                                  const poLabel = po ? (po?.order_no || po?.po_no || poId) : (poId || "-");
                                  const dcDate = dc?.created_at || dc?.date || dc?.dc_date || dc?.challan_date || "";
                                  return (
                                    <TableRow key={String(dcId)}>
                                      <TableCell className="font-medium">{dcNo}</TableCell>
                                      <TableCell>{dcDate ? formatDate(dcDate) : "-"}</TableCell>
                                      <TableCell>{dc?.status || "-"}</TableCell>
                                      <TableCell>{poLabel}</TableCell>
                                    </TableRow>
                                  );
                                })}
                              </TableBody>
                            </Table>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:col-span-4">
                <div className="sticky top-4 space-y-3 rounded-2xl border bg-card p-4 shadow-sm">
                  <div className="flex items-center gap-2 text-sm font-medium" >
                    {isImage ? <ImageIcon className="h-4 w-4 text-primary" /> : <FileText className="h-4 w-4 text-primary" />}
                    Attachment
                  </div>
                  {!fileUrl ? (
                    <div className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">No attachment found</div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      <Button onClick={() => setAttachmentOpen(true)} className="w-full mt-2">
                        <Eye className="mr-2 h-4 w-4" />
                        Preview Attachment
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={attachmentOpen} onOpenChange={setAttachmentOpen}>
        <DialogContent className="h-[96vh] w-[96vw] max-w-[96vw]">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <DialogTitle>Attachment Preview</DialogTitle>
              <p className="text-sm text-muted-foreground truncate">{fileName || 'Attachment'}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{fileTypeLabel}</Badge>
              <Button asChild variant="outline" size="sm">
                <a href={fileUrl} target="_blank" rel="noreferrer">Open in new tab</a>
              </Button>
            </div>
          </div>

          {!fileUrl ? (
            <div className="flex h-[78vh] items-center justify-center text-muted-foreground">No attachment</div>
          ) : (
            <div className="mt-4 rounded-xl border bg-muted/10 p-3">
              {isImage ? (
                <img src={fileUrl} alt="Sample File" className="max-h-[78vh] object-contain w-full rounded-lg" />
              ) : isPdf ? (
                <iframe src={fileUrl} className="h-[78vh] w-full rounded-lg" title="Sample Attachment Preview" />
              ) : (
                <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
                  <FileText className="h-8 w-8 text-muted-foreground" />
                  <div className="text-sm font-medium">Preview not available for this file type.</div>
                  <Button asChild>
                    <a href={fileUrl} target="_blank" rel="noreferrer">Open Attachment</a>
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
