import React, { useMemo, useState, useRef, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useProject } from '@/contexts/useProject';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Upload, Plus, CheckCircle2, Search, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Pencil, Trash2, Loader2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/api";
import { Checkbox } from "@/components/ui/checkbox";
import { formatCurrencyINR, formatNumberIN } from "@/lib/numberFormat";
import { UnitSelect, convertQuantity } from "@/components/forms/UnitSelect";
import { extractRawTextFromPdfFile } from "@/lib/boqExtractor";

const NO_FILE_KEY = "__NO_FILE__";

function inferSavedFilePath(res) {
  const data = res?.data ?? res;
  if (!data) return "";
  const candidate =
    data?.boq_file ||
    data?.boqFile ||
    data?.file ||
    data?.file_path ||
    data?.filePath ||
    data?.url ||
    data?.path ||
    "";
  return typeof candidate === "string" ? candidate : "";
}

function normalizeBoqItem(apiItem) {
  const itemCode = apiItem.item_code ?? apiItem.code ?? apiItem.item_no;
  return {
    id: apiItem.boq_id,
    boq_id: apiItem.boq_id,
    code: apiItem.item_no ?? itemCode,
    item_no: apiItem.item_no ?? apiItem.itemNo,
    item_code: apiItem.item_code,
    category: apiItem.category,
    description: apiItem.description ?? apiItem.item_description ?? apiItem.service_description,
    floor: apiItem.floor,
    unit: apiItem.unit ?? apiItem.uom,
    quantity: apiItem.quantity ?? apiItem.qty ?? apiItem.order_qty,
    rate: apiItem.rate ?? apiItem.unit_price,
    amount: apiItem.amount ?? apiItem.value,
    boq_file: apiItem.boq_file,
    project_id: apiItem.project_id,
    created_at: apiItem.created_at,
    hsn: apiItem.hsn ?? apiItem.hsn_sac_code ?? (typeof itemCode === "string" ? itemCode : undefined),
    sac_code: apiItem.sac_code ?? (typeof itemCode === "string" ? itemCode : undefined),
    client: (apiItem.client ?? apiItem.boq_client ?? apiItem.client_format ?? "").toString().trim().toLowerCase(),
  };
}

function matchesActiveClient(item, activeClient) {
  const client = String(item?.client || "").toLowerCase();
  if (client && client === activeClient) return true;

  const code = String(item?.code || "").trim();
  const hasHsn = String(item?.hsn || "").trim() !== "";
  const hasSac = String(item?.sac_code || "").trim() !== "";

  if (activeClient === "lodha") {
    // Lodha typically has numeric dot notation item numbers like 1.01.1 and an HSN/SAC code.
    if (hasHsn) return true;
    if (/^\d+(\.\d+){1,3}$/.test(code)) return true;
    return false;
  }

  if (activeClient === "hiranandani") {
    // Hiranandani item numbers are usually like "(1)" and have SAC code.
    if (hasSac) return true;
    if (/^\(\d+\)$/.test(code)) return true;
    return false;
  }

  return true;
}

const EMPTY_FORM = { category: '', item_no: '', item_code: '', description: '', floor: '', unit: '', quantity: '', rate: '', amount: '' };

export default function BOQ() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { projectId: routeProjectId } = useParams();
  const [searchParams] = useSearchParams();
  const { selectedProject } = useProject();
  const projectId = selectedProject?.id ?? selectedProject?.project_id ?? routeProjectId ?? null;
  const activeFileKey = (searchParams.get("file") || "").trim();
  const isNewBoqMode = (searchParams.get("new") || "").trim() === "1";
  const urlClient = (searchParams.get("client") || "").trim().toLowerCase();
  const [activeClient, setActiveClient] = useState(() => {
    if (urlClient) return urlClient;
    try {
      const key = projectId ? `boqClient:${projectId}` : "";
      const stored = key ? (localStorage.getItem(key) || "").trim().toLowerCase() : "";
      return stored || "";
    } catch {
      return "";
    }
  });

  // Keep client selection persistent per project, even if URL doesn't include `client`.
  useEffect(() => {
    const next = urlClient || (() => {
      try {
        const key = projectId ? `boqClient:${projectId}` : "";
        const stored = key ? (localStorage.getItem(key) || "").trim().toLowerCase() : "";
        return stored || "";
      } catch {
        return "";
      }
    })();
    setActiveClient(next);
  }, [urlClient, projectId]);

  useEffect(() => {
    if (!projectId) return;
    try {
      const key = `boqClient:${projectId}`;
      if (activeClient) localStorage.setItem(key, activeClient);
      else localStorage.removeItem(key);
    } catch {
      // ignore storage failures
    }
  }, [activeClient, projectId]);

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [importPreviewOpen, setImportPreviewOpen] = useState(false);
  const [extractedItems, setExtractedItems] = useState([]);
  const [extractedProjectName, setExtractedProjectName] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [extractError, setExtractError] = useState(null);
  const [boqFile, setBoqFile] = useState(null);
  const boqInputRef = useRef(null);
  const canImportBoqPdf = Boolean(projectId && activeClient);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [itemForm, setItemForm] = useState(EMPTY_FORM);
  const [formFile, setFormFile] = useState(null);
  const [saving, setSaving] = useState(false);
  const addFormRef = useRef(null);
  const [selectedIds, setSelectedIds] = useState(() => new Set());
  const [massDeleteOpen, setMassDeleteOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [viewItem, setViewItem] = useState(null);
  const [newBoqDialogOpen, setNewBoqDialogOpen] = useState(false);
  const [reservedQtyMap, setReservedQtyMap] = useState(() => new Map());

  const readReservedQtyMap = (pid) => {
    const key = `boqReservedQty:${String(pid || "").trim()}`;
    try {
      const raw = localStorage.getItem(key);
      const parsed = raw ? JSON.parse(raw) : [];
      const entries = Array.isArray(parsed) ? parsed : [];
      const map = new Map();
      for (const entry of entries) {
        if (!Array.isArray(entry) || entry.length < 2) continue;
        const k = String(entry[0] || "").trim();
        const v = Number(entry[1]) || 0;
        if (!k) continue;
        map.set(k, v);
      }
      return map;
    } catch {
      return new Map();
    }
  };

  useEffect(() => {
    if (!projectId) {
      setReservedQtyMap(new Map());
      return;
    }
    setReservedQtyMap(readReservedQtyMap(projectId));
    const onFocus = () => setReservedQtyMap(readReservedQtyMap(projectId));
    const onStorage = (e) => {
      if (e?.key && e.key === `boqReservedQty:${String(projectId)}`) {
        setReservedQtyMap(readReservedQtyMap(projectId));
      }
    };
    window.addEventListener("focus", onFocus);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("focus", onFocus);
      window.removeEventListener("storage", onStorage);
    };
  }, [projectId]);

  const getRemainingQtyForItem = (item) => {
    const base = Number(String(item?.quantity ?? "").replace(/,/g, "").trim());
    const safeBase = Number.isFinite(base) ? base : 0;
    const normalize = (v) => String(v || "").trim().toLowerCase();
    const normalizeEmptyLike = (v) => {
      const t = String(v ?? "").trim();
      if (!t) return "";
      const n = t.toLowerCase();
      if (n === "-" || n === "_" || n === "na" || n === "n/a" || n === "null" || n === "undefined") return "";
      return t;
    };
    const itemNoKey = normalize(normalizeEmptyLike(item?.item_no));
    const codeKey = normalize(normalizeEmptyLike(item?.code));
    const itemCodeKey = normalize(normalizeEmptyLike(item?.item_code));
    const descKey = normalize(normalizeEmptyLike(item?.description));
    const sectionKey = normalize(normalizeEmptyLike(item?.category));
    const compositeKey = descKey ? `${descKey}__${sectionKey}` : "";
    const reserved =
      (itemNoKey && reservedQtyMap.get(itemNoKey)) ||
      (codeKey && reservedQtyMap.get(codeKey)) ||
      (itemCodeKey && reservedQtyMap.get(itemCodeKey)) ||
      (compositeKey && reservedQtyMap.get(compositeKey)) ||
      0;
    return Math.max(0, safeBase - (Number(reserved) || 0));
  };

  const fetchItems = async () => {
    if (!projectId) {
      setItems([]);
      setSelectedIds(new Set());
      return;
    }
    setLoading(true);
    try {
      const res = await api.getBOQsByProject(projectId);
      const errorText = String(res?.error || "").toLowerCase();
      const isNoBoqForProject =
        errorText.includes("no boq") ||
        errorText.includes("no boq product") ||
        (errorText.includes("boq") && errorText.includes("not found"));
      const isInternalServerError =
        errorText.includes("internal server error") ||
        errorText.includes("server error") ||
        errorText.includes("status code 500") ||
        errorText.includes("500");
      const rows = res?.success
        ? (Array.isArray(res.data)
            ? res.data
            : Array.isArray(res.data?.boqs)
              ? res.data.boqs
              : Array.isArray(res.data?.data)
                ? res.data.data
                : [])
        : [];

      if (rows.length > 0) {
        setItems(rows.map(normalizeBoqItem));
        setSelectedIds(new Set());
      } else {
        setItems([]);
        setSelectedIds(new Set());
        if (!res?.success && !isNoBoqForProject && !isInternalServerError) {
          toast({ title: "Error", description: res?.error || "Failed to load BOQ items.", variant: "destructive" });
        }
      }
    } catch (e) {
      console.error(e);
      toast({ title: "Error", description: "Failed to load BOQ items.", variant: "destructive" });
      setItems([]);
      setSelectedIds(new Set());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, [projectId]);

  const scopedItems = useMemo(() => {
    const byFile = (() => {
      // Explicit "new BOQ" mode starts with a clean slate.
      if (isNewBoqMode && !activeFileKey) return [];
      if (!activeFileKey) return items;
      if (activeFileKey === NO_FILE_KEY) return items.filter((i) => !i?.boq_file);
      return items.filter((i) => String(i?.boq_file || "") === activeFileKey);
    })();

    if (!activeClient) return byFile;
    // When a client format is selected, prefer matching items for that client,
    // but allow heuristic matching when backend doesn't return a client field.
    const matched = byFile.filter((i) => matchesActiveClient(i, activeClient));
    // Never show an empty table purely due to missing client metadata.
    return matched.length > 0 ? matched : byFile;
  }, [items, activeFileKey, activeClient, isNewBoqMode]);

  // If the project already has any BOQ items, allow both "Add" and "Replace".
  // "Replace" will wipe either the currently opened BOQ file (when selected) or the entire project's BOQ items.
  const canReplaceCurrentBOQ = Boolean(projectId && items.length > 0);

  const isPdf = (f) => f && (f.type === "application/pdf" || (f.name || "").toLowerCase().endsWith(".pdf"));

  const runExtract = async (file) => {
    setExtractError(null);
    setExtracting(true);
    try {
      const rawText = await extractRawTextFromPdfFile(file);

      if (activeClient === 'lodha') {
        const { parseLodhaBoq } = await import('@/lib/boqParser');
        const parsed = parseLodhaBoq(rawText);
        const mapped = parsed.items.map((it, idx) => ({
          id: idx + 1 + Date.now(),
          category: it.section || 'General',
          code: it.item_no || '',
          item_no: it.item_no || '',
          item_code: it.hsn || '',
          description: it.description || '',
          unit: it.unit || '',
          quantity: it.qty_text || (it.qty != null ? String(it.qty) : ''),
          rate: it.rate_text || (it.rate != null ? String(it.rate) : ''),
          amount: it.amount_text || (it.amount != null ? String(it.amount) : ''),
          floor: '',
          hsn: it.hsn || '',
        }));
        setExtractedItems(mapped);
      } else if (activeClient === 'hiranandani') {
        const { parseHiranandaniBoq } = await import('@/lib/boqParser');
        const parsed = parseHiranandaniBoq(rawText);
        const mapped = parsed.items.map((it, idx) => ({
          id: idx + 1 + Date.now(),
          category: it.section || 'General',
          code: it.item_no || '',
          item_no: it.item_no || '',
          item_code: it.sac_code || '',
          description: it.description || '',
          unit: it.unit || '',
          quantity: it.qty_text || (Number.isFinite(it.qty) ? String(it.qty) : ''),
          rate: it.rate_text || (Number.isFinite(it.rate) ? String(it.rate) : ''),
          amount: it.amount_text || (Number.isFinite(it.amount) ? String(it.amount) : ''),
          floor: '',
          sac_code: it.sac_code || '',
        }));
        setExtractedItems(mapped);
      } else {
        // fallback to server-side for unknown clients
        const res = await api.parseBoqPdf({ boq_file: file, project_id: projectId || '', save: false });
        if (res.success && res.data && Array.isArray(res.data.items)) {
          const mapped = res.data.items.map((it, idx) => ({
            id: idx + 1 + Date.now(),
            category: it.section || 'General',
            code: it.item_no || '',
            item_code: it.item_no || '',
            description: it.description || '',
            unit: it.unit || '',
            quantity: it.qty ? String(it.qty) : '',
            rate: '',
            amount: '',
            floor: '',
          }));
          setExtractedItems(mapped);
        } else {
          throw new Error(res.error || 'Failed to parse BOQ PDF from server.');
        }
      }

      setExtractedProjectName('');
      setImportPreviewOpen(true);
    } catch (err) {
      console.error(err);
      setExtractError(err?.message || "Could not read BOQ PDF.");
      toast({
        title: "BOQ extraction failed",
        description: "We couldn't parse this PDF. You can still import via Excel or add items manually.",
        variant: "destructive",
      });
    } finally {
      setExtracting(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!projectId) {
      toast({ title: "Select project first", description: "Please select a project before importing a BOQ PDF.", variant: "destructive" });
      if (boqInputRef.current) boqInputRef.current.value = "";
      return;
    }
    if (!activeClient) {
      toast({ title: "Select BOQ format first", description: "Choose a BOQ format (e.g., Lodha/Hiranandani) to enable PDF import.", variant: "destructive" });
      if (boqInputRef.current) boqInputRef.current.value = "";
      return;
    }
    setBoqFile(file);
    // Once a file is selected, exit "new BOQ" mode so saved items can be visible/scoped.
    if (projectId) {
      const params = new URLSearchParams(searchParams);
      if (params.get("new") === "1") {
        params.delete("new");
        navigate(`/${projectId}/boq/manage?${params.toString()}`);
      }
    }
    if (isPdf(file)) runExtract(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!projectId) {
      toast({ title: "Select project first", description: "Please select a project before importing a BOQ PDF.", variant: "destructive" });
      return;
    }
    if (!activeClient) {
      toast({ title: "Select BOQ format first", description: "Choose a BOQ format (e.g., Lodha/Hiranandani) to enable PDF import.", variant: "destructive" });
      return;
    }
    const file = e.dataTransfer?.files?.[0];
    if (!file) return;
    if (!isPdf(file)) {
      toast({ title: "Invalid file", description: "Please use a BOQ PDF.", variant: "destructive" });
      return;
    }
    setBoqFile(file);
    if (projectId) {
      const params = new URLSearchParams(searchParams);
      if (params.get("new") === "1") {
        params.delete("new");
        navigate(`/${projectId}/boq/manage?${params.toString()}`);
      }
    }
    runExtract(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const addExtractedToBOQ = async () => {
    if (!projectId) {
      const maxId = items.length ? Math.max(...items.map((i) => i.id)) : 0;
      const withIds = extractedItems.map((it, i) => ({ ...it, id: maxId + i + 1 }));
      setItems((prev) => [...prev, ...withIds]);
      setSearchTerm("");
      setCurrentPage(1);
      setImportPreviewOpen(false);
      setBoqFile(null);
      if (boqInputRef.current) boqInputRef.current.value = "";
      toast({ title: "Added to BOQ", description: `${withIds.length} item(s) added. Select a project to save to server.` });
      return;
    }

    setSaving(true);
    try {
      const res = await api.saveBOQItems({
        project_id: projectId || "",
        items: extractedItems,
        boq_file_name: boqFile?.name,
        client: activeClient || undefined,
      });
      if (!res?.success) throw new Error(res?.error || "Failed to save BOQ");
      const savedPath = inferSavedFilePath(res);

      // Required: refresh via GET /api/boq/project/{projectId}
      await fetchItems();
      setSearchTerm('');
      setCurrentPage(1);
      setImportPreviewOpen(false);
      setBoqFile(null);
      if (boqInputRef.current) boqInputRef.current.value = '';
      if (savedPath) {
        const next = `/${projectId}/boq/manage?file=${encodeURIComponent(savedPath)}${activeClient ? `&client=${encodeURIComponent(activeClient)}` : ""}`;
        navigate(next);
      } else {
        // If backend doesn't return a stable file path (or we didn't attach a file), ensure the user still sees all imported rows.
        const next = `/${projectId}/boq/manage${activeClient ? `?client=${encodeURIComponent(activeClient)}` : ""}`;
        navigate(next);
      }
      toast({ title: 'BOQ saved', description: 'BOQ imported successfully.' });
    } catch (e) {
      toast({ title: 'Error', description: e?.message || 'Failed to save BOQ.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const replaceBOQWithExtracted = async () => {
    if (projectId) {
      const targetItems = activeFileKey ? scopedItems : items;
      if (targetItems.length === 0) {
        toast({
          title: "No BOQ to replace",
          description: "There are no existing BOQ items for this project.",
          variant: "destructive",
        });
        return;
      }
      setSaving(true);
      try {
        for (const item of targetItems) {
          await api.deleteBOQ(item.id);
        }
        const res = await api.saveBOQItems({
          project_id: projectId || "",
          items: extractedItems,
          boq_file_name: boqFile?.name,
          client: activeClient || undefined,
        });
        if (!res?.success) throw new Error(res?.error || "Failed to save BOQ");
        const savedPath = inferSavedFilePath(res);

        await fetchItems();
        setSearchTerm("");
        setCurrentPage(1);
        setImportPreviewOpen(false);
        setBoqFile(null);
        if (boqInputRef.current) boqInputRef.current.value = "";
        if (savedPath) {
          const next = `/${projectId}/boq/manage?file=${encodeURIComponent(savedPath)}${activeClient ? `&client=${encodeURIComponent(activeClient)}` : ""}`;
          navigate(next);
        } else {
          const next = `/${projectId}/boq/manage${activeClient ? `?client=${encodeURIComponent(activeClient)}` : ""}`;
          navigate(next);
        }
        toast({ title: "BOQ replaced", description: "BOQ replaced successfully." });
      } catch (e) {
        toast({ title: "Error", description: e?.message || "Failed to replace BOQ.", variant: "destructive" });
      } finally {
        setSaving(false);
      }
    } else {
      const withIds = extractedItems.map((it, i) => ({ ...it, id: i + 1 }));
      setItems(withIds);
      setSearchTerm("");
      setCurrentPage(1);
      setImportPreviewOpen(false);
      setBoqFile(null);
      if (boqInputRef.current) boqInputRef.current.value = "";
      toast({ title: "BOQ replaced", description: `${withIds.length} item(s) loaded from PDF. Select a project to save to server.` });
    }
  };

  const openAddDialog = () => {
    setItemForm(EMPTY_FORM);
    setFormFile(null);
    setAddDialogOpen(true);
  };

  const handleAddItem = async (e) => {
    e?.preventDefault();
    if (!projectId) {
      toast({ title: "Select project", description: "Choose a project first.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = { ...itemForm, project_id: projectId };
      if (formFile instanceof File) payload.boq_file = formFile;
      let res;
      if (activeClient === 'lodha') {
        res = await api.createBOQLodha({
          ...payload,
          description: payload.description,
          section: payload.category,
          item_no: payload.item_no || '',
          hsn: payload.item_code || '',
          qty: payload.quantity,
        });
      } else if (activeClient === 'hiranandani') {
        res = await api.createBOQHiranandani({
          ...payload,
          description: payload.description,
          section: payload.category,
          item_no: payload.item_no || '',
          sac_code: payload.item_code || '',
          order_qty: payload.quantity,
          uom: payload.unit,
          unit_price: payload.rate,
          value: payload.amount,
        });
      } else {
        res = await api.createBOQ(payload);
      }
      if (res.success) {
        await fetchItems();
        setAddDialogOpen(false);
        setItemForm(EMPTY_FORM);
        setFormFile(null);
        setSearchTerm("");
        setCurrentPage(1);
        toast({ title: "Item added", description: "BOQ item created." });
      } else {
        toast({ title: "Error", description: res.error || "Failed to add item.", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Error", description: e.message || "Failed to add item.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const openEditDialog = (item) => {
    setEditItem(item);
    setItemForm({
      category: item.category ?? '',
      item_no: item.item_no ?? item.code ?? '',
      item_code: item.hsn ?? item.sac_code ?? item.item_code ?? '',
      description: item.description ?? '',
      floor: item.floor ?? '',
      unit: item.unit ?? '',
      quantity: item.quantity ?? '',
      rate: item.rate ?? '',
      amount: item.amount ?? '',
    });
    setFormFile(null);
  };

  const handleEditItem = async (e) => {
    e?.preventDefault();
    if (!editItem) return;
    setSaving(true);
    try {
      const payload = { ...itemForm, item_code: itemForm.item_code || undefined };
      if (formFile instanceof File) payload.boq_file = formFile;
      const res = await api.updateBOQ(editItem.id, payload);
      if (res.success) {
        await fetchItems();
        setEditItem(null);
        setItemForm(EMPTY_FORM);
        setFormFile(null);
        toast({ title: "Item updated", description: "BOQ item saved." });
      } else {
        toast({ title: "Error", description: res.error || "Failed to update item.", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Error", description: e.message || "Failed to update item.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const openDeleteDialog = (item) => {
    if (!item) return;
    setDeleteTarget(item);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    const item = deleteTarget;
    if (!item) return;
    setSaving(true);
    try {
      const res = await api.deleteBOQ(item.id);
      if (res.success) {
        await fetchItems();
        setSelectedIds((prev) => {
          const next = new Set(prev);
          next.delete(item.id);
          return next;
        });
        setDeleteDialogOpen(false);
        setDeleteTarget(null);
      } else {
        toast({ title: "Error", description: res.error || "Failed to delete item.", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Error", description: e.message || "Failed to delete item.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const filteredItems = scopedItems.filter((item) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      String(item.category ?? "").toLowerCase().includes(term) ||
      String(item.code ?? "").toLowerCase().includes(term) ||
      String(item.description ?? "").toLowerCase().includes(term) ||
      String(item.unit ?? "").toLowerCase().includes(term) ||
      String(item.floor ?? "").toLowerCase().includes(term) ||
      String(item.quantity).includes(term) ||
      String(item.rate).includes(term) ||
      String(item.amount).includes(term)
    );
  });

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedItems = filteredItems.slice(startIndex, endIndex);
  const pageIds = paginatedItems.map((i) => i?.id).filter((id) => id != null);
  const pageAllSelected = pageIds.length > 0 && pageIds.every((id) => selectedIds.has(id));
  const pageSomeSelected = pageIds.some((id) => selectedIds.has(id));
  const pageCheckboxState = pageAllSelected ? true : pageSomeSelected ? "indeterminate" : false;

  const totalAmount = filteredItems.reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const prettyKey = (key) => {
    const raw = String(key || "").trim();
    if (!raw) return "";
    if (raw.toLowerCase() === "category" || raw.toLowerCase() === "categories") return "Section";
    const withSpaces = raw
      .replace(/[_-]+/g, " ")
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/\s+/g, " ")
      .trim();
    return withSpaces.charAt(0).toUpperCase() + withSpaces.slice(1);
  };

  const toggleItemSelection = (id, checked) => {
    if (id == null) return;
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const togglePageSelection = (checked) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) {
        pageIds.forEach((id) => next.add(id));
      } else {
        pageIds.forEach((id) => next.delete(id));
      }
      return next;
    });
  };

  const handleMassDelete = async () => {
    const ids = Array.from(selectedIds);
    if (!projectId || ids.length === 0) return;

    setSaving(true);
    try {
      let deleted = 0;
      let failed = 0;
      for (const id of ids) {
        try {
          const res = await api.deleteBOQ(id);
          if (res?.success) deleted += 1;
          else failed += 1;
        } catch {
          failed += 1;
        }
      }
      await fetchItems();
      setSelectedIds(new Set());
      setMassDeleteOpen(false);
      toast({
        title: "Mass delete complete",
        description: failed > 0 ? `${deleted} deleted, ${failed} failed.` : `${deleted} item(s) deleted.`,
        variant: failed > 0 ? "destructive" : undefined,
      });
    } finally {
      setSaving(false);
    }
  };


  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [totalPages]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-3xl font-bold tracking-tight">BOQ</h1>
            {activeClient === 'lodha' ? (
              <Badge className="bg-sky-100 text-sky-800 hover:bg-sky-100">Lodha Format</Badge>
            ) : activeClient === 'hiranandani' ? (
              <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Hiranandani Format</Badge>
            ) : null}
          </div>
          <p className="text-muted-foreground mt-2">
            {activeFileKey
              ? `Managing ${activeFileKey === NO_FILE_KEY ? "manual BOQ" : "BOQ file"} items.`
              : "Upload a BOQ PDF or open one from the BOQ list."}
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-wrap w-full lg:w-auto gap-2">
          <Button
            type="button"
            size="sm"
            variant={activeClient ? "outline" : "default"}
            className="shrink-0 w-full lg:w-auto"
            onClick={() => setNewBoqDialogOpen(true)}
            disabled={!projectId}
          >
            {activeClient ? (
              <>
                <Pencil className="mr-2 h-4 w-4" />
                {activeClient === "lodha" ? "Lodha Format" : activeClient === "hiranandani" ? "Hiranandani Format" : activeClient}
              </>
            ) : (
              <>
                <Plus className="mr-2 h-4 w-4" /> Select BOQ Format
              </>
            )}
          </Button>
          <div
            className={[
              "relative border-2 border-dashed rounded-lg px-4 py-2 flex items-center gap-2 text-sm transition-colors w-full sm:col-span-2 lg:w-auto",
              canImportBoqPdf ? "hover:bg-muted/50" : "opacity-60 cursor-not-allowed",
            ].join(" ")}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <input
              ref={boqInputRef}
              type="file"
              accept=".pdf"
              onChange={handleFileChange}
              disabled={!canImportBoqPdf}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            {extracting ? (
              <Loader2 className="h-4 w-4 shrink-0 animate-spin" />
            ) : (
              <Upload className="h-4 w-4 shrink-0" />
            )}
            <span className="truncate min-w-0">
              {!projectId
                ? "Select project first"
                : !activeClient
                  ? "Select BOQ format first"
                  : boqFile
                    ? (extracting ? "Extracting…" : boqFile.name)
                    : "Import BOQ PDF"}
            </span>
            {extractError && <span className="text-destructive text-xs">{extractError}</span>}
          </div>
          <Button
            size="sm"
            className="shrink-0 w-full lg:w-auto bg-sky-200 text-sky-950 hover:bg-sky-300 dark:bg-sky-300 dark:text-sky-950 dark:hover:bg-sky-400"
            onClick={openAddDialog}
            disabled={!projectId}
          >
            <Plus className="mr-2 h-4 w-4" /> Add Item
          </Button>
          {selectedIds.size > 0 ? (
            <Button
              variant="destructive"
              size="sm"
              className="shrink-0 w-full lg:w-auto"
              onClick={() => setMassDeleteOpen(true)}
              disabled={!projectId || saving}
            >
              <Trash2 className="mr-2 h-4 w-4" /> Delete Selected ({selectedIds.size})
            </Button>
          ) : null}
          <Button variant="outline" size="sm" className="shrink-0 w-full lg:w-auto" onClick={fetchItems} disabled={loading}>
            {loading ? "Loading…" : "Refresh"}
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>BOQ Items</CardTitle>
            <div className="relative w-full sm:w-auto sm:min-w-[300px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by section, code, description..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-8"
              />
            </div>
          </div>
          {searchTerm && (
            <p className="text-sm text-muted-foreground mt-2">
              Showing {filteredItems.length} of {items.length} item(s)
            </p>
          )}
        </CardHeader>
        <CardContent>
          <div className="hidden md:block overflow-x-auto">
            <div className={activeClient ? "min-w-[1200px]" : "min-w-[1100px]"}>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={pageCheckboxState}
                      onCheckedChange={(v) => togglePageSelection(Boolean(v))}
                      disabled={paginatedItems.length === 0}
                    />
                  </TableHead>
                  {activeClient === 'hiranandani' ? (
                    <>
                      <TableHead>Item No</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Section</TableHead>
                      <TableHead>SAC Code</TableHead>
                      <TableHead>UOM</TableHead>
                      <TableHead className="text-right">Order Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Value</TableHead>
                    </>
                  ) : (
                    <>
                      <TableHead>Description</TableHead>
                      <TableHead>Section</TableHead>
                      <TableHead>{activeClient ? "Item No" : "Item Code"}</TableHead>
                      {activeClient === 'lodha' ? <TableHead>HSN</TableHead> : null}
                      {!activeClient ? <TableHead>Floor</TableHead> : null}
                      <TableHead>Unit</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      <TableHead className="text-right">Rate</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </>
                  )}
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={activeClient ? 10 : 10} className="h-24 text-center text-muted-foreground">
                      Loading BOQ items…
                    </TableCell>
                  </TableRow>
                ) : paginatedItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={activeClient ? 10 : 10} className="h-24 text-center text-muted-foreground">
                      {!projectId ? "Select a project to load BOQ items." : searchTerm ? "No items found matching your search." : "No BOQ items. Import a PDF or add items manually."}
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedItems.map((item) => (
                  <TableRow
                    key={item.id}
                    className="cursor-pointer"
                    onClick={() => setViewItem(item)}
                  >
                    <TableCell>
                      <div onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={selectedIds.has(item.id)}
                          onCheckedChange={(v) => toggleItemSelection(item.id, Boolean(v))}
                        />
                      </div>
                    </TableCell>
                    {activeClient === 'hiranandani' ? (
                      <>
                        <TableCell className="font-mono text-xs whitespace-nowrap">{item.code}</TableCell>
                        <TableCell className="font-medium max-w-[560px] whitespace-normal break-words">
                          {item.description}
                        </TableCell>
                        <TableCell className="text-sm font-medium text-muted-foreground">{item.category}</TableCell>
                        <TableCell className="font-mono text-xs">{item.sac_code || item.item_code || ''}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell className="text-right">{formatNumberIN(getRemainingQtyForItem(item), { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right">{item.rate ? formatCurrencyINR(item.rate) : "–"}</TableCell>
                        <TableCell className="text-right">{item.amount ? formatCurrencyINR(item.amount) : "–"}</TableCell>
                      </>
                    ) : (
                      <>
                        <TableCell className="font-medium max-w-[560px] whitespace-normal break-words">
                          {item.description}
                        </TableCell>
                        <TableCell className="text-sm font-medium text-muted-foreground">{item.category}</TableCell>
                        <TableCell className="font-mono text-xs whitespace-nowrap">{item.code}</TableCell>
                        {activeClient === 'lodha' ? <TableCell className="font-mono text-xs">{item.hsn || item.item_code || ''}</TableCell> : null}
                        {!activeClient ? <TableCell>{item.floor}</TableCell> : null}
                        <TableCell>{item.unit}</TableCell>
                        <TableCell className="text-right">{formatNumberIN(getRemainingQtyForItem(item), { maximumFractionDigits: 3 })}</TableCell>
                        <TableCell className="text-right">{item.rate ? formatCurrencyINR(item.rate) : "–"}</TableCell>
                        <TableCell className="text-right">{item.amount ? formatCurrencyINR(item.amount) : "–"}</TableCell>
                      </>
                    )}
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" onClick={() => openEditDialog(item)} title="Edit">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => openDeleteDialog(item)} title="Delete">
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                  ))
                )}
                {paginatedItems.length > 0 && (
                  <TableRow className="bg-muted/50 font-bold">
                  <TableCell colSpan={activeClient ? 6 : 6}>Total</TableCell>
                  <TableCell className="text-right"></TableCell>
                  <TableCell className="text-right"></TableCell>
                  <TableCell className="text-right">{formatCurrencyINR(totalAmount)}</TableCell>
                  <TableCell></TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            </div>
            {filteredItems.length > itemsPerPage && (
              <div className="flex flex-col lg:flex-row lg:items-center justify-between mt-4 pt-4 border-t gap-3">
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-muted-foreground">Rows per page</p>
                  <Select
                    value={`${itemsPerPage}`}
                    onValueChange={(value) => {
                      setItemsPerPage(Number(value));
                      setCurrentPage(1);
                    }}
                  >
                    <SelectTrigger className="h-8 w-[70px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[10, 20, 30, 50, 100].map((size) => (
                        <SelectItem key={size} value={`${size}`}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </p>
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage(1)}
                      disabled={currentPage === 1}
                    >
                      <ChevronsLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage(totalPages)}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronsRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4 md:hidden">
            {paginatedItems.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">
                {searchTerm ? "No items found matching your search." : "No BOQ items. Import a PDF or add items manually."}
              </div>
            ) : (
              paginatedItems.map((item) => (
              <div
                key={item.id}
                className="p-4 border rounded-lg space-y-3 cursor-pointer"
                onClick={() => setViewItem(item)}
              >
                <div className="flex justify-between items-start gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-xs font-semibold text-muted-foreground">{item.category}</div>
                    <div className="font-medium break-words">{item.description}</div>
                    <div className="text-xs font-mono text-muted-foreground break-all">
                      {activeClient ? `Item No: ${item.code || "-"}` : `Item Code: ${item.code || "-"}`}
                    </div>
                    {activeClient === "lodha" ? (
                      <div className="text-xs text-muted-foreground">HSN: <span className="font-mono">{item.hsn || item.item_code || "-"}</span></div>
                    ) : activeClient === "hiranandani" ? (
                      <div className="text-xs text-muted-foreground">SAC: <span className="font-mono">{item.sac_code || item.item_code || "-"}</span></div>
                    ) : null}
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <div onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selectedIds.has(item.id)}
                        onCheckedChange={(v) => toggleItemSelection(item.id, Boolean(v))}
                      />
                    </div>
                    <div className="font-bold">{item.amount ? formatCurrencyINR(item.amount) : "–"}</div>
                    {item.rate ? (
                      <div className="text-xs text-muted-foreground">
                        {formatCurrencyINR(item.rate)}/{item.unit}
                      </div>
                    ) : null}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm pt-2 border-t">
                  <div>
                    <span className="text-muted-foreground block">{activeClient === "hiranandani" ? "Order Qty:" : "Qty:"}</span>
                    <span>{formatNumberIN(getRemainingQtyForItem(item))} {item.unit}</span>
                  </div>
                  {!activeClient ? (
                    <div>
                      <span className="text-muted-foreground block">Floor:</span>
                      <span>{item.floor}</span>
                    </div>
                  ) : (
                    <div>
                      <span className="text-muted-foreground block">{activeClient === "hiranandani" ? "Unit Price:" : "Rate:"}</span>
                      <span>{item.rate ? formatCurrencyINR(item.rate) : "–"}</span>
                    </div>
                  )}
                </div>
                <div className="flex justify-end gap-1 pt-2" onClick={(e) => e.stopPropagation()}>
                  <Button variant="ghost" size="sm" onClick={() => openEditDialog(item)}>
                    <Pencil className="mr-2 h-4 w-4" /> Edit
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => openDeleteDialog(item)}>
                    Delete
                  </Button>
                </div>
              </div>
              ))
            )}
            {paginatedItems.length > 0 && (
              <div className="p-4 bg-muted/50 rounded-lg flex justify-between items-center font-bold">
                <span>Total Amount</span>
                <span>{formatCurrencyINR(totalAmount)}</span>
              </div>
            )}
            {filteredItems.length > itemsPerPage && (
              <div className="flex flex-col gap-3 pt-4 border-t">
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-muted-foreground">Rows per page</p>
                  <Select
                    value={`${itemsPerPage}`}
                    onValueChange={(value) => {
                      setItemsPerPage(Number(value));
                      setCurrentPage(1);
                    }}
                  >
                    <SelectTrigger className="h-8 w-[70px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[10, 20, 30, 50, 100].map((size) => (
                        <SelectItem key={size} value={`${size}`}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-muted-foreground">
                    Page {currentPage} of {totalPages}
                  </p>
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage(1)}
                      disabled={currentPage === 1}
                    >
                      <ChevronsLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage(totalPages)}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronsRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog
        open={deleteDialogOpen}
        onOpenChange={(open) => {
          setDeleteDialogOpen(open);
          if (!open) setDeleteTarget(null);
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete BOQ item</DialogTitle>
            <DialogDescription>
              This will permanently delete{" "}
              <span className="font-mono">{deleteTarget?.code || deleteTarget?.item_code || "this item"}</span>.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} disabled={saving}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleConfirmDelete} disabled={saving || !deleteTarget}>
              {saving ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={massDeleteOpen} onOpenChange={setMassDeleteOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete selected BOQ items</DialogTitle>
          </DialogHeader>
          <div className="text-sm text-muted-foreground">
            This will permanently delete {selectedIds.size} item(s).
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMassDeleteOpen(false)} disabled={saving}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleMassDelete} disabled={saving || selectedIds.size === 0}>
              {saving ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!viewItem} onOpenChange={(open) => !open && setViewItem(null)}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>BOQ Item Details</DialogTitle>
          </DialogHeader>
          {viewItem ? (
            <ScrollArea className="max-h-[70vh] pr-4">
              <div className="grid gap-2">
                {Object.entries(viewItem)
                  .filter(([key]) => !key.startsWith("__"))
                  .map(([key, value]) => (
                    <div key={key} className="grid grid-cols-1 sm:grid-cols-3 gap-2 rounded-md border p-3 text-sm">
                      <div className="text-muted-foreground font-medium break-words">{prettyKey(key)}</div>
                      <div className="sm:col-span-2 break-words">
                        {value == null || value === "" ? "-" : typeof value === "object" ? JSON.stringify(value) : String(value)}
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          ) : null}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewItem(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add BOQ Item</DialogTitle>
            </DialogHeader>
          <form ref={addFormRef} onSubmit={handleAddItem} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Section *</Label>
                <Input
                  value={itemForm.category}
                  onChange={(e) => setItemForm((f) => ({ ...f, category: e.target.value }))}
                  placeholder="e.g. Civil, Plumbing"
                  required
                />
              </div>
              {activeClient ? (
                <div className="space-y-2">
                  <Label>Item No *</Label>
                  <Input
                    value={itemForm.item_no}
                    onChange={(e) => setItemForm((f) => ({ ...f, item_no: e.target.value }))}
                    placeholder={activeClient === "lodha" ? "e.g. 1.01.1" : "e.g. (1)"}
                    required
                  />
                </div>
              ) : null}
              <div className="space-y-2">
                <Label>
                  {activeClient === 'lodha' ? 'HSN/SAC Code' : activeClient === 'hiranandani' ? 'SAC Code' : 'Item Code'}
                </Label>
                <Input
                  value={itemForm.item_code}
                  onChange={(e) => setItemForm((f) => ({ ...f, item_code: e.target.value }))}
                  placeholder={activeClient ? 'e.g. 995462' : 'e.g. C-101'}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>{activeClient === 'hiranandani' ? 'Service Description *' : 'Item Description *'}</Label>
              <Input
                value={itemForm.description}
                onChange={(e) => setItemForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Item description"
                required
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Floor</Label>
                <Input
                  value={itemForm.floor}
                  onChange={(e) => setItemForm((f) => ({ ...f, floor: e.target.value }))}
                  placeholder="e.g. Ground"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'UOM' : 'Unit'}</Label>
                <UnitSelect
                  value={itemForm.unit}
                  onValueChange={(value) =>
                    setItemForm((f) => {
                      const converted = convertQuantity(f.quantity, f.unit, value);
                      return {
                        ...f,
                        unit: value,
                        quantity: converted ?? f.quantity,
                      };
                    })
                  }
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Order Qty' : 'Qty'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.quantity}
                  onChange={(e) => setItemForm((f) => ({ ...f, quantity: e.target.value }))}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Unit Price' : 'Rate'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.rate}
                  onChange={(e) => setItemForm((f) => ({ ...f, rate: e.target.value }))}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Value' : 'Amount'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.amount}
                  onChange={(e) => setItemForm((f) => ({ ...f, amount: e.target.value }))}
                  placeholder="0"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setAddDialogOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Add Item"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editItem} onOpenChange={(open) => !open && setEditItem(null)}>
          <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit BOQ Item</DialogTitle>
            </DialogHeader>
          <form onSubmit={handleEditItem} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Section *</Label>
                <Input
                  value={itemForm.category}
                  onChange={(e) => setItemForm((f) => ({ ...f, category: e.target.value }))}
                  placeholder="e.g. Civil, Plumbing"
                  required
                />
              </div>
              {activeClient ? (
                <div className="space-y-2">
                  <Label>Item No *</Label>
                  <Input
                    value={itemForm.item_no}
                    onChange={(e) => setItemForm((f) => ({ ...f, item_no: e.target.value }))}
                    placeholder={activeClient === "lodha" ? "e.g. 1.01.1" : "e.g. (1)"}
                    required
                  />
                </div>
              ) : null}
              <div className="space-y-2">
                <Label>
                  {activeClient === 'lodha' ? 'HSN/SAC Code' : activeClient === 'hiranandani' ? 'SAC Code' : 'Item Code'}
                </Label>
                <Input
                  value={itemForm.item_code}
                  onChange={(e) => setItemForm((f) => ({ ...f, item_code: e.target.value }))}
                  placeholder={activeClient ? 'e.g. 995462' : 'e.g. C-101'}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>{activeClient === 'hiranandani' ? 'Service Description *' : 'Item Description *'}</Label>
              <Input
                value={itemForm.description}
                onChange={(e) => setItemForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Item description"
                required
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Floor</Label>
                <Input
                  value={itemForm.floor}
                  onChange={(e) => setItemForm((f) => ({ ...f, floor: e.target.value }))}
                  placeholder="e.g. Ground"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'UOM' : 'Unit'}</Label>
                <UnitSelect
                  value={itemForm.unit}
                  onValueChange={(value) =>
                    setItemForm((f) => {
                      const converted = convertQuantity(f.quantity, f.unit, value);
                      return {
                        ...f,
                        unit: value,
                        quantity: converted ?? f.quantity,
                      };
                    })
                  }
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Order Qty' : 'Qty'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.quantity}
                  onChange={(e) => setItemForm((f) => ({ ...f, quantity: e.target.value }))}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Unit Price' : 'Rate'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.rate}
                  onChange={(e) => setItemForm((f) => ({ ...f, rate: e.target.value }))}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label>{activeClient === 'hiranandani' ? 'Value' : 'Amount'}</Label>
                <Input
                  type="number"
                  step="any"
                  value={itemForm.amount}
                  onChange={(e) => setItemForm((f) => ({ ...f, amount: e.target.value }))}
                  placeholder="0"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditItem(null)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={importPreviewOpen} onOpenChange={setImportPreviewOpen}>
        <DialogContent className="sm:max-w-[90vw] h-[85vh] flex flex-col overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Preview BOQ from PDF
              <Badge variant="secondary" className="ml-2">
                {extractedItems.length} item(s)
              </Badge>
            </DialogTitle>
          </DialogHeader>
          {extractedProjectName && (
            <p className="text-sm text-muted-foreground">Project: <strong>{extractedProjectName}</strong></p>
          )}
          <p className="text-sm text-muted-foreground">
            {extractedItems.length} item(s) extracted. {canReplaceCurrentBOQ ? "Add to existing BOQ or replace all." : "Add to BOQ."}
          </p>
          <div className="flex-1 overflow-auto border rounded-md">
            <div className="min-w-[640px]">
            <Table>
              <TableHeader>
                <TableRow>
                  {activeClient === 'hiranandani' ? (
                    <>
                      <TableHead>Item No</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Section</TableHead>
                      <TableHead>SAC Code</TableHead>
                      <TableHead>UOM</TableHead>
                      <TableHead className="text-right">Order Qty</TableHead>
                      <TableHead className="text-right">Unit Price</TableHead>
                      <TableHead className="text-right">Value</TableHead>
                    </>
                  ) : (
                    <>
                      <TableHead>Description</TableHead>
                      <TableHead>Section</TableHead>
                      <TableHead>{activeClient === 'lodha' ? 'Item No' : 'Code'}</TableHead>
                      {activeClient === 'lodha' ? <TableHead>HSN</TableHead> : null}
                      <TableHead>Unit</TableHead>
                      <TableHead className="text-right">Qty</TableHead>
                      {activeClient ? <TableHead className="text-right">Rate</TableHead> : null}
                      {activeClient ? <TableHead className="text-right">Amount</TableHead> : null}
                    </>
                  )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {(() => {
                  const groups = extractedItems.reduce((acc, it) => {
                    const key = String(it.category || 'General');
                    if (!acc.has(key)) acc.set(key, []);
                    acc.get(key).push(it);
                    return acc;
                  }, new Map());
                  return Array.from(groups.entries()).flatMap(([section, rows]) => [
                    (
                      <TableRow key={`section-${section}`}>
                        <TableCell colSpan={activeClient ? 8 : 5} className="bg-muted/40 font-medium">
                          {section}
                        </TableCell>
                      </TableRow>
                    ),
                    ...rows.map((it, i) => (
                      <TableRow key={`${section}-${i}`}>
                        {activeClient === 'hiranandani' ? (
                          <>
                            <TableCell className="font-mono text-xs">{it.code}</TableCell>
                            <TableCell className="max-w-[560px] whitespace-normal break-words">
                              {it.description}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              <Badge variant="outline">{it.category}</Badge>
                            </TableCell>
                            <TableCell className="font-mono text-xs">{it.sac_code || ''}</TableCell>
                            <TableCell>{it.unit}</TableCell>
                            <TableCell className="text-right">{formatNumberIN(it.quantity, { maximumFractionDigits: 3 })}</TableCell>
                            <TableCell className="text-right">{it.rate ? formatCurrencyINR(it.rate) : '–'}</TableCell>
                            <TableCell className="text-right">{it.amount ? formatCurrencyINR(it.amount) : '–'}</TableCell>
                          </>
                        ) : (
                          <>
                            <TableCell className="max-w-[560px] whitespace-normal break-words">
                              {it.description}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              <Badge variant="outline">{it.category}</Badge>
                            </TableCell>
                            <TableCell className="font-mono text-xs">{it.code}</TableCell>
                            {activeClient === 'lodha' ? <TableCell className="font-mono text-xs">{it.hsn || ''}</TableCell> : null}
                            <TableCell>{it.unit}</TableCell>
                            <TableCell className="text-right">{formatNumberIN(it.quantity, { maximumFractionDigits: 3 })}</TableCell>
                            {activeClient ? <TableCell className="text-right">{it.rate ? formatCurrencyINR(it.rate) : '–'}</TableCell> : null}
                            {activeClient ? <TableCell className="text-right">{it.amount ? formatCurrencyINR(it.amount) : '–'}</TableCell> : null}
                          </>
                        )}
                      </TableRow>
                    )),
                  ]);
                })()}
              </TableBody>
            </Table>
            </div>
          </div>
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => { setImportPreviewOpen(false); setBoqFile(null); setExtractError(null); if (boqInputRef.current) boqInputRef.current.value = ""; }} disabled={saving}>
              Cancel
            </Button>
            <Button variant="outline" onClick={addExtractedToBOQ} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving…
                </>
              ) : (
                `Add to BOQ (${extractedItems.length})`
              )}
            </Button>
            {canReplaceCurrentBOQ ? (
              <Button onClick={replaceBOQWithExtracted} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Replacing…
                  </>
                ) : (
                  `Replace BOQ (${extractedItems.length})`
                )}
              </Button>
            ) : null}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={newBoqDialogOpen} onOpenChange={setNewBoqDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Select BOQ Format</DialogTitle>
            <DialogDescription>Choose the client format before creating the BOQ.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { label: "Lodha", value: "lodha", description: "Lodha BOQ format" },
              { label: "Hiranandani", value: "hiranandani", description: "Hiranandani BOQ format" },
            ].map((opt) => (
              <button
                key={`boq-new-${opt.value}`}
                type="button"
                onClick={() => {
                  setNewBoqDialogOpen(false);
                  if (!projectId) return;
                  setActiveClient(opt.value);
                  setBoqFile(null);
                  setExtractedItems([]);
                  setExtractError(null);
                  if (boqInputRef.current) boqInputRef.current.value = "";
                  navigate(`/${projectId}/boq/manage?client=${encodeURIComponent(opt.value)}&new=1`);
                }}
                className="rounded-lg border border-border p-4 text-left transition hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <div className="text-base font-semibold">{opt.label}</div>
                <div className="mt-2 text-sm text-muted-foreground">{opt.description}</div>
                {activeClient === opt.value ? (
                  <div className="mt-3">
                    <Badge variant="secondary">Selected</Badge>
                  </div>
                ) : null}
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
