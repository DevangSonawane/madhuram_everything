import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  CalendarDays,
  Download,
  Eye,
  FileSignature,
  FileText,
  Loader2,
  Link2,
  Mail,
  Pencil,
  Plus,
  RefreshCcw,
  Search,
  Trash2,
  Upload,
  X,
  MoreHorizontal,
} from "lucide-react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useProject } from "@/contexts/useProject";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { extractImagesFromPdf } from "@/lib/pdfUtils";
import { UnitSelect, convertQuantity } from "@/components/forms/UnitSelect";
import { RowActionsMenu } from "@/components/RowActionsMenu";

const URGENCY_OPTIONS = ["High", "Medium", "Low"];

const createEmptyItem = () => ({
  material_description: "",
  unit: "NOS",
  req_qty: "",
  make: "",
  place_of_utilisation: "",
});

const createEmptyForm = () => ({
  project_id: "",
  sample_id: "",
  project_name: "",
  workorder_no: "",
  location: "",
  mirno: "",
  urgency: "Medium",
  date: new Date().toISOString().slice(0, 10),
  approved_by: "",
  remarks: "",
  pr_file_path: "",
  signature_file_path: "",
  prFile: null,
  signatureFile: null,
  items: [createEmptyItem()],
});

const parseIntegerOrNull = (value) => {
  if (value == null || value === "") return null;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  return parsed;
};

const formatDate = (value) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString();
};

const formatDateDmy = (value) => {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  const dd = String(date.getDate()).padStart(2, "0");
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const yyyy = String(date.getFullYear());
  return `${dd}.${mm}.${yyyy}`;
};

const formatPrNumber = (pr = {}) => {
  const sourceDate = pr.date || pr.created_at || new Date().toISOString();
  const parsed = new Date(sourceDate);
  const yyyy = parsed.getFullYear();
  const mm = String(parsed.getMonth() + 1).padStart(2, "0");
  const dd = String(parsed.getDate()).padStart(2, "0");
  const datePart = Number.isNaN(parsed.getTime()) ? "0000-00-00" : `${yyyy}-${mm}-${dd}`;
  const sequence = pr.pr_id || pr.id || "0";
  const project = pr.project_id || pr.projectId || "0";
  return `PR-${datePart}-${sequence}-${project}`;
};

const isImageFile = (path = "") => /\.(png|jpg|jpeg|gif|webp)$/i.test(path);
const isPdfFile = (path = "") => /\.pdf$/i.test(path);

const getAuthHeadersForFile = () => {
  try {
    const user = JSON.parse(localStorage.getItem("inventory_user") || "null");
    const token = user?.token;
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
};

const fetchFileAsBlob = async (url) => {
  if (!url) return null;
  // Some file endpoints are public; sending an Authorization header can trigger CORS preflight failures.
  // Try with auth first, then fall back to a plain fetch.
  try {
    const response = await fetch(url, { headers: getAuthHeadersForFile() });
    if (response.ok) return await response.blob();
  } catch {
    // continue to unauthenticated attempt
  }

  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    return await response.blob();
  } catch {
    return null;
  }
};

const getSignaturePreviewDataUrl = async (path = "") => {
  const url = path ? api.getApiFileUrl(path) : "";
  if (!url) return "";
  const blob = await fetchFileAsBlob(url);
  if (!blob || blob.size === 0) return "";

  const isPdf = blob.type === "application/pdf" || isPdfFile(path);
  if (isPdf) {
    const file = new File([blob], "signature.pdf", {
      type: blob.type || "application/pdf",
    });
    try {
      const images = await extractImagesFromPdf(file, {
        pageRange: { start: 1, end: 1 },
        maxPages: 1,
        batchSize: 1,
        scale: 1.2,
        quality: 0.9,
      });
      return images?.[0]?.imageDataUrl || "";
    } catch {
      return "";
    }
  }

  try {
    return await blobToDataUrl(blob);
  } catch {
    return "";
  }
};

const blobToDataUrl = (blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(blob);
  });

const ensurePdfCompatibleImageDataUrl = async (dataUrl = "") => {
  const value = String(dataUrl || "");
  if (!value.startsWith("data:image/")) return value;
  if (value.startsWith("data:image/png") || value.startsWith("data:image/jpeg") || value.startsWith("data:image/jpg")) {
    return value;
  }

  // jsPDF addImage is most reliable with PNG/JPEG; convert other raster types via canvas.
  try {
    const img = new Image();
    img.crossOrigin = "anonymous";
    const loaded = await new Promise((resolve, reject) => {
      img.onload = () => resolve(true);
      img.onerror = () => reject(new Error("Failed to load image"));
      img.src = value;
    });
    if (!loaded) return "";

    const canvas = document.createElement("canvas");
    canvas.width = img.naturalWidth || img.width || 0;
    canvas.height = img.naturalHeight || img.height || 0;
    const ctx = canvas.getContext("2d");
    if (!ctx || !canvas.width || !canvas.height) return "";
    ctx.drawImage(img, 0, 0);
    return canvas.toDataURL("image/png", 0.92);
  } catch {
    return "";
  }
};

const sniffFileKind = async (blob, path = "") => {
  const name = String(path || "");
  const ext = name.split(".").pop()?.toLowerCase() || "";
  try {
    const buf = await blob.slice(0, 32).arrayBuffer();
    const bytes = new Uint8Array(buf);

    // PDF: %PDF-
    if (bytes.length >= 5 && bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46 && bytes[4] === 0x2d) {
      return { kind: "pdf", mime: "application/pdf" };
    }
    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if (
      bytes.length >= 8 &&
      bytes[0] === 0x89 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x4e &&
      bytes[3] === 0x47 &&
      bytes[4] === 0x0d &&
      bytes[5] === 0x0a &&
      bytes[6] === 0x1a &&
      bytes[7] === 0x0a
    ) {
      return { kind: "image", mime: "image/png" };
    }
    // JPEG: FF D8 FF
    if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
      return { kind: "image", mime: "image/jpeg" };
    }
    // GIF: GIF8
    if (bytes.length >= 4 && bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x38) {
      return { kind: "image", mime: "image/gif" };
    }
    // WEBP: RIFF....WEBP
    if (
      bytes.length >= 12 &&
      bytes[0] === 0x52 &&
      bytes[1] === 0x49 &&
      bytes[2] === 0x46 &&
      bytes[3] === 0x46 &&
      bytes[8] === 0x57 &&
      bytes[9] === 0x45 &&
      bytes[10] === 0x42 &&
      bytes[11] === 0x50
    ) {
      return { kind: "image", mime: "image/webp" };
    }
  } catch {
    // Ignore sniff errors; fall back to extension.
  }

  if (ext === "pdf") return { kind: "pdf", mime: "application/pdf" };
  if (ext === "png") return { kind: "image", mime: "image/png" };
  if (ext === "jpg" || ext === "jpeg") return { kind: "image", mime: "image/jpeg" };
  if (ext === "webp") return { kind: "image", mime: "image/webp" };
  if (ext === "gif") return { kind: "image", mime: "image/gif" };

  return { kind: "unknown", mime: blob.type || "application/octet-stream" };
};

const parseMaybeJson = (value, fallback) => {
  if (typeof value !== "string") return value ?? fallback;
  const t = value.trim();
  if (!t) return fallback;
  try {
    return JSON.parse(t);
  } catch {
    return fallback;
  }
};

const normalizePr = (item = {}) => {
  const rawItems = parseMaybeJson(item.items ?? item.pr_items ?? item.prItems, []);
  return {
    ...item,
    pr_id: item.pr_id || item.id,
    project_id: item.project_id || item.projectId || null,
    sample_id: item.sample_id || item.sampleId || null,
    project_name: item.project_name || "-",
    workorder_no: item.workorder_no || "-",
    location: item.location || "-",
    mirno: item.mirno || "-",
    urgency: item.urgency || "Medium",
    date: item.date || item.created_at || null,
    approved_by: item.approved_by || "-",
    pr_file_path: item.pr_file_path || "",
    signature_file_path: item.signature_file_path || "",
    remarks: item.remarks || "",
    items: Array.isArray(rawItems) ? rawItems : [],
  };
};

function PrFormDialog({
  open,
  onOpenChange,
  mode,
  form,
  setForm,
  onSubmit,
  submitting,
  selectedProject,
  sampleOptions,
  loadingSamples,
}) {
  const title = mode === "edit" ? "Edit Purchase Request" : "Create Purchase Request";
  const selectedSampleMissing = Boolean(
    form.sample_id && !sampleOptions.some((sample) => String(sample.sample_id || sample.id) === form.sample_id)
  );

  const setField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const setItemField = (index, field, value) => {
    setForm((prev) => {
      const next = [...prev.items];
      next[index] = { ...next[index], [field]: value };
      return { ...prev, items: next };
    });
  };

  const addItem = () => {
    setForm((prev) => ({ ...prev, items: [...prev.items, createEmptyItem()] }));
  };

  const removeItem = (index) => {
    setForm((prev) => {
      if (prev.items.length <= 1) return prev;
      return { ...prev, items: prev.items.filter((_, i) => i !== index) };
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Fill PR header details, upload optional files, and add item rows.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Project ID *</Label>
            <Input
              value={form.project_id}
              onChange={(e) => setField("project_id", e.target.value)}
              placeholder="e.g. 5"
            />
          </div>
          <div className="space-y-2">
            <Label>Project Name *</Label>
            <Input
              value={form.project_name}
              onChange={(e) => setField("project_name", e.target.value)}
              placeholder={selectedProject?.project_name || "Project name"}
            />
          </div>
          <div className="space-y-2">
            <Label>Sample ID</Label>
            <Select
              value={form.sample_id || "none"}
              onValueChange={(value) => setField("sample_id", value === "none" ? "" : value)}
              disabled={loadingSamples}
            >
              <SelectTrigger>
                <SelectValue placeholder={loadingSamples ? "Loading samples..." : "Optional"} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {selectedSampleMissing ? (
                  <SelectItem value={form.sample_id}>Sample #{form.sample_id} (current)</SelectItem>
                ) : null}
                {sampleOptions.map((sample) => {
                  const id = String(sample.sample_id || sample.id);
                  const label = sample.work_done || sample.site_name || sample.building_name || `Sample #${id}`;
                  return (
                    <SelectItem key={id} value={id}>
                      {`#${id} - ${label}`}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Work Order No</Label>
            <Input
              value={form.workorder_no}
              onChange={(e) => setField("workorder_no", e.target.value)}
              placeholder="WO number"
            />
          </div>
          <div className="space-y-2">
            <Label>MIR No</Label>
            <Input
              value={form.mirno}
              onChange={(e) => setField("mirno", e.target.value)}
              placeholder="Optional"
            />
          </div>
          <div className="space-y-2">
            <Label>Urgency</Label>
            <Select value={form.urgency} onValueChange={(value) => setField("urgency", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select urgency" />
              </SelectTrigger>
              <SelectContent>
                {URGENCY_OPTIONS.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Date</Label>
            <Input value={form.date} onChange={(e) => setField("date", e.target.value)} type="date" />
          </div>
          <div className="space-y-2">
            <Label>Approved By</Label>
            <Input
              value={form.approved_by}
              onChange={(e) => setField("approved_by", e.target.value)}
              placeholder="Approver name"
            />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Location</Label>
            <Input
              value={form.location}
              onChange={(e) => setField("location", e.target.value)}
              placeholder="Site / location"
            />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Remarks</Label>
            <Textarea
              value={form.remarks}
              onChange={(e) => setField("remarks", e.target.value)}
              placeholder="Optional notes"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-base">PR Items</Label>
            <Button type="button" variant="outline" size="sm" onClick={addItem}>
              <Plus className="mr-2 h-4 w-4" /> Add Row
            </Button>
          </div>

          <div className="space-y-3">
            {form.items.map((item, index) => (
              <Card key={`item-${index}`}>
                <CardContent className="grid gap-3 p-4 md:grid-cols-12">
                  <div className="md:col-span-4">
                    <Label className="mb-1 block text-xs">Material Description *</Label>
                    <Input
                      value={item.material_description}
                      onChange={(e) => setItemField(index, "material_description", e.target.value)}
                      placeholder="Material"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="mb-1 block text-xs">Unit</Label>
                    <UnitSelect
                      value={item.unit}
                      onValueChange={(value) => {
                        const converted = convertQuantity(item.req_qty, item.unit, value);
                        setItemField(index, "unit", value);
                        if (converted != null) {
                          setItemField(index, "req_qty", converted);
                        }
                      }}
                      triggerClassName="h-9"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="mb-1 block text-xs">Qty *</Label>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={item.req_qty}
                      onChange={(e) => setItemField(index, "req_qty", e.target.value)}
                      placeholder="0"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="mb-1 block text-xs">Name</Label>
                    <Input
                      value={item.make}
                      onChange={(e) => setItemField(index, "make", e.target.value)}
                      placeholder="Name"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="mb-1 block text-xs">Place of Utilisation</Label>
                    <Input
                      value={item.place_of_utilisation}
                      onChange={(e) => setItemField(index, "place_of_utilisation", e.target.value)}
                      placeholder="Usage area"
                    />
                  </div>
                  <div className="md:col-span-12 flex justify-end">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeItem(index)}
                      disabled={form.items.length <= 1}
                    >
                      <X className="mr-2 h-4 w-4" /> Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onSubmit} disabled={submitting}>
            {submitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
              </>
            ) : mode === "edit" ? (
              "Update PR"
            ) : (
              "Create PR"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PrViewDialog({ open, onOpenChange, pr }) {
  const [signaturePreviewUrl, setSignaturePreviewUrl] = useState("");
  const [signatureLoadError, setSignatureLoadError] = useState(false);
  const [inventoryNameMap, setInventoryNameMap] = useState({});
  const [backpathLoading, setBackpathLoading] = useState(false);
  const [linkedPos, setLinkedPos] = useState([]);
  const [linkedDcs, setLinkedDcs] = useState([]);
  const prFileUrl = pr?.pr_file_path ? api.getApiFileUrl(pr.pr_file_path) : "";
  const signatureUrl = pr?.signature_file_path ? api.getApiFileUrl(pr.signature_file_path) : "";
  const hasSignatureFile = Boolean(pr?.signature_file_path);
  const signaturePath = String(pr?.signature_file_path || "");
  const signatureIsImage = hasSignatureFile && isImageFile(signaturePath);
  const signatureIsPdf = hasSignatureFile && isPdfFile(signaturePath);
  const extractMakeFromRemark = (value) => {
    const t = String(value || "").trim();
    if (!t) return "";
    const m = t.match(/\bmake\s*:\s*(.+)$/i);
    return m ? String(m[1] || "").trim() : "";
  };

  useEffect(() => {
    let mounted = true;
    const loadInventoryNames = async () => {
      if (!open || !pr) {
        if (mounted) setInventoryNameMap({});
        return;
      }
      const ids = Array.from(
        new Set(
          (Array.isArray(pr.items) ? pr.items : [])
            .map((item) => Number(item?.inventory_id))
            .filter((id) => Number.isFinite(id) && id > 0)
        )
      );
      if (ids.length === 0) {
        if (mounted) setInventoryNameMap({});
        return;
      }

      const entries = await Promise.all(
        ids.map(async (id) => {
          try {
            const res = await api.getInventoryChain(id);
            const item = res?.data?.item || {};
            const name = String(item.name || "").trim();
            return [id, name || null];
          } catch {
            return [id, null];
          }
        })
      );

      if (!mounted) return;
      const next = {};
      entries.forEach(([id, name]) => {
        if (name) next[id] = name;
      });
      setInventoryNameMap(next);
    };

    loadInventoryNames();
    return () => {
      mounted = false;
    };
  }, [open, pr?.pr_id]);

  useEffect(() => {
    let objectUrl = "";
    const loadSignature = async () => {
      if (!hasSignatureFile) {
        setSignaturePreviewUrl("");
        setSignatureLoadError(false);
        return;
      }
      setSignatureLoadError(false);

      // Images render fine via direct URL in <img>. Only attempt conversion for PDFs.
      if (signatureIsImage) {
        setSignaturePreviewUrl("");
        return;
      }

      const dataUrl = await getSignaturePreviewDataUrl(pr.signature_file_path);
      if (dataUrl) {
        setSignaturePreviewUrl(dataUrl);
        return;
      }
      const blob = await fetchFileAsBlob(signatureUrl);
      if (blob && blob.size > 0) {
        objectUrl = URL.createObjectURL(blob);
        setSignaturePreviewUrl(objectUrl);
      } else {
        setSignaturePreviewUrl("");
      }
    };
    loadSignature();
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [hasSignatureFile, pr?.signature_file_path, signatureUrl, signatureIsImage]);

  useEffect(() => {
    let mounted = true;
    const loadBackpath = async () => {
      const prId = pr?.pr_id;
      if (!open || !prId) {
        if (mounted) {
          setLinkedPos([]);
          setLinkedDcs([]);
        }
        return;
      }
      setBackpathLoading(true);
      try {
        const res = await api.getBackpathByPr(prId, { page: 1, limit: 200 });
        const payload = res?.success ? (res.data ?? res) : null;
        const pos = Array.isArray(payload?.pos) ? payload.pos : [];
        const dcs = Array.isArray(payload?.dcs) ? payload.dcs : [];
        if (!mounted) return;
        setLinkedPos(pos);
        setLinkedDcs(dcs);
      } catch {
        if (!mounted) return;
        setLinkedPos([]);
        setLinkedDcs([]);
      } finally {
        if (mounted) setBackpathLoading(false);
      }
    };
    loadBackpath();
    return () => {
      mounted = false;
    };
  }, [open, pr?.pr_id]);

  if (!pr) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>{formatPrNumber(pr)}</DialogTitle>
          <DialogDescription>Request details and uploaded documents.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 text-sm md:grid-cols-3">
          <div>
            <p className="text-muted-foreground">Project</p>
            <p className="font-medium">{pr.project_name}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Work Order</p>
            <p className="font-medium">{pr.workorder_no}</p>
          </div>
          <div>
            <p className="text-muted-foreground">MIR No</p>
            <p className="font-medium">{pr.mirno}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Date</p>
            <p className="font-medium">{formatDate(pr.date)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Urgency</p>
            <p className="font-medium">{pr.urgency}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Approved By</p>
            <div className="mt-2 w-full max-w-[220px]">
              <div className="flex h-20 items-center justify-center rounded border border-border bg-background">
                {!hasSignatureFile ? (
                  pr.approved_by ? (
                    <span className="text-xs font-medium text-muted-foreground">{pr.approved_by}</span>
                  ) : (
                    <span className="text-xs text-muted-foreground">No signature</span>
                  )
                ) : signatureIsImage ? (
                  signatureLoadError ? (
                    <Button asChild variant="outline" size="sm">
                      <a href={signatureUrl} target="_blank" rel="noreferrer">
                        <FileSignature className="mr-2 h-4 w-4" /> View Signature
                      </a>
                    </Button>
                  ) : (
                    <img
                      src={signatureUrl}
                      alt="Signature"
                      className="h-16 w-full object-contain px-2"
                      onError={() => setSignatureLoadError(true)}
                    />
                  )
                ) : signaturePreviewUrl ? (
                  <img
                    src={signaturePreviewUrl}
                    alt="Signature"
                    className="h-16 w-full object-contain px-2"
                  />
                ) : signatureIsPdf ? (
                  <Button asChild variant="outline" size="sm">
                    <a href={signatureUrl} target="_blank" rel="noreferrer">
                      <FileSignature className="mr-2 h-4 w-4" /> View Signature (PDF)
                    </a>
                  </Button>
                ) : (
                  <Button asChild variant="outline" size="sm">
                    <a href={signatureUrl} target="_blank" rel="noreferrer">
                      <FileSignature className="mr-2 h-4 w-4" /> View Signature
                    </a>
                  </Button>
                )}
              </div>
              <div className="mt-1 text-center text-xs font-semibold text-muted-foreground">Approved By</div>
            </div>
          </div>
          <div className="md:col-span-3">
            <p className="text-muted-foreground">Location</p>
            <p className="font-medium">{pr.location}</p>
          </div>
          {pr.remarks ? (
            <div className="md:col-span-3">
              <p className="text-muted-foreground">Remarks</p>
              <p className="font-medium">{pr.remarks}</p>
            </div>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-2">
          {prFileUrl ? (
            <Button asChild variant="outline" size="sm">
              <a href={prFileUrl} target="_blank" rel="noreferrer">
                <FileText className="mr-2 h-4 w-4" /> View PR File
              </a>
            </Button>
          ) : null}
          {signatureUrl ? (
            <Button asChild variant="outline" size="sm">
              <a href={signatureUrl} target="_blank" rel="noreferrer">
                <FileSignature className="mr-2 h-4 w-4" /> View Signature
              </a>
            </Button>
          ) : null}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Items ({pr.items.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[220px]">Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead>Place</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pr.items.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="h-16 text-center text-muted-foreground">
                      No items.
                    </TableCell>
                  </TableRow>
                ) : (
                  pr.items.map((item, idx) => (
                    <TableRow key={`${item.pr_item_id || idx}`}>
                      <TableCell className="font-medium">
                        {item.make || item.Make || extractMakeFromRemark(item.remark) || "-"}
                      </TableCell>
                      <TableCell>
                        {inventoryNameMap?.[Number(item?.inventory_id)] || item.material_description || "-"}
                      </TableCell>
                      <TableCell>{item.unit || "-"}</TableCell>
                      <TableCell>{item.req_qty ?? "-"}</TableCell>
                      <TableCell>{item.place_of_utilisation || "-"}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle className="text-sm">Linked Purchase Orders</CardTitle>
                <Badge variant="secondary">{linkedPos.length} PO(s)</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {backpathLoading ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Loading linked records…
                </div>
              ) : linkedPos.length === 0 ? (
                <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                  No PO linked to this PR.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">PO No</TableHead>
                      <TableHead className="w-[200px]">Created</TableHead>
                      <TableHead className="w-[140px]">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {linkedPos.map((po, idx) => (
                      <TableRow key={String(po?.po_id ?? po?.id ?? idx)}>
                        <TableCell className="font-medium">{po?.order_no || po?.po_no || po?.po_id || po?.id || "-"}</TableCell>
                        <TableCell>{po?.created_at ? formatDate(po.created_at) : "-"}</TableCell>
                        <TableCell>{po?.status || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle className="text-sm">Linked Delivery Challans (DC)</CardTitle>
                <Badge variant="secondary">{linkedDcs.length} DC(s)</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {backpathLoading ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Loading linked records…
                </div>
              ) : linkedDcs.length === 0 ? (
                <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                  No DC linked to this PR.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[200px]">DC No</TableHead>
                      <TableHead className="w-[200px]">Created</TableHead>
                      <TableHead className="w-[140px]">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {linkedDcs.map((dc, idx) => (
                      <TableRow key={String(dc?.dc_id ?? dc?.id ?? idx)}>
                        <TableCell className="font-medium">
                          {dc?.challan_number || dc?.dc_number || dc?.dc_no || dc?.dc_id || dc?.id || "-"}
                        </TableCell>
                        <TableCell>{dc?.created_at ? formatDate(dc.created_at) : "-"}</TableCell>
                        <TableCell>{dc?.status || "-"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function PurchaseRequests() {
  const navigate = useNavigate();
  const { projectId } = useParams();
  const { selectedProject } = useProject();
  const { toast } = useToast();

  const [prs, setPrs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [urgencyFilter, setUrgencyFilter] = useState("all");

  const [formOpen, setFormOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [editingPrId, setEditingPrId] = useState(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [deletingPrId, setDeletingPrId] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTargetPr, setDeleteTargetPr] = useState(null);
  const [linkingPrId, setLinkingPrId] = useState(null);
  const [selectedPr, setSelectedPr] = useState(null);
  const [form, setForm] = useState(createEmptyForm());
  const [sampleOptions, setSampleOptions] = useState([]);
  const [loadingSamples, setLoadingSamples] = useState(false);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [emailPr, setEmailPr] = useState(null);
  const [emailSending, setEmailSending] = useState(false);
  const [pdfDownloading, setPdfDownloading] = useState(false);
  const [poOfficerEmail, setPoOfficerEmail] = useState("");
  const [poOfficers, setPoOfficers] = useState([]);
  const [loadingPoOfficers, setLoadingPoOfficers] = useState(false);
  const [poOfficersError, setPoOfficersError] = useState("");
  const [selectedPoOfficerId, setSelectedPoOfficerId] = useState("");
  const [emailAttachments, setEmailAttachments] = useState([]);
  const [autoEmailAttachments, setAutoEmailAttachments] = useState([]);
  const [isFileDragActive, setIsFileDragActive] = useState(false);
  const [emailRemarks, setEmailRemarks] = useState("");
  const [emailLogs, setEmailLogs] = useState([]);
  const [loadingEmailLogs, setLoadingEmailLogs] = useState(false);

  const effectiveProjectId = useMemo(
    () => parseIntegerOrNull(projectId) || parseIntegerOrNull(selectedProject?.project_id || selectedProject?.id),
    [projectId, selectedProject]
  );

  const loadPrs = async ({ mode = "auto", sampleId } = {}) => {
    try {
      setLoading(true);

      let result;
      if (mode === "sample" && sampleId) {
        result = await api.getPrsBySample(sampleId);
      } else if (mode === "all") {
        result = await api.getPrs();
      } else {
        result = effectiveProjectId ? await api.getPrsByProject(effectiveProjectId) : await api.getPrs();
      }

      if (!result.success) {
        setPrs([]);
        toast({
          title: "Failed to load PRs",
          description: result.error || "Could not fetch purchase requests.",
          variant: "destructive",
        });
        return;
      }

      const rows = Array.isArray(result.data) ? result.data : [];
      setPrs(rows.map(normalizePr));
    } catch {
      setPrs([]);
      toast({
        title: "Failed to load PRs",
        description: "Could not fetch purchase requests.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPrs();
  }, [projectId, effectiveProjectId]);

  const handleLinkInventory = async (pr) => {
    if (!pr?.pr_id) return;
    setLinkingPrId(pr.pr_id);
    try {
      const result = await api.autoMatchPrInventory(pr.pr_id);
      if (!result.success) {
        toast({
          title: "Linking failed",
          description: result.error || "Could not link inventory items.",
          variant: "destructive",
        });
        return;
      }
      toast({
        title: "Inventory linked successfully",
        description: "Review the matches.",
      });
      await loadPrs();
    } catch (error) {
      toast({
        title: "Linking failed",
        description: error?.message || "Could not link inventory items.",
        variant: "destructive",
      });
    } finally {
      setLinkingPrId(null);
    }
  };

  useEffect(() => {
    let mounted = true;

    const loadSampleOptions = async () => {
      setLoadingSamples(true);
      try {
        const result = effectiveProjectId
          ? await api.getSamplesByProject(effectiveProjectId)
          : await api.getSamples();

        if (!mounted) return;
        if (!result.success || !Array.isArray(result.data)) {
          setSampleOptions([]);
          return;
        }

        const byId = new Map();
        result.data.forEach((sample) => {
          const id = sample?.sample_id ?? sample?.id;
          if (id == null || id === "") return;
          byId.set(String(id), sample);
        });
        setSampleOptions(Array.from(byId.values()));
      } catch {
        if (mounted) setSampleOptions([]);
      } finally {
        if (mounted) setLoadingSamples(false);
      }
    };

    loadSampleOptions();
    return () => {
      mounted = false;
    };
  }, [effectiveProjectId]);

  const totalItems = useMemo(
    () => prs.reduce((sum, pr) => sum + (Array.isArray(pr.items) ? pr.items.length : 0), 0),
    [prs]
  );

  const highUrgencyCount = useMemo(
    () => prs.filter((pr) => String(pr.urgency).toLowerCase() === "high").length,
    [prs]
  );

  const filteredPrs = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return prs.filter((pr) => {
      if (urgencyFilter !== "all" && String(pr.urgency).toLowerCase() !== urgencyFilter) {
        return false;
      }

      if (!normalizedQuery) return true;

      const haystack = [
        pr.pr_id,
        pr.project_name,
        pr.workorder_no,
        pr.location,
        pr.mirno,
        pr.approved_by,
      ]
        .map((value) => String(value || "").toLowerCase())
        .join(" ");

      return haystack.includes(normalizedQuery);
    });
  }, [prs, query, urgencyFilter]);

  const openEditDialog = (pr) => {
    setEditingPrId(pr.pr_id);
    setForm({
      project_id: pr.project_id ? String(pr.project_id) : "",
      sample_id: pr.sample_id ? String(pr.sample_id) : "",
      project_name: pr.project_name === "-" ? "" : pr.project_name,
      workorder_no: pr.workorder_no === "-" ? "" : pr.workorder_no,
      location: pr.location === "-" ? "" : pr.location,
      mirno: pr.mirno === "-" ? "" : pr.mirno,
      urgency: pr.urgency || "Medium",
      date: pr.date ? String(pr.date).slice(0, 10) : new Date().toISOString().slice(0, 10),
      approved_by: pr.approved_by === "-" ? "" : pr.approved_by,
      remarks: pr.remarks || "",
      pr_file_path: pr.pr_file_path || "",
      signature_file_path: pr.signature_file_path || "",
      prFile: null,
      signatureFile: null,
      items: Array.isArray(pr.items) && pr.items.length > 0
        ? pr.items.map((item) => ({
            material_description: item.material_description || "",
            unit: item.unit || "NOS",
            req_qty: item.req_qty ?? "",
            make: item.make || "",
            place_of_utilisation: item.place_of_utilisation || "",
          }))
        : [createEmptyItem()],
    });
    setFormOpen(true);
  };

  const openViewDialog = async (prId) => {
    const id = parseIntegerOrNull(prId);
    if (!id) return;

    const result = await api.getPrById(id);
    if (!result.success) {
      toast({
        title: "Failed to load PR",
        description: result.error || "Could not fetch PR details.",
        variant: "destructive",
      });
      return;
    }

    setSelectedPr(normalizePr(result.data || {}));
    setViewOpen(true);
  };

  const handleSubmitForm = async () => {
    const normalizedProjectId = parseIntegerOrNull(form.project_id);
    if (!normalizedProjectId) {
      toast({
        title: "Validation failed",
        description: "Project ID is required and must be a positive integer.",
        variant: "destructive",
      });
      return;
    }

    if (!String(form.project_name || "").trim()) {
      toast({
        title: "Validation failed",
        description: "Project name is required.",
        variant: "destructive",
      });
      return;
    }

    const cleanedItems = form.items
      .map((item) => ({
        material_description: String(item.material_description || "").trim(),
        unit: String(item.unit || "").trim() || "NOS",
        req_qty: Number(item.req_qty),
        make: String(item.make || "").trim(),
        place_of_utilisation: String(item.place_of_utilisation || "").trim(),
      }))
      .filter((item) => item.material_description && Number.isFinite(item.req_qty) && item.req_qty > 0);

    if (cleanedItems.length === 0) {
      toast({
        title: "Validation failed",
        description: "Add at least one item with description and quantity.",
        variant: "destructive",
      });
      return;
    }

    try {
      setFormSubmitting(true);

      let prFilePath = form.pr_file_path;
      let signatureFilePath = form.signature_file_path;

      if (form.prFile instanceof File) {
        const uploadResult = await api.uploadPrFile(form.prFile);
        if (!uploadResult.success) {
          toast({
            title: "PR file upload failed",
            description: uploadResult.error || "Could not upload PR file.",
            variant: "destructive",
          });
          return;
        }
        prFilePath = uploadResult.data?.filePath || "";
      }

      if (form.signatureFile instanceof File) {
        const signatureResult = await api.uploadPrSignature(form.signatureFile);
        if (!signatureResult.success) {
          toast({
            title: "Signature upload failed",
            description: signatureResult.error || "Could not upload signature file.",
            variant: "destructive",
          });
          return;
        }
        signatureFilePath = signatureResult.data?.filePath || "";
      }

      const payload = {
        project_id: normalizedProjectId,
        sample_id: parseIntegerOrNull(form.sample_id),
        project_name: String(form.project_name || "").trim(),
        workorder_no: String(form.workorder_no || "").trim(),
        location: String(form.location || "").trim(),
        mirno: String(form.mirno || "").trim(),
        urgency: form.urgency || "Medium",
        date: form.date || new Date().toISOString().slice(0, 10),
        approved_by: String(form.approved_by || "").trim(),
        remarks: String(form.remarks || "").trim(),
        pr_file_path: prFilePath,
        signature_file_path: signatureFilePath,
        items: cleanedItems,
      };

      const response = editingPrId
        ? await api.updatePr(editingPrId, payload)
        : await api.createPr(payload);

      if (!response.success) {
        toast({
          title: editingPrId ? "Update failed" : "Create failed",
          description: response.error || "Unable to save PR.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: editingPrId ? "PR updated" : "PR created",
        description: editingPrId
          ? "Purchase request updated successfully."
          : `Purchase request created successfully. ${formatPrNumber(response.data || { ...payload, pr_id: "new" })}`,
      });

      setFormOpen(false);
      setEditingPrId(null);
      await loadPrs();
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleDeletePr = async (prId) => {
    const id = parseIntegerOrNull(prId);
    if (!id) return;

    try {
      setDeletingPrId(id);
      const result = await api.deletePr(id);
      if (!result.success) {
        toast({
          title: "Delete failed",
          description: result.error || "Could not delete PR.",
          variant: "destructive",
        });
        return;
      }

      toast({ title: "PR deleted", description: "Purchase request removed successfully." });
      await loadPrs();
    } finally {
      setDeletingPrId(null);
    }
  };

  const openDeleteConfirm = (pr) => {
    const id = parseIntegerOrNull(pr?.pr_id ?? pr?.id ?? pr);
    if (!id) return;
    const label =
      typeof pr === "object" && pr
        ? formatPrNumber(pr)
        : `PR #${id}`;
    setDeleteTargetPr({ id, label });
    setDeleteConfirmOpen(true);
  };

  const closeDeleteConfirm = () => {
    if (deletingPrId) return;
    setDeleteConfirmOpen(false);
    setDeleteTargetPr(null);
  };

  const confirmDeletePr = async () => {
    if (!deleteTargetPr?.id) return;
    await handleDeletePr(deleteTargetPr.id);
    setDeleteConfirmOpen(false);
    setDeleteTargetPr(null);
  };

  const openEmailDialog = async (pr) => {
    setEmailPr(pr);
    setEmailDialogOpen(true);
    setPoOfficerEmail("");
    setSelectedPoOfficerId("");
    setPoOfficers([]);
    setPoOfficersError("");
    setEmailAttachments([]);
    setAutoEmailAttachments([]);
    setIsFileDragActive(false);
    setEmailRemarks("");
    setEmailLogs([]);

    if (pr?.signature_file_path) {
      try {
        const signatureUrl = api.getApiFileUrl(pr.signature_file_path);
        const signatureName = String(pr.signature_file_path).split("/").pop() || "signature";
        const blob = await fetchFileAsBlob(signatureUrl);
        if (blob && blob.size > 0) {
          setAutoEmailAttachments([new File([blob], signatureName, { type: blob.type || "application/octet-stream" })]);
        }
      } catch {
        setAutoEmailAttachments([]);
      }
    }

    if (pr?.pr_id || pr?.id) {
      try {
        setLoadingEmailLogs(true);
        const logResult = await api.getPrEmailLogs(pr.pr_id || pr.id);
        if (logResult.success && Array.isArray(logResult.data)) {
          setEmailLogs(logResult.data);
        } else {
          setEmailLogs([]);
        }
      } catch {
        setEmailLogs([]);
      } finally {
        setLoadingEmailLogs(false);
      }
    }
  };

  useEffect(() => {
    let active = true;

    const loadPoOfficers = async () => {
      setLoadingPoOfficers(true);
      setPoOfficersError("");
      try {
        const result = await api.getUsers();
        if (!active) return;
        if (result.success && Array.isArray(result.data)) {
          const normalized = result.data
            .map((user) => ({
              id: String(user.user_id ?? user.id ?? user._id ?? user.email ?? user.name ?? ""),
              name: String(user.name || user.username || user.email || "PO Officer"),
              email: String(user.email || ""),
              role: String(user.role || user.role_id || user.roleId || ""),
            }))
            .filter((user) => {
              const role = user.role.toLowerCase().replace(/[_\s-]+/g, "_");
              return role === "po_officer";
            })
            .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));

          setPoOfficers(normalized);

          if (normalized.length === 0) {
            setPoOfficerEmail("");
            setSelectedPoOfficerId("");
            return;
          }

          if (!selectedPoOfficerId && !poOfficerEmail.trim()) {
            const first = normalized[0];
            setSelectedPoOfficerId(first.id);
            setPoOfficerEmail(first.email || "");
          }
        } else if (result.success) {
          setPoOfficers([]);
          setPoOfficersError("No PO officers found.");
          setPoOfficerEmail("");
          setSelectedPoOfficerId("");
        } else {
          setPoOfficers([]);
          setPoOfficersError(result.error || "Failed to load PO officers.");
          setPoOfficerEmail("");
          setSelectedPoOfficerId("");
        }
      } catch {
        if (!active) return;
        setPoOfficers([]);
        setPoOfficersError("Failed to load PO officers.");
        setPoOfficerEmail("");
        setSelectedPoOfficerId("");
      } finally {
        if (active) setLoadingPoOfficers(false);
      }
    };

    if (emailDialogOpen) {
      loadPoOfficers();
    }

    return () => {
      active = false;
    };
  }, [emailDialogOpen]);


  const handleAttachmentSelect = (file) => {
    const normalized = [];

    if (file instanceof File) {
      normalized.push(file);
    } else if (file && typeof FileList !== "undefined" && file instanceof FileList) {
      Array.from(file).forEach((entry) => {
        if (entry instanceof File) normalized.push(entry);
      });
    } else if (Array.isArray(file)) {
      file.forEach((entry) => {
        if (entry instanceof File) normalized.push(entry);
      });
    }

    if (normalized.length === 0) return;
    setEmailAttachments(normalized);
  };

  const handleAttachmentDrop = (event) => {
    event.preventDefault();
    setIsFileDragActive(false);
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) handleAttachmentSelect(files);
  };

  const handleSendPrEmail = async () => {
    if (!emailPr) return;

    const to = String(poOfficerEmail || "").trim();
    if (!to) {
      toast({
        title: "Add PO officer email",
        description: "Enter the PO officer email address.",
        variant: "destructive",
      });
      return;
    }

    const poId =
      emailPr?.po_id ||
      emailPr?.poId ||
      emailPr?.po?.po_id ||
      emailPr?.po?.id ||
      emailPr?.purchase_order_id;

    try {
      setEmailSending(true);
      const attachmentFiles = [...autoEmailAttachments, ...emailAttachments];

      const result = poId
        ? await api.sendPoEmail({
            poId: Number(poId),
            to,
            attachmentFiles,
            message: String(emailRemarks || "").trim(),
          })
        : await api.sendPrEmail({
            prId: emailPr?.pr_id || emailPr?.id,
            to,
            attachmentFiles,
            message: String(emailRemarks || "").trim(),
          });

      if (!result.success) {
        toast({
          title: "Email failed",
          description: result.error || "Could not send PO email.",
          variant: "destructive",
        });
        return;
      }

      setEmailDialogOpen(false);
      setEmailPr(null);
      setPoOfficerEmail("");
      setEmailAttachments([]);
      setEmailRemarks("");
      setEmailLogs([]);
      toast({
        title: "Email sent",
        description: `PO sent to ${to}.`,
      });
    } finally {
      setEmailSending(false);
    }
  };

  const downloadMaterialRequestPdf = async (prInput, { signatureFile } = {}) => {
    if (!prInput) return;
    try {
      setPdfDownloading(true);
      const pr = normalizePr(prInput);
      const signatureUrl = pr.signature_file_path ? api.getApiFileUrl(pr.signature_file_path) : "";

      let signatureDataUrl = "";
      // Prefer the already-fetched signature file (auto attachment) if available.
      const autoSignatureFile = signatureFile instanceof File ? signatureFile : null;
      if (autoSignatureFile instanceof File && autoSignatureFile.size > 0) {
        try {
          const sniffed = await sniffFileKind(autoSignatureFile, autoSignatureFile.name);
          if (sniffed.kind === "pdf") {
            const images = await extractImagesFromPdf(autoSignatureFile, {
              pageRange: { start: 1, end: 1 },
              maxPages: 1,
              batchSize: 1,
              scale: 1.2,
              quality: 0.9,
            });
            signatureDataUrl = images?.[0]?.imageDataUrl || "";
          } else if (sniffed.kind === "image") {
            const typedBlob = autoSignatureFile.slice(0, autoSignatureFile.size, sniffed.mime);
            const dataUrl = await blobToDataUrl(typedBlob);
            signatureDataUrl = await ensurePdfCompatibleImageDataUrl(String(dataUrl || ""));
          }
        } catch {
          signatureDataUrl = "";
        }
      }

      if (!signatureDataUrl && signatureUrl && pr.signature_file_path) {
        try {
          const blob = await fetchFileAsBlob(signatureUrl);
          if (blob && blob.size > 0) {
            const sniffed = await sniffFileKind(blob, pr.signature_file_path);
            if (sniffed.kind === "pdf") {
              const file = new File([blob], "signature.pdf", { type: "application/pdf" });
              const images = await extractImagesFromPdf(file, {
                pageRange: { start: 1, end: 1 },
                maxPages: 1,
                batchSize: 1,
                scale: 1.2,
                quality: 0.9,
              });
              signatureDataUrl = images?.[0]?.imageDataUrl || "";
            } else if (sniffed.kind === "image") {
              const typedBlob = blob.slice(0, blob.size, sniffed.mime);
              const dataUrl = await blobToDataUrl(typedBlob);
              signatureDataUrl = await ensurePdfCompatibleImageDataUrl(String(dataUrl || ""));
            } else {
              // Last resort: try the existing helper (may still succeed for some cases).
              signatureDataUrl = await getSignaturePreviewDataUrl(pr.signature_file_path || "");
            }
          }
        } catch {
          signatureDataUrl = "";
        }
      }

      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      doc.setDrawColor(0);
      doc.setTextColor(0);

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 10;
      const frameX = margin;
      const frameY = margin;
      const frameW = pageWidth - margin * 2;
      const frameH = pageHeight - margin * 2;

      const titleH = 10;
      const headerRowH = 8;
      const headerRows = 5;
      const headerH = headerRowH * headerRows;
      const splitW = 130;
      const splitX = frameX + splitW;

      const renderFrame = () => {
        doc.setLineWidth(0.5);
        doc.rect(frameX, frameY, frameW, frameH);
      };

      const renderTitleAndHeader = () => {
        renderFrame();

        doc.setLineWidth(0.5);
        doc.line(frameX, frameY + titleH, frameX + frameW, frameY + titleH);

        doc.setFont("times", "bold");
        doc.setFontSize(14);
        doc.text("Material Request", frameX + frameW / 2, frameY + 7, { align: "center" });

        const headerY = frameY + titleH;
        doc.rect(frameX, headerY, frameW, headerH);
        doc.line(splitX, headerY, splitX, headerY + headerH);
        for (let i = 1; i < headerRows; i += 1) {
          doc.line(frameX, headerY + i * headerRowH, frameX + frameW, headerY + i * headerRowH);
        }

        const drawLabelValue = (label, value, x, y) => {
          doc.setFont("times", "bold");
          doc.setFontSize(10.5);
          doc.text(label, x, y);
          const labelW = doc.getTextWidth(label);
          doc.setFont("times", "normal");
          doc.text(String(value || "-"), x + labelW + 1, y);
        };

        const leftX = frameX + 2.5;
        const rightX = splitX + 2.5;
        const rowY = (index) => headerY + headerRowH * (index + 0.65);

        drawLabelValue("Project Name :-", pr.project_name || "-", leftX, rowY(0));
        drawLabelValue("Date :-", formatDateDmy(pr.date), rightX, rowY(0));
        drawLabelValue("Work Order No.:-", pr.workorder_no || "-", leftX, rowY(1));
        drawLabelValue("Location :-", pr.location || "-", leftX, rowY(2));

        const mrNo = pr.pr_id || pr.id || pr.mirno || "-";
        drawLabelValue("MR No. :-", mrNo, leftX, rowY(3));
        drawLabelValue("Urgency :-", pr.urgency || "-", leftX, rowY(4));
      };

      renderTitleAndHeader();

      const tableStartY = frameY + titleH + headerH;
      const items = Array.isArray(pr.items) ? pr.items : [];
      const minRows = 15;
      const tableRows = Array.from({ length: Math.max(items.length, minRows) }, (_, idx) => {
        const item = items[idx] || {};
        const hasItem = idx < items.length;
        return [
          hasItem ? String(idx + 1) : "",
          String(item.material_description || ""),
          String(item.unit || ""),
          item.req_qty == null ? "" : String(item.req_qty),
          String(item.make || ""),
          String(item.place_of_utilisation || ""),
        ];
      });

      autoTable(doc, {
        startY: tableStartY,
        margin: { left: frameX, right: frameX },
        tableWidth: frameW,
        theme: "grid",
        head: [["Sr. No.", "Material Description", "Unit", "Req. Qty.", "Make", "Place of Utilisation"]],
        body: tableRows,
        styles: {
          font: "times",
          fontSize: 9.5,
          cellPadding: 1.5,
          lineColor: [0, 0, 0],
          lineWidth: 0.2,
          textColor: [0, 0, 0],
          valign: "middle",
        },
        headStyles: {
          fontStyle: "bold",
          fillColor: [255, 255, 255],
          textColor: [0, 0, 0],
          lineColor: [0, 0, 0],
          lineWidth: 0.2,
        },
        columnStyles: {
          0: { cellWidth: 12, halign: "center" },
          1: { cellWidth: 85 },
          2: { cellWidth: 14, halign: "center" },
          3: { cellWidth: 20, halign: "center" },
          4: { cellWidth: 25 },
          5: { cellWidth: 34 },
        },
        didDrawPage: (data) => {
          if (data.pageNumber > 1) {
            renderFrame();
          }
        },
      });

      const footerH = 20;
      const footerY = pageHeight - margin - footerH;
      const lastTableY = doc.lastAutoTable?.finalY || tableStartY;
      if (lastTableY > footerY - 3) {
        doc.addPage();
        renderFrame();
      }

      const lastPageNumber = doc.getNumberOfPages();
      doc.setPage(lastPageNumber);

      const colW = frameW / 3;
      doc.setLineWidth(0.5);
      doc.line(frameX, footerY, frameX + frameW, footerY);
      doc.line(frameX + colW, footerY, frameX + colW, frameY + frameH);
      doc.line(frameX + colW * 2, footerY, frameX + colW * 2, frameY + frameH);

      doc.setFont("times", "bold");
      doc.setFontSize(10);
      doc.text("Requested BY :", frameX + colW / 2, footerY + footerH - 4, { align: "center" });
      doc.text("Checked By :", frameX + colW + colW / 2, footerY + footerH - 4, { align: "center" });
      doc.text("Approved By :", frameX + colW * 2 + colW / 2, footerY + footerH - 4, { align: "center" });

      // Draw signature box inside Approved By column
      const sigBoxW = colW - 16;
      const sigBoxH = 16;
      const sigBoxX = frameX + colW * 2 + 8;
      const sigBoxY = footerY + 2;
      doc.rect(sigBoxX, sigBoxY, sigBoxW, sigBoxH);

      if (signatureDataUrl && String(signatureDataUrl).startsWith("data:image/")) {
        const isPng = signatureDataUrl.startsWith("data:image/png");
        const isJpeg = signatureDataUrl.startsWith("data:image/jpeg") || signatureDataUrl.startsWith("data:image/jpg");
        const type = isPng ? "PNG" : isJpeg ? "JPEG" : "JPEG";
        const imgW = sigBoxW - 4;
        const imgH = sigBoxH - 4;
        const imgX = sigBoxX + 2;
        const imgY = sigBoxY + 2;
        doc.addImage(signatureDataUrl, type, imgX, imgY, imgW, imgH);
      } else if (pr.signature_file_path) {
        doc.setFont("times", "normal");
        doc.setFontSize(8);
        doc.text("Signature attached", frameX + colW * 2 + colW / 2, footerY + 10, { align: "center" });
      } else if (pr.approved_by && pr.approved_by !== "-") {
        doc.setFont("times", "normal");
        doc.setFontSize(9);
        doc.text(String(pr.approved_by), frameX + colW * 2 + colW / 2, footerY + 10, { align: "center" });
      }

      const filename = `Material-Request-${formatPrNumber(pr)}.pdf`;
      doc.save(filename);
    } catch {
      toast({
        title: "Download failed",
        description: "Could not generate the PDF.",
        variant: "destructive",
      });
    } finally {
      setPdfDownloading(false);
    }
  };

  const handleDownloadMaterialRequest = async () => {
    if (!emailPr) return;
    const signatureFile =
      Array.isArray(autoEmailAttachments) && autoEmailAttachments.length > 0 ? autoEmailAttachments[0] : null;
    await downloadMaterialRequestPdf(emailPr, { signatureFile });
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-border bg-gradient-to-r from-emerald-50 via-teal-50 to-white p-6 md:p-8 dark:from-slate-900 dark:via-slate-900 dark:to-slate-800/70">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="min-w-0">
            <h1 className="text-3xl font-bold tracking-tight">Purchase Requests</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Manage PR lifecycle with project-scoped API endpoints.
            </p>
          </div>
          <div className="grid w-full gap-2 sm:grid-cols-2 lg:flex lg:w-auto">
            <Button variant="outline" onClick={() => loadPrs()}>
              <RefreshCcw className="mr-2 h-4 w-4" /> Refresh
            </Button>
            <Button onClick={() => navigate("create")}>
              <Plus className="mr-2 h-4 w-4" /> Create PR
            </Button>
          </div>
        </div>
      </section>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-0 shadow-sm ring-1 ring-border/50 overflow-hidden">
          <CardHeader className="pb-2 bg-muted/10">
            <CardDescription>Total PRs</CardDescription>
            <CardTitle className="text-2xl">{prs.length}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="border-0 shadow-sm ring-1 ring-border/50 overflow-hidden">
          <CardHeader className="pb-2 bg-muted/10">
            <CardDescription>High Urgency</CardDescription>
            <CardTitle className="text-2xl">{highUrgencyCount}</CardTitle>
          </CardHeader>
        </Card>
        <Card className="border-0 shadow-sm ring-1 ring-border/50 overflow-hidden">
          <CardHeader className="pb-2 bg-muted/10">
            <CardDescription>Total Items</CardDescription>
            <CardTitle className="text-2xl">{totalItems}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Search and filter purchase requests.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-12">
          <div className="relative md:col-span-9">
            <Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by PR ID, project, WO, location, MIR..."
            />
          </div>

          <div className="md:col-span-3">
            <Select value={urgencyFilter} onValueChange={setUrgencyFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Urgency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Urgency</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm ring-1 ring-border/50 overflow-hidden">
        <CardHeader className="border-b bg-muted/20">
          <CardTitle>PR List</CardTitle>
          <CardDescription>All purchase requests for the selected scope.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="hidden md:block overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40">
                <TableHead>PR</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Work Order</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Urgency</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Files</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                    <span className="inline-flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" /> Loading purchase requests...
                    </span>
                  </TableCell>
                </TableRow>
              ) : filteredPrs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
                    No purchase requests found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredPrs.map((pr) => {
                  const urgency = String(pr.urgency || "").toLowerCase();
                  const urgencyClass =
                    urgency === "high"
                      ? "border-red-200 bg-red-50 text-red-700"
                      : urgency === "medium"
                      ? "border-amber-200 bg-amber-50 text-amber-700"
                      : "border-sky-200 bg-sky-50 text-sky-700";
                  const needsInventoryLink = (pr.items || []).some((item) => !item?.inventory_id);

                  return (
                    <TableRow
                      key={pr.pr_id}
                      className="cursor-pointer"
                      onClick={() => openViewDialog(pr.pr_id)}
                    >
                      <TableCell className="font-medium">{formatPrNumber(pr)}</TableCell>
                      <TableCell>
                        <div className="font-medium">{pr.project_name}</div>
                        <div className="text-xs text-muted-foreground">ID: {pr.project_id || "-"}</div>
                      </TableCell>
                      <TableCell>{pr.workorder_no}</TableCell>
                      <TableCell>
                        <span className="inline-flex items-center gap-1">
                          <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> {formatDate(pr.date)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={urgencyClass}>
                          {pr.urgency}
                        </Badge>
                      </TableCell>
                      <TableCell>{pr.items.length}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {pr.pr_file_path ? (
                            <Badge variant="secondary">
                              <FileText className="mr-1 h-3 w-3" /> PR
                            </Badge>
                          ) : null}
                          {pr.signature_file_path ? (
                            <Badge variant="secondary">
                              <FileSignature className="mr-1 h-3 w-3" /> Sign
                            </Badge>
                          ) : null}
                          {!pr.pr_file_path && !pr.signature_file_path ? (
                            <span className="text-xs text-muted-foreground">-</span>
                          ) : null}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="inline-flex justify-end" onClick={(e) => e.stopPropagation()}>
                          <RowActionsMenu
                            items={[
                              { key: "view", label: "View", icon: Eye, onSelect: () => openViewDialog(pr.pr_id) },
                              { key: "edit", label: "Edit", icon: Pencil, onSelect: () => openEditDialog(pr) },
                              { type: "separator" },
                              { key: "email", label: "Email", icon: Mail, onSelect: () => openEmailDialog(pr) },
                              { key: "download", label: "Download", icon: Download, onSelect: () => downloadMaterialRequestPdf(pr) },
                              needsInventoryLink ? {
                                key: "link",
                                label: linkingPrId === pr.pr_id ? "Linking..." : "Link to Inventory",
                                icon: Link2,
                                disabled: linkingPrId === pr.pr_id,
                                onSelect: () => handleLinkInventory(pr),
                              } : null,
                              { type: "separator" },
                              {
                                key: "delete",
                                label: deletingPrId === pr.pr_id ? "Deleting..." : "Delete",
                                icon: Trash2,
                                destructive: true,
                                disabled: deletingPrId === pr.pr_id,
                                onSelect: () => openDeleteConfirm(pr),
                              },
                            ]}
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
          </div>

          <div className="space-y-4 md:hidden">
            {loading ? (
              <div className="rounded-lg border p-6 text-center text-muted-foreground">
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> Loading purchase requests...
                </span>
              </div>
            ) : filteredPrs.length === 0 ? (
              <div className="rounded-lg border p-6 text-center text-muted-foreground">
                No purchase requests found.
              </div>
            ) : (
              filteredPrs.map((pr) => {
                const urgency = String(pr.urgency || "").toLowerCase();
                const urgencyClass =
                  urgency === "high"
                    ? "border-red-200 bg-red-50 text-red-700"
                    : urgency === "medium"
                    ? "border-amber-200 bg-amber-50 text-amber-700"
                    : "border-sky-200 bg-sky-50 text-sky-700";
                const needsInventoryLink = (pr.items || []).some((item) => !item?.inventory_id);

                return (
                  <div
                    key={pr.pr_id}
                    className="rounded-lg border p-4 space-y-3 cursor-pointer"
                    onClick={() => openViewDialog(pr.pr_id)}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 space-y-1">
                        <div className="font-semibold break-words">{formatPrNumber(pr)}</div>
                        <div className="text-sm text-muted-foreground break-words">{pr.project_name}</div>
                        <div className="text-xs text-muted-foreground">Project ID: {pr.project_id || "-"}</div>
                      </div>
                      <Badge variant="outline" className={urgencyClass}>
                        {pr.urgency}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-muted-foreground block">Work Order</span>
                        <span>{pr.workorder_no || "-"}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">Date</span>
                        <span className="inline-flex items-center gap-1">
                          <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> {formatDate(pr.date)}
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">Items</span>
                        <span>{pr.items.length}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">Files</span>
                        <div className="flex flex-wrap gap-1">
                          {pr.pr_file_path ? (
                            <Badge variant="secondary">
                              <FileText className="mr-1 h-3 w-3" /> PR
                            </Badge>
                          ) : null}
                          {pr.signature_file_path ? (
                            <Badge variant="secondary">
                              <FileSignature className="mr-1 h-3 w-3" /> Sign
                            </Badge>
                          ) : null}
                          {!pr.pr_file_path && !pr.signature_file_path ? (
                            <span className="text-xs text-muted-foreground">-</span>
                          ) : null}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2" onClick={(e) => e.stopPropagation()}>
                      <div className="flex justify-end">
                        <RowActionsMenu
                          items={[
                            { key: "view", label: "View", icon: Eye, onSelect: () => openViewDialog(pr.pr_id) },
                            { key: "edit", label: "Edit", icon: Pencil, onSelect: () => openEditDialog(pr) },
                            { type: "separator" },
                            { key: "email", label: "Email", icon: Mail, onSelect: () => openEmailDialog(pr) },
                            { key: "download", label: "Download", icon: Download, onSelect: () => downloadMaterialRequestPdf(pr) },
                            needsInventoryLink ? {
                              key: "link",
                              label: linkingPrId === pr.pr_id ? "Linking..." : "Link to Inventory",
                              icon: Link2,
                              disabled: linkingPrId === pr.pr_id,
                              onSelect: () => handleLinkInventory(pr),
                            } : null,
                            { type: "separator" },
                            {
                              key: "delete",
                              label: deletingPrId === pr.pr_id ? "Deleting..." : "Delete",
                              icon: Trash2,
                              destructive: true,
                              disabled: deletingPrId === pr.pr_id,
                              onSelect: () => openDeleteConfirm(pr),
                            },
                          ]}
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      <PrFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        mode={editingPrId ? "edit" : "create"}
        form={form}
        setForm={setForm}
        submitting={formSubmitting}
        onSubmit={handleSubmitForm}
        selectedProject={selectedProject}
        sampleOptions={sampleOptions}
        loadingSamples={loadingSamples}
      />

      <PrViewDialog open={viewOpen} onOpenChange={setViewOpen} pr={selectedPr} />

      <Dialog
        open={emailDialogOpen}
        onOpenChange={(open) => {
          setEmailDialogOpen(open);
          if (!open) {
            setEmailPr(null);
            setPdfDownloading(false);
            setPoOfficerEmail("");
            setEmailAttachments([]);
            setAutoEmailAttachments([]);
            setIsFileDragActive(false);
            setEmailRemarks("");
            setEmailLogs([]);
          }
        }}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Email Purchase Request</DialogTitle>
            <DialogDescription>
              Enter the PO officer email address to send this PR.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="rounded-lg border p-3 text-sm">
              <div><span className="font-medium">PR:</span> {emailPr ? formatPrNumber(emailPr) : "-"}</div>
              <div><span className="font-medium">Project:</span> {emailPr?.project_name || "-"}</div>
            </div>

            <div className="space-y-2">
              <Label>Attachment (optional)</Label>
              <label
                className={`flex cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed p-4 text-center transition-colors ${
                  isFileDragActive ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30"
                }`}
                onDragOver={(event) => {
                  event.preventDefault();
                  setIsFileDragActive(true);
                }}
                onDragLeave={() => setIsFileDragActive(false)}
                onDrop={handleAttachmentDrop}
              >
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onClick={(event) => {
                    event.currentTarget.value = "";
                  }}
                  onChange={(event) => handleAttachmentSelect(event.target.files)}
                />
                <Upload className="mb-2 h-5 w-5 text-muted-foreground" />
                <p className="text-sm font-medium">Drag and drop files here, or click to upload</p>
                <p className="text-xs text-muted-foreground">Selected files will be uploaded and attached when you send the email.</p>
              </label>
              {emailAttachments.length > 0 ? (
                <div className="space-y-2">
                  {emailAttachments.map((file) => {
                    const key = `${file.name}-${file.size}-${file.lastModified}`;
                    return (
                      <div key={key} className="flex items-center justify-between rounded-md border bg-muted/30 px-3 py-2 text-sm">
                        <span className="truncate">{file.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            setEmailAttachments((prev) =>
                              prev.filter((entry) => `${entry.name}-${entry.size}-${entry.lastModified}` !== key)
                            )
                          }
                        >
                          Remove
                        </Button>
                      </div>
                    );
                  })}
                  <div>
                    <Button type="button" variant="outline" size="sm" onClick={() => setEmailAttachments([])}>
                      Clear All
                    </Button>
                  </div>
                </div>
              ) : null}
              {autoEmailAttachments.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs text-muted-foreground">Auto attached</div>
                  {autoEmailAttachments.map((file) => {
                    const key = `${file.name}-${file.size}-${file.lastModified}`;
                    return (
                      <div key={key} className="flex items-center justify-between rounded-md border bg-muted/20 px-3 py-2 text-sm">
                        <span className="truncate">{file.name}</span>
                        <Badge variant="secondary">Signature</Badge>
                      </div>
                    );
                  })}
                </div>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label>Signature</Label>
              {emailPr?.signature_file_path ? (
                <div className="rounded-lg border bg-muted/20 p-3">
                  {isImageFile(emailPr.signature_file_path) ? (
                    <img
                      src={api.getApiFileUrl(emailPr.signature_file_path)}
                      alt="Signature"
                      className="max-h-40 w-full object-contain"
                    />
                  ) : (
                    <Button asChild variant="outline" size="sm">
                      <a href={api.getApiFileUrl(emailPr.signature_file_path)} target="_blank" rel="noreferrer">
                        <FileSignature className="mr-2 h-4 w-4" /> View Signature
                      </a>
                    </Button>
                  )}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">No signature uploaded for this PR.</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Remarks (optional)</Label>
              <Textarea
                value={emailRemarks}
                onChange={(event) => setEmailRemarks(event.target.value)}
                placeholder="Add any note for the PO officer..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>PO Officer Email</Label>
              <Select
                value={selectedPoOfficerId || ""}
                onValueChange={(value) => {
                  setSelectedPoOfficerId(value);
                  const selected = poOfficers.find((user) => user.id === value);
                  setPoOfficerEmail(selected?.email || "");
                }}
                disabled={loadingPoOfficers || poOfficers.length === 0}
              >
                <SelectTrigger>
                  <SelectValue
                    placeholder={loadingPoOfficers ? "Loading PO officers..." : "Select PO officer"}
                  />
                </SelectTrigger>
                <SelectContent>
                  {poOfficers.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.email || user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {poOfficersError ? (
                <p className="text-xs text-destructive">{poOfficersError}</p>
              ) : null}
              {!poOfficersError && !loadingPoOfficers && poOfficers.length === 0 ? (
                <p className="text-xs text-muted-foreground">No PO officers found.</p>
              ) : null}
            </div>

          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEmailDialogOpen(false)} disabled={emailSending}>
              Cancel
            </Button>
            <Button
              variant="outline"
              onClick={handleDownloadMaterialRequest}
              disabled={emailSending || pdfDownloading || !emailPr}
            >
              {pdfDownloading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Downloading
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" /> Download
                </>
              )}
            </Button>
            <Button onClick={handleSendPrEmail} disabled={emailSending || !poOfficerEmail.trim()}>
              {emailSending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending
                </>
              ) : (
                <>
                  <Mail className="mr-2 h-4 w-4" /> Send Email
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleteConfirmOpen}
        onOpenChange={(open) => {
          if (open) setDeleteConfirmOpen(true);
          else closeDeleteConfirm();
        }}
      >
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Delete purchase request?</DialogTitle>
            <DialogDescription>
              This will permanently delete {deleteTargetPr?.label || "this PR"}. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={closeDeleteConfirm} disabled={Boolean(deletingPrId)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDeletePr}
              disabled={Boolean(deletingPrId) || !deleteTargetPr?.id}
            >
              {deletingPrId === deleteTargetPr?.id ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
