import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Layers, Save, Copy, Upload, CheckCircle, FileText, Image as ImageIcon, ArrowRight, ArrowLeft, ChevronLeft, Eye, Loader2, Search, Filter, Download, Plus, Minus, Link2, Paperclip, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from 'xlsx';
import { extractImagesFromPdf, extractTextFromPdf } from "@/lib/pdfUtils";
import { extractCPVCData, mapCPVCItemsToSamples } from "@/lib/cpvcExtractor";
import { extractSuspendedWorkData, mapSuspendedWorkItemsToSamples } from "@/lib/suspendedWorkExtractor";
// Diagram/other-doc preview removed from Samples create flow.
import { useProject } from "@/contexts/useProject";
import { api } from "@/lib/api";
import { formatCurrencyINR } from "@/lib/numberFormat";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RowActionsMenu } from "@/components/RowActionsMenu";
import InventoryPicker from "@/components/InventoryPicker";

// Mock Sample Data (Floor-wise distribution)
const MOCK_SAMPLES = [
  { id: 1, item: "CPVC Pipe 2 inch", unit: "Mtr", perFloorQty: 42, totalFloors: 117, totalQty: 4914, status: "Locked" },
  { id: 2, item: "Wall Mounted WC", unit: "Nos", perFloorQty: 4, totalFloors: 117, totalQty: 468, status: "Locked" },
  { id: 3, item: "Basin Mixer", unit: "Nos", perFloorQty: 4, totalFloors: 117, totalQty: 468, status: "Draft" },
  { id: 4, item: "Shower Head", unit: "Nos", perFloorQty: 4, totalFloors: 117, totalQty: 468, status: "Draft" },
];

export default function Samples() {
  const location = useLocation();
  const navigate = useNavigate();
  const { projectId: routeProjectId } = useParams();
  const [step, setStep] = useState(1);
  const [floorCount, setFloorCount] = useState("");
  const [floorPlanFile, setFloorPlanFile] = useState(null);
  const [suspendedWorkFile, setSuspendedWorkFile] = useState(null);
  const [isConfigured, setIsConfigured] = useState(true);
  const [floorPlanPreview, setFloorPlanPreview] = useState(null);
  
  // PDF extraction state - CPVC
  const [extractedDiagrams, setExtractedDiagrams] = useState([]);
  const [extractedValues, setExtractedValues] = useState([]);
  const [processingPdf, setProcessingPdf] = useState(false);
  const [extractionProgress, setExtractionProgress] = useState({ current: 0, total: 0, message: '' });
  
  // PDF extraction state - Suspended Work
  const [suspendedDiagrams, setSuspendedDiagrams] = useState([]);
  const [suspendedValues, setSuspendedValues] = useState([]);
  const [processingSuspendedPdf, setProcessingSuspendedPdf] = useState(false);
  const [suspendedExtractionProgress, setSuspendedExtractionProgress] = useState({ current: 0, total: 0, message: '' });
  
  // UI state
  // Diagram/document viewer removed from Samples page.
  const [samples, setSamples] = useState(MOCK_SAMPLES);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all"); // "all", "cpvc", "suspended"
  const { toast } = useToast();
  const { selectedProject } = useProject();
  const projectId = selectedProject?.project_id || selectedProject?.id || routeProjectId || "";
  const isCreateRoute = /\/samples\/create\/?$/.test(String(location?.pathname || ""));
  const [serverSamples, setServerSamples] = useState([]);
  const [loadingServer, setLoadingServer] = useState(false);
  const [uploadFilePaths, setUploadFilePaths] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(() => isCreateRoute);
  const [linkingSampleId, setLinkingSampleId] = useState(null);
  const [linkedSampleIds, setLinkedSampleIds] = useState(() => new Set());
  const [selectedUploadedFile, setSelectedUploadedFile] = useState("");
  const [isAttachmentDragActive, setIsAttachmentDragActive] = useState(false);
  const [itemFieldDialogOpen, setItemFieldDialogOpen] = useState(false);
  const [itemFieldRowIndex, setItemFieldRowIndex] = useState(null);
  const [itemFieldKey, setItemFieldKey] = useState("");
  const [itemFieldValue, setItemFieldValue] = useState("");
  const [boqPickerOpen, setBoqPickerOpen] = useState(false);
  const [projectBoqItems, setProjectBoqItems] = useState([]);
  const [loadingProjectBoqItems, setLoadingProjectBoqItems] = useState(false);
  const [boqSearch, setBoqSearch] = useState("");
  const [activeBoqClient, setActiveBoqClient] = useState("");
  const [addingBoqKey, setAddingBoqKey] = useState(null);
  const [savingSample, setSavingSample] = useState(false);
  const [pendingBoqQty, setPendingBoqQty] = useState({});
  const [boqDescriptionPreview, setBoqDescriptionPreview] = useState(null);
  const [inventoryQtyStatus, setInventoryQtyStatus] = useState({});
  const [createForm, setCreateForm] = useState({
    building_name: "",
    site_name: "",
    sample_file: "",
    location: { floor: "", block: "", wing: "", coordinates: "" },
    item_description: [],
    add_fields: []
  });

  const getSelectedProjectId = () => selectedProject?.project_id || selectedProject?.id;
  const projectIdForInventory = useMemo(() => {
    const pid = getSelectedProjectId();
    const n = Number(pid);
    return Number.isFinite(n) ? n : null;
  }, [selectedProject]);

  useEffect(() => {
    // Keep UI in sync with route.
    setShowCreateForm(isCreateRoute);
  }, [isCreateRoute]);

  const extractUploadedFilePaths = (data) => {
    if (!data) return [];
    if (Array.isArray(data)) return data.filter((p) => typeof p === "string" && p.trim()).map((p) => p.trim());
    if (typeof data === "string") return data.trim() ? [data.trim()] : [];

    const candidates = [
      data.filePaths,
      data.file_paths,
      data.files,
      data.paths,
      data.filePath,
      data.file_path,
      data.path,
      data.url,
      data.data?.filePaths,
      data.data?.file_paths,
      data.data?.files,
      data.data?.paths,
      data.data?.filePath,
      data.data?.file_path,
      data.data?.path,
      data.data?.url,
    ].filter(Boolean);

    for (const candidate of candidates) {
      const extracted = extractUploadedFilePaths(candidate);
      if (extracted.length > 0) return extracted;
    }
    return [];
  };

  const isInsufficientStockError = (error) => /insufficient\s+stock/i.test(String(error || ""));

  // BOQ in sample-management should display the BOQ rows "as-is" from the API.
  // We still derive a minimal set of fields for rendering/actions without mutating the original item.
  const toFiniteNumber = (value) => {
    const n = Number(String(value ?? "").replace(/,/g, "").trim());
    return Number.isFinite(n) ? n : null;
  };

  const computeAmount = (qty, rate) => {
    const q = toFiniteNumber(qty);
    const r = toFiniteNumber(rate);
    if (q == null || r == null) return "";
    return String(q * r);
  };

  const pickFirst = (obj, keys) => {
    const source = obj && typeof obj === "object" ? obj : {};
    for (const key of keys) {
      const value = source?.[key];
      if (value == null) continue;
      if (typeof value === "string" && value.trim() === "") continue;
      return value;
    }
    return "";
  };

  const deriveBoqFields = (item) => {
    const raw = item && typeof item === "object" ? item : {};
    const qtyRaw = pickFirst(raw, ["quantity", "qty", "order_qty", "orderQty"]);
    const rateRaw = pickFirst(raw, ["rate", "unit_price", "unitPrice"]);
    const amountRaw = pickFirst(raw, ["amount", "value"]);
    const computedAmount = computeAmount(qtyRaw, rateRaw);
    return {
      id: raw?.boq_id ?? raw?.id ?? "",
      item_no: pickFirst(raw, ["item_no", "itemNo"]),
      item_code: pickFirst(raw, ["item_code", "itemCode", "code"]),
      section: pickFirst(raw, ["category", "section", "section_name", "sectionName"]),
      description: pickFirst(raw, ["description", "item_description", "service_description"]),
      unit: pickFirst(raw, ["unit", "uom", "UOM"]),
      qty: qtyRaw,
      rate: rateRaw,
      amount: computedAmount || amountRaw,
      hsn: pickFirst(raw, ["hsn", "hsn_sac_code"]),
      sac_code: pickFirst(raw, ["sac_code"]),
      client: pickFirst(raw, ["client", "client_format", "boq_client"]),
    };
  };

  const boqItemKey = (item) => {
    const derived = deriveBoqFields(item);
    const keyFromId = String(derived.id || "").trim();
    if (keyFromId) return keyFromId;
    const keyFromNo = String(derived.item_no || "").trim();
    const keyFromCode = String(derived.item_code || "").trim();
    if (keyFromNo) return keyFromNo;
    if (keyFromCode) return keyFromCode;
    return `${String(derived.description || "").trim()}__${String(derived.section || "").trim()}`;
  };

  const truncateWords = (value, maxWords = 10) => {
    const text = String(value || "").trim();
    if (!text) return "-";
    const parts = text.split(/\s+/).filter(Boolean);
    if (parts.length <= maxWords) return text;
    return `${parts.slice(0, maxWords).join(" ")}...`;
  };

  const formatMaybeCurrency = (value) => {
    if (value == null || value === "") return "-";
    const cleaned = String(value).replace(/,/g, "").trim();
    const n = Number(cleaned);
    return Number.isFinite(n) ? formatCurrencyINR(n) : String(value);
  };

  const getBoqAvailableQty = (boqItem) => {
    const derived = deriveBoqFields(boqItem);
    const raw = String(derived?.qty ?? "").replace(/,/g, "").trim();
    const num = Number(raw);
    if (!Number.isFinite(num)) return 0;
    return Math.max(0, num);
  };

  const readActiveBoqClient = (projectId) => {
    if (typeof window === "undefined") return "";
    const pid = String(projectId || "").trim();
    if (!pid) return "";
    try {
      return (localStorage.getItem(`boqClient:${pid}`) || "").trim().toLowerCase();
    } catch {
      return "";
    }
  };

  const matchesBoqClient = (item, client) => {
    const c = String(client || "").toLowerCase();
    if (!c) return true;
    const derived = deriveBoqFields(item);
    const explicit = String(derived?.client || "").trim().toLowerCase();
    if (explicit && explicit === c) return true;

    const itemNo = String(derived?.item_no || derived?.item_code || "").trim();
    const hasHsn = String(derived?.hsn || "").trim() !== "";
    const hasSac = String(derived?.sac_code || "").trim() !== "";
    const isLodhaNo = /^\d+(\.\d+){1,3}$/.test(itemNo);
    const isHiraNo = /^\(\d+\)$/.test(itemNo);
    const hasAnySignal = hasHsn || hasSac || isLodhaNo || isHiraNo;

    if (c === "lodha") {
      if (hasHsn || isLodhaNo) return true;
      if (!hasAnySignal) return true;
      if (hasSac || isHiraNo) return false;
      return true;
    }
    if (c === "hiranandani") {
      if (hasSac || isHiraNo) return true;
      if (!hasAnySignal) return true;
      if (hasHsn || isLodhaNo) return false;
      return true;
    }
    return true;
  };

  const linkedSamplesStorageKey = (projectId) => `linked_sample_ids_${String(projectId || "").trim()}`;

  const readLinkedSampleIdsFromStorage = (projectId) => {
    if (typeof window === "undefined") return [];
    const pid = String(projectId || "").trim();
    if (!pid) return [];
    try {
      const raw = localStorage.getItem(linkedSamplesStorageKey(pid));
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed.map((id) => String(id)).filter(Boolean) : [];
    } catch {
      return [];
    }
  };

  const persistLinkedSampleId = (projectId, sampleId) => {
    if (typeof window === "undefined") return;
    const pid = String(projectId || "").trim();
    const sid = String(sampleId || "").trim();
    if (!pid || !sid) return;
    const prev = readLinkedSampleIdsFromStorage(pid);
    const next = Array.from(new Set([...prev, sid]));
    try {
      localStorage.setItem(linkedSamplesStorageKey(pid), JSON.stringify(next));
    } catch {
      // ignore storage errors
    }
  };

  const normalizeInventory = (item = {}) => ({
    inventory_id: item.inventory_id || item.id,
    project_id: item.project_id,
    brand: item.brand || "",
    name: item.name || "",
    quantity: Number(item.current_quantity ?? item.quantity) || 0,
    price: Number(item.price) || 0,
    stockin: Boolean(item.stockin),
    billing: Boolean(item.billing),
  });

  const refreshProjectSamples = async () => {
    const pid = getSelectedProjectId();
    if (!pid) {
      setServerSamples([]);
      return [];
    }
    const res = await api.getSamplesByProject(pid);
    if (!res.success) {
      setServerSamples([]);
      return [];
    }
    const arr = Array.isArray(res.data) ? res.data : [];
    setServerSamples(arr);
    setLinkedSampleIds((prev) => {
      const stored = readLinkedSampleIdsFromStorage(pid);
      const next = new Set([...(prev || []), ...stored]);
      arr.forEach((sample) => {
        const sid = sample?.sample_id || sample?.id;
        if (!sid) return;
        if (sampleHasInventoryLinks(sample)) next.add(String(sid));
      });
      return next;
    });
    return arr;
  };

  const parseMaybeArray = (value) => {
    if (Array.isArray(value)) return value;
    if (typeof value === "string") {
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === "object") {
          const nested = parsed.items || parsed.item_description || parsed.rows || parsed.data;
          return Array.isArray(nested) ? nested : [];
        }
        return [];
      } catch {
        return [];
      }
    }
    if (value && typeof value === "object") {
      const candidates = [
        value.items,
        value.item_description,
        value.item_descriptions,
        value.data,
        value.rows,
      ];
      for (const candidate of candidates) {
        if (Array.isArray(candidate)) return candidate;
        if (typeof candidate === "string") {
          try {
            const parsed = JSON.parse(candidate);
            if (Array.isArray(parsed)) return parsed;
            if (parsed && typeof parsed === "object") {
              const nested = parsed.items || parsed.item_description || parsed.rows || parsed.data;
              if (Array.isArray(nested)) return nested;
            }
          } catch {
            // ignore
          }
        }
      }
    }
    return [];
  };

  const sampleHasInventoryLinks = (sample) => {
    const normalizeKey = (value) => String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const items = parseMaybeArray(sample?.item_description || sample?.items || sample?.item_descriptions);
    if (!Array.isArray(items)) return false;
    return items.some((item) => {
      const directInventoryId =
        item?.inventory_id ??
        item?.inventoryId ??
        item?.inventoryID ??
        item?.inventory?.inventory_id ??
        item?.inventory?.id;
      if (directInventoryId) return true;
      const fields = parseMaybeArray(item?.add_fields);
      if (!Array.isArray(fields)) return false;
      return fields.some((field) => {
        const key = normalizeKey(field?.key);
        return key === "inventoryid" || key === "inventory_id";
      });
    });
  };

  const handleLinkSampleInventory = async (sample) => {
    const sampleId = sample?.sample_id || sample?.id;
    if (!sampleId) return;
    setLinkingSampleId(sampleId);
    try {
      const res = await api.autoMatchSampleInventory(sampleId);
      if (!res.success) {
        toast({
          title: "Linking failed",
          description: res.error || "Could not link inventory items.",
          variant: "destructive",
        });
        return;
      }
      // Hide the action immediately even if the backend takes time to reflect the link.
      setLinkedSampleIds((prev) => {
        const next = new Set(prev);
        next.add(String(sampleId));
        return next;
      });
      persistLinkedSampleId(getSelectedProjectId(), sampleId);
      toast({ title: "Inventory linked successfully", description: "Review the matches." });
      await refreshProjectSamples();
    } catch (error) {
      toast({
        title: "Linking failed",
        description: error?.message || "Could not link inventory items.",
        variant: "destructive",
      });
    } finally {
      setLinkingSampleId(null);
    }
  };

  useEffect(() => {
    const pid = getSelectedProjectId();
    if (!pid) {
      setLinkedSampleIds(new Set());
      return;
    }
    const stored = readLinkedSampleIdsFromStorage(pid);
    setLinkedSampleIds(new Set(stored));
  }, [selectedProject]);

  const refreshProjectBoqItems = async () => {
    const pid = getSelectedProjectId();
    if (!pid) {
      setProjectBoqItems([]);
      return [];
    }

    let client = readActiveBoqClient(pid);

    // Fetch raw BOQ rows so the picker shows items exactly as stored on the server.
    const res = await api.getBOQsByProject(pid);
    if (!res.success) {
      setProjectBoqItems([]);
      toast({
        title: "Failed to load BOQ items",
        description: res.error || "Could not fetch BOQ items for this project.",
        variant: "destructive",
      });
      return [];
    }

    const payload = res.data || {};
    const items = Array.isArray(payload)
      ? payload
      : Array.isArray(payload?.boqs)
        ? payload.boqs
        : Array.isArray(payload?.items)
          ? payload.items
          : Array.isArray(payload?.data)
            ? payload.data
            : [];

    if (!client) {
      const derivedAll = items.map(deriveBoqFields);
      const hasLodhaSignal =
        derivedAll.some((it) => String(it.hsn || "").trim()) ||
        derivedAll.some((it) => /^\d+(\.\d+){1,3}$/.test(String(it.item_no || it.item_code || "").trim()));
      const hasHiraSignal =
        derivedAll.some((it) => String(it.sac_code || "").trim()) ||
        derivedAll.some((it) => /^\(\d+\)$/.test(String(it.item_no || it.item_code || "").trim()));
      if (hasHiraSignal && !hasLodhaSignal) client = "hiranandani";
      else if (hasLodhaSignal && !hasHiraSignal) client = "lodha";
    }

    setActiveBoqClient(client);
    const arr = items.filter((it) => matchesBoqClient(it, client));
    setProjectBoqItems(arr);
    return arr;
  };

  useEffect(() => {
    const load = async () => {
      setLoadingServer(true);
      try {
        await refreshProjectSamples();
      } catch {
        setServerSamples([]);
      } finally {
        setLoadingServer(false);
      }
    };
    load();
  }, [selectedProject]);

  useEffect(() => {
    if (!selectedProject) return;
    const projectFloorsRaw = selectedProject?.floors ?? selectedProject?.floor ?? "";
    const projectFloors = projectFloorsRaw == null ? "" : String(projectFloorsRaw).trim();
    if (!projectFloors) return;
    setFloorCount((prev) => (prev ? prev : projectFloors));
  }, [selectedProject]);

  useEffect(() => {
    if (!showCreateForm) return;
    // Prefill commonly repeated fields from the selected project when opening the form.
    if (selectedProject) {
      const projectBuilding = String(
        selectedProject?.building_name ||
          selectedProject?.project_name ||
          selectedProject?.name ||
          ""
      ).trim();
      const projectSite = String(
        selectedProject?.site_name ||
          selectedProject?.location ||
          ""
      ).trim();
      const projectFloorsRaw = selectedProject?.floors ?? selectedProject?.floor ?? "";
      const projectFloors = projectFloorsRaw == null ? "" : String(projectFloorsRaw).trim();
      setCreateForm((prev) => ({
        ...prev,
        building_name: prev.building_name || projectBuilding,
        site_name: prev.site_name || projectSite,
        location: {
          ...prev.location,
          floor: prev.location?.floor || projectFloors,
        },
      }));
    }
    const load = async () => {
      setLoadingProjectBoqItems(true);
      try {
        await refreshProjectBoqItems();
      } finally {
        setLoadingProjectBoqItems(false);
      }
    };
    load();
  }, [showCreateForm, selectedProject]);


  const saveCreate = async () => {
    if (savingSample) return;
    const pid = selectedProject?.project_id || selectedProject?.id;
    if (!pid) {
      toast({ title: "Select project", description: "Choose a project first.", variant: "destructive" });
      return;
    }

    const invalidInventory = (createForm.item_description || [])
      .map((item, index) => {
        const inventoryId = item?.inventory_id ? Number(item.inventory_id) : null;
        if (!inventoryId || !Number.isFinite(inventoryId)) return null;
        const status = inventoryQtyStatus?.[index];
        if (!status || status.valid !== false) return null;
        return { index, inventoryId, ...status };
      })
      .filter(Boolean);

    if (invalidInventory.length > 0) {
      const first = invalidInventory[0];
      toast({
        title: "Validation failed",
        description: `Row ${first.index + 1}: requested qty (${first.requestedQty}) exceeds available (${first.availableQty}).`,
        variant: "destructive",
      });
      return;
    }

    setSavingSample(true);
    try {
      const selectedFilePath = createForm.sample_file || "";
      const normalizedItems = Array.isArray(createForm.item_description)
        ? createForm.item_description
        : parseMaybeArray(createForm.item_description);
      const basePayload = {
        project_id: pid,
        building_name: createForm.building_name,
        site_name: createForm.site_name,
        sample_file: selectedFilePath,
        location: createForm.location,
        item_description: normalizedItems,
        // Some backend deployments expect `items` instead of `item_description`.
        items: normalizedItems,
        add_fields: createForm.add_fields
      };

      const res = await api.createSample(basePayload);
      if (res.success) {
        const created = res.data || {};
        const createdId = created.sample_id || created.id;
        if (createdId && selectedFilePath && !created.sample_file) {
          try {
            await api.updateSample(createdId, { sample_file: selectedFilePath });
          } catch {
            // Non-blocking: user can still attach from the table actions.
          }
        }

        // After successful sample creation, deduct BOQ quantities for any BOQ-derived rows.
        try {
          const deductRes = await deductBoqQuantitiesForSampleItems(pid, normalizedItems);
          if (!deductRes?.success) {
            toast({
              title: "Sample created, BOQ not updated",
              description: deductRes?.error || "Could not deduct BOQ quantities.",
              variant: "destructive",
            });
          } else if ((deductRes?.data?.failed || 0) > 0) {
            toast({
              title: "Sample created with partial BOQ updates",
              description: `${deductRes.data.updated || 0} updated, ${deductRes.data.failed} failed.`,
              variant: "destructive",
            });
          } else {
            await refreshProjectBoqItems();
          }
        } catch (error) {
          toast({
            title: "Sample created, BOQ not updated",
            description: error?.message || "Could not deduct BOQ quantities.",
            variant: "destructive",
          });
        }

        await refreshProjectSamples();
        setCreateForm({
          building_name: "",
          site_name: "",
          sample_file: "",
          location: { floor: "", block: "", wing: "", coordinates: "" },
          item_description: [],
          add_fields: []
        });
        setInventoryQtyStatus({});
        toast({ title: "Created", description: "Sample created" });
        if (isCreateRoute) {
          navigate(`/${pid}/samples`);
        } else {
          setShowCreateForm(false);
        }
      } else {
        toast({
          title: isInsufficientStockError(res.error) ? "Insufficient stock" : "Create failed",
          description: res.error || "Error",
          variant: "destructive",
        });
      }
    } finally {
      setSavingSample(false);
    }
  };

  const removeSample = async (sample) => {
    const id = sample.sample_id || sample.id;
    const res = await api.deleteSample(id);
    if (res.success) {
      await refreshProjectSamples();
      toast({ title: "Deleted", description: "Sample deleted" });
    } else {
      toast({ title: "Delete failed", description: res.error || "Error", variant: "destructive" });
    }
  };

  const openItemFieldDialog = (_target, rowIndex) => {
    setItemFieldRowIndex(rowIndex);
    setItemFieldKey("");
    setItemFieldValue("");
    setItemFieldDialogOpen(true);
  };

  const closeItemFieldDialog = () => {
    setItemFieldDialogOpen(false);
    setItemFieldRowIndex(null);
    setItemFieldKey("");
    setItemFieldValue("");
  };

  const addItemFieldToRow = () => {
    const key = itemFieldKey.trim();
    const value = itemFieldValue.trim();

    if (!key || !value || itemFieldRowIndex === null) {
      toast({ title: "Missing values", description: "Enter both key and value.", variant: "destructive" });
      return;
    }

    const next = [...createForm.item_description];
    const existingIndex = (next[itemFieldRowIndex].add_fields || []).findIndex(
      (field) => (field?.key || "").trim() === key
    );
    const nextFields = [...(next[itemFieldRowIndex].add_fields || [])];
    if (existingIndex >= 0) {
      nextFields[existingIndex] = { key, value };
    } else {
      nextFields.push({ key, value });
    }
    next[itemFieldRowIndex] = {
      ...next[itemFieldRowIndex],
      add_fields: nextFields
    };
    setCreateForm({ ...createForm, item_description: next });

    closeItemFieldDialog();
  };

  const removeItemFieldFromRow = (_target, rowIndex, fieldIndex) => {
    const next = [...createForm.item_description];
    next[rowIndex] = {
      ...next[rowIndex],
      add_fields: (next[rowIndex].add_fields || []).filter((_, idx) => idx !== fieldIndex)
    };
    setCreateForm({ ...createForm, item_description: next });
  };

  const hasIncompleteAdditionalFields = (fields = []) =>
    fields.some((field) => !(field.key || "").trim() || !(field.value || "").trim());

  const addAdditionalField = (_target) => {
    if (hasIncompleteAdditionalFields(createForm.add_fields)) {
      toast({
        title: "Complete existing fields",
        description: "Fill key and value before adding another additional info row.",
        variant: "destructive",
      });
      return;
    }
    setCreateForm({ ...createForm, add_fields: [...createForm.add_fields, { key: "", value: "" }] });
  };

  const removeAdditionalField = (_target, index) => {
    setCreateForm({ ...createForm, add_fields: createForm.add_fields.filter((_, idx) => idx !== index) });
  };

  const openPreview = (sample) => {
    const id = sample.sample_id || sample.id;
    navigate(`preview/${id}`);
  };

  const deductBoqQuantitiesForSampleItems = async (projectId, sampleItems) => {
    const pid = String(projectId || "").trim();
    if (!pid) return { success: false, error: "Missing project id" };

    const rows = Array.isArray(sampleItems) ? sampleItems : [];
    const getField = (row, key) =>
      (row?.add_fields || []).find((f) => String(f?.key || "").trim() === key)?.value ?? "";
    const normalizeEmptyLike = (v) => {
      const t = String(v ?? "").trim();
      if (!t) return "";
      const n = t.toLowerCase();
      if (n === "-" || n === "_" || n === "na" || n === "n/a" || n === "null" || n === "undefined") return "";
      return t;
    };
    const normalizeMatchText = (value) => String(value || "").trim().toLowerCase();

    const deductions = rows
      .map((row) => ({
        boq_id: normalizeEmptyLike(getField(row, "boq_id")),
        item_no: normalizeEmptyLike(getField(row, "item_no")),
        item_code: normalizeEmptyLike(getField(row, "item_code")),
        section: normalizeEmptyLike(getField(row, "section")),
        description: normalizeEmptyLike(getField(row, "description")),
        selected_qty: Number(String(getField(row, "selected_qty") || "").replace(/,/g, "").trim()) || 0,
      }))
      .filter((d) => d.selected_qty > 0 && (d.boq_id || d.item_no || d.item_code || d.description));

    if (deductions.length === 0) return { success: true, data: { updated: 0, failed: 0 } };

    const normalizeFullBoqItem = (apiItem) => ({
      id: apiItem?.boq_id ?? apiItem?.id,
      code: apiItem?.item_code ?? apiItem?.code ?? apiItem?.item_no,
      item_code: apiItem?.item_code,
      item_no: apiItem?.item_no ?? apiItem?.itemNo,
      section: apiItem?.category ?? apiItem?.section ?? apiItem?.section_name ?? apiItem?.sectionName,
      description: apiItem?.description ?? apiItem?.item_description ?? apiItem?.service_description,
      qty: apiItem?.quantity ?? apiItem?.qty ?? apiItem?.order_qty ?? apiItem?.orderQty,
    });

    const fullRes = await api.getBOQsByProject(pid);
    const fullRows = fullRes?.success
      ? (Array.isArray(fullRes.data)
          ? fullRes.data
          : Array.isArray(fullRes.data?.boqs)
            ? fullRes.data.boqs
            : Array.isArray(fullRes.data?.data)
              ? fullRes.data.data
              : [])
      : [];

    if (!fullRes?.success) {
      return { success: false, error: fullRes?.error || "Could not fetch BOQ items for deduction." };
    }

    const normalized = fullRows.map(normalizeFullBoqItem).filter((r) => r?.id != null);

    // Resolve each deduction to a BOQ row and aggregate by BOQ id.
    const aggregateByBoqId = new Map(); // id -> qtyToDeduct
    let failedMatches = 0;
    for (const d of deductions) {
      const directBoqId = d.boq_id ? Number(d.boq_id) || d.boq_id : "";
      if (directBoqId) {
        const directMatch = normalized.find((row) => String(row.id) === String(directBoqId));
        if (!directMatch) {
          failedMatches += 1;
          continue;
        }
        aggregateByBoqId.set(directMatch.id, (aggregateByBoqId.get(directMatch.id) || 0) + d.selected_qty);
        continue;
      }

      const targetItemNo = normalizeMatchText(d.item_no);
      const targetItemCode = normalizeMatchText(d.item_code);
      const targetDesc = normalizeMatchText(d.description);
      const targetSection = normalizeMatchText(d.section);

      const match = normalized.find((row) => {
        const rowNo = normalizeMatchText(row.item_no || row.code || "");
        const rowCode = normalizeMatchText(row.item_code || row.code || "");
        const rowDesc = normalizeMatchText(row.description || "");
        const rowSection = normalizeMatchText(row.section || "");

        if (targetItemNo && rowNo && rowNo === targetItemNo) return true;
        if (targetItemCode && rowCode && rowCode === targetItemCode) return true;
        if (targetDesc && rowDesc && rowDesc === targetDesc && (!targetSection || rowSection === targetSection)) return true;
        return false;
      });

      if (!match) {
        failedMatches += 1;
        continue;
      }
      aggregateByBoqId.set(match.id, (aggregateByBoqId.get(match.id) || 0) + d.selected_qty);
    }

    let updated = 0;
    let failed = failedMatches;
    for (const [boqId, qtyToDeduct] of aggregateByBoqId.entries()) {
      const match = normalized.find((r) => r.id === boqId);
      if (!match) {
        failed += 1;
        continue;
      }
      const currentQty = Number(String(match.qty ?? "").replace(/,/g, "").trim());
      const safeCurrent = Number.isFinite(currentQty) ? currentQty : 0;
      const nextQty = Math.max(0, safeCurrent - qtyToDeduct);
      const updateRes = await api.updateBOQ(match.id, { quantity: String(nextQty) });
      if (updateRes?.success) updated += 1;
      else failed += 1;
    }

    return { success: failed === 0, data: { updated, failed } };
  };

  const addBoqItemToSampleItems = (boqItem, selectedQty) => {
    const derived = deriveBoqFields(boqItem);
    const key = boqItemKey(boqItem);
    if (!key) return;

    const qtyToAdd = Number(selectedQty) || 0;
    if (qtyToAdd <= 0) return;
    const rateNum = (() => {
      const cleaned = String(derived.rate ?? "").replace(/,/g, "").trim();
      const n = Number(cleaned);
      return Number.isFinite(n) ? n : 0;
    })();
    const selectedAmount = rateNum && qtyToAdd ? rateNum * qtyToAdd : 0;
    const nextRow = {
      _row_type: "boq",
      sr_no: String(createForm.item_description.length + 1),
      description: String(derived.description || "-"),
      quantity: qtyToAdd ? String(qtyToAdd) : "",
      value: selectedAmount ? String(selectedAmount) : "",
      add_fields: [
        { key: "boq_id", value: String(derived.id || "") },
        { key: "boq_key", value: String(key) },
        { key: "item_code", value: String(derived.item_code || "-") },
        { key: "item_no", value: String(derived.item_no || "-") },
        { key: "section", value: String(derived.section || "-") },
        { key: "description", value: String(derived.description || "-") },
        { key: "unit", value: String(derived.unit || "-") },
        // Show selected quantity in the sample items table (not the BOQ total qty).
        { key: "qty", value: qtyToAdd ? String(qtyToAdd) : "" },
        // Keep BOQ qty for reference (not shown in the main table by default).
        { key: "boq_qty", value: String(derived.qty || "") },
        { key: "rate", value: String(derived.rate || "") },
        // Amount for the selected quantity.
        { key: "amount", value: selectedAmount ? String(selectedAmount) : "" },
        { key: "hsn", value: String(derived.hsn || "") },
        { key: "sac_code", value: String(derived.sac_code || "") },
        { key: "selected_qty", value: qtyToAdd ? String(qtyToAdd) : "" },
        { key: "project_id", value: String(getSelectedProjectId() || "") },
      ],
    };

    const toFiniteNumber = (value) => {
      const n = Number(String(value ?? "").replace(/,/g, "").trim());
      return Number.isFinite(n) ? n : 0;
    };

    const getFieldValue = (row, fieldKey) =>
      (row?.add_fields || []).find((f) => String(f?.key || "").trim() === fieldKey)?.value ?? "";

    const setFieldValue = (row, fieldKey, value) => {
      const list = Array.isArray(row?.add_fields) ? [...row.add_fields] : [];
      const idx = list.findIndex((f) => String(f?.key || "").trim() === fieldKey);
      if (idx >= 0) list[idx] = { ...list[idx], value };
      else list.push({ key: fieldKey, value });
      return { ...row, add_fields: list };
    };

    setCreateForm((prev) => {
      const rows = Array.isArray(prev.item_description) ? [...prev.item_description] : [];
      const existingIndex = rows.findIndex((r) => String(getFieldValue(r, "boq_key") || "") === String(key));

      if (existingIndex < 0) {
        return { ...prev, item_description: [...rows, nextRow] };
      }

      const existing = rows[existingIndex] || {};
      const existingQty =
        toFiniteNumber(existing?.quantity) ||
        toFiniteNumber(getFieldValue(existing, "selected_qty")) ||
        toFiniteNumber(getFieldValue(existing, "qty")) ||
        0;
      const nextQty = existingQty + qtyToAdd;

      const effectiveRate =
        toFiniteNumber(getFieldValue(existing, "rate")) ||
        toFiniteNumber(derived.rate) ||
        0;
      const nextAmount = effectiveRate && nextQty ? effectiveRate * nextQty : 0;

      let merged = {
        ...existing,
        _row_type: "boq",
        description: String(existing.description || derived.description || "-"),
        quantity: nextQty ? String(nextQty) : "",
        value: nextAmount ? String(nextAmount) : "",
      };
      merged = setFieldValue(merged, "qty", nextQty ? String(nextQty) : "");
      merged = setFieldValue(merged, "selected_qty", nextQty ? String(nextQty) : "");
      merged = setFieldValue(merged, "amount", nextAmount ? String(nextAmount) : "");
      if (effectiveRate) merged = setFieldValue(merged, "rate", String(effectiveRate));

      rows[existingIndex] = merged;
      return { ...prev, item_description: rows };
    });
  };

  const addManualSampleItemRow = () => {
    setCreateForm((prev) => {
      const rows = Array.isArray(prev.item_description) ? prev.item_description : [];
      return {
        ...prev,
        item_description: [
          ...rows,
          {
            _row_type: "manual",
            sr_no: String(rows.length + 1),
            description: "",
            quantity: "",
            value: "",
            inventory_id: null,
            issued_qty: null,
          },
        ],
      };
    });
  };

  const updateManualSampleItemRow = (index, patch) => {
    setCreateForm((prev) => {
      const rows = Array.isArray(prev.item_description) ? [...prev.item_description] : [];
      const existing = rows[index] || {};
      rows[index] = { ...existing, ...patch };
      return { ...prev, item_description: rows };
    });
  };

  const removeSampleItemRowAt = (index) => {
    setCreateForm((prev) => {
      const rows = Array.isArray(prev.item_description) ? prev.item_description : [];
      return { ...prev, item_description: rows.filter((_, i) => i !== index) };
    });
    setInventoryQtyStatus((prev) => {
      const mapped = {};
      Object.entries(prev || {}).forEach(([key, value]) => {
        const idx = Number(key);
        if (!Number.isInteger(idx)) return;
        if (idx === index) return;
        mapped[idx > index ? idx - 1 : idx] = value;
      });
      return mapped;
    });
  };

  const openBoqQtySelector = (boqItem) => {
    const key = boqItemKey(boqItem);
    if (!key) return;
    const remaining = getBoqRemainingQty(boqItem);
    if (remaining <= 0) {
      toast({
        title: "Qty is 0",
        description: "You cannot add an item with zero quantity.",
        variant: "destructive",
      });
      return;
    }
    const maxAllowed = remaining > 0 ? Math.min(999999, Math.floor(remaining)) : 999999;
    setPendingBoqQty((prev) => {
      const existing = Number(prev[key]) || 1;
      const clamped = Math.max(1, Math.min(maxAllowed, existing));
      return { ...prev, [key]: String(clamped) };
    });
  };

  const adjustPendingBoqQty = (boqItem, delta) => {
    const key = boqItemKey(boqItem);
    if (!key) return;
    const remaining = getBoqRemainingQty(boqItem);
    const maxAllowed = remaining > 0 ? Math.min(999999, Math.floor(remaining)) : 999999;
    setPendingBoqQty((prev) => {
      const current = Number(prev[key]) || 1;
      const next = Math.max(1, Math.min(maxAllowed, current + delta));
      return { ...prev, [key]: String(next) };
    });
  };

  const setPendingBoqQtyValue = (boqItem, rawValue) => {
    const key = boqItemKey(boqItem);
    if (!key) return;
    const remaining = getBoqRemainingQty(boqItem);
    const maxAllowed = remaining > 0 ? Math.min(999999, Math.floor(remaining)) : 999999;
    const cleaned = String(rawValue || "").replace(/[^\d]/g, "");
    if (!cleaned) {
      setPendingBoqQty((prev) => ({ ...prev, [key]: "" }));
      return;
    }
    const numeric = Math.max(1, Number(cleaned) || 1);
    const clamped = Math.max(1, Math.min(maxAllowed, numeric));
    setPendingBoqQty((prev) => ({ ...prev, [key]: String(clamped) }));
  };

  const normalizePendingBoqQty = (boqItem) => {
    const key = boqItemKey(boqItem);
    if (!key) return;
    const remaining = getBoqRemainingQty(boqItem);
    const maxAllowed = remaining > 0 ? Math.min(999999, Math.floor(remaining)) : 999999;
    setPendingBoqQty((prev) => {
      const current = Number(prev[key]) || 1;
      const next = Math.max(1, Math.min(maxAllowed, current));
      return { ...prev, [key]: String(next) };
    });
  };

  const closeBoqQtySelector = (key) => {
    setPendingBoqQty((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const confirmAddBoqWithQuantity = async (boqItem) => {
    const key = boqItemKey(boqItem);
    const selectedQty = Number(pendingBoqQty[key]) || 0;
    const remaining = getBoqRemainingQty(boqItem);

    if (remaining <= 0) {
      toast({
        title: "Qty is 0",
        description: "You cannot add an item with zero quantity.",
        variant: "destructive",
      });
      return;
    }

    if (!key || selectedQty <= 0) {
      toast({ title: "Invalid quantity", description: "Select a valid quantity.", variant: "destructive" });
      return;
    }

    if (selectedQty > remaining) {
      toast({
        title: "Quantity exceeds BOQ qty",
        description: `BOQ remaining quantity is ${remaining}. Please select ${remaining} or less.`,
        variant: "destructive",
      });
      return;
    }

    setAddingBoqKey(key);
    try {
      addBoqItemToSampleItems(boqItem, selectedQty);
      closeBoqQtySelector(key);
      toast({
        title: "Item added",
        description: `Added ${selectedQty}.`,
      });
    } finally {
      setAddingBoqKey(null);
    }
  };

  const filteredProjectBoqItems = useMemo(() => {
    const query = boqSearch.trim().toLowerCase();
    if (!query) return projectBoqItems;
    return projectBoqItems.filter((item) => (
      String(deriveBoqFields(item).item_no || "").toLowerCase().includes(query)
      || String(deriveBoqFields(item).item_code || "").toLowerCase().includes(query)
      || String(deriveBoqFields(item).description || "").toLowerCase().includes(query)
      || String(deriveBoqFields(item).section || "").toLowerCase().includes(query)
      || String(deriveBoqFields(item).unit || "").toLowerCase().includes(query)
    ));
  }, [projectBoqItems, boqSearch]);

  const inventoryTableKeys = useMemo(() => {
    // Show only the fields the user cares about in the "items added" table.
    // Order: Description -> Section -> Unit -> Qty -> Amount
    const preferredOrder = ["description", "section", "unit", "qty", "amount"];
    const dynamicKeys = Array.from(
      new Set(
        createForm.item_description.flatMap((row) =>
          (row.add_fields || [])
            .map((field) => (field?.key || "").trim())
            .filter(Boolean)
        )
      )
    );
    if (createForm.item_description.length > 0) {
      ["description", "qty", "amount"].forEach((k) => {
        if (!dynamicKeys.includes(k)) dynamicKeys.push(k);
      });
    }
    const ordered = preferredOrder.filter((key) => dynamicKeys.includes(key));
    return ordered;
  }, [createForm.item_description]);

  const boqReservedQtyByKey = useMemo(() => {
    const rows = Array.isArray(createForm.item_description) ? createForm.item_description : [];
    const normalize = (v) => String(v || "").trim().toLowerCase();
    const normalizeEmptyLike = (v) => {
      const t = String(v ?? "").trim();
      if (!t) return "";
      const n = t.toLowerCase();
      if (n === "-" || n === "_" || n === "na" || n === "n/a" || n === "null" || n === "undefined") return "";
      return t;
    };
    const fieldVal = (row, key) =>
      (row?.add_fields || []).find((f) => String(f?.key || "").trim() === key)?.value ?? "";

    const deriveReserveKeyFromFields = (row) => {
      const boqId = normalize(normalizeEmptyLike(fieldVal(row, "boq_id")));
      const itemNo = normalize(normalizeEmptyLike(fieldVal(row, "item_no")));
      const itemCode = normalize(normalizeEmptyLike(fieldVal(row, "item_code")));
      const description = normalize(normalizeEmptyLike(fieldVal(row, "description")));
      const section = normalize(normalizeEmptyLike(fieldVal(row, "section")));
      return boqId || itemNo || itemCode || (description ? `${description}__${section}` : "");
    };

    const map = new Map();
    for (const row of rows) {
      const selectedQtyRaw = fieldVal(row, "selected_qty");
      const selectedQty = Number(String(selectedQtyRaw || "").replace(/,/g, "").trim()) || 0;
      if (selectedQty <= 0) continue;
      const key = deriveReserveKeyFromFields(row);
      if (!key) continue;
      map.set(key, (map.get(key) || 0) + selectedQty);
    }
    return map;
  }, [createForm.item_description]);

  useEffect(() => {
    const pid = getSelectedProjectId();
    if (!pid) return;
    // Persist reserved BOQ quantities so BOQ screen can show remaining qty while drafting a sample.
    // Note: this is client-side reservation only; server-side deduction happens on sample save.
    try {
      const key = `boqReservedQty:${String(pid)}`;
      const entries = Array.from(boqReservedQtyByKey.entries()).map(([k, v]) => [k, v]);
      if (entries.length === 0) localStorage.removeItem(key);
      else localStorage.setItem(key, JSON.stringify(entries));
    } catch {
      // ignore storage failures
    }
  }, [boqReservedQtyByKey, selectedProject, showCreateForm]);

  const getBoqRemainingQty = (boqItem) => {
    const baseQty = getBoqAvailableQty(boqItem);
    const derived = deriveBoqFields(boqItem);
    const normalize = (v) => String(v || "").trim().toLowerCase();
    const normalizeEmptyLike = (v) => {
      const t = String(v ?? "").trim();
      if (!t) return "";
      const n = t.toLowerCase();
      if (n === "-" || n === "_" || n === "na" || n === "n/a" || n === "null" || n === "undefined") return "";
      return t;
    };
    const boqId = normalize(normalizeEmptyLike(derived?.id));
    const itemNo = normalize(normalizeEmptyLike(derived?.item_no));
    const itemCode = normalize(normalizeEmptyLike(derived?.item_code));
    const description = normalize(normalizeEmptyLike(derived?.description));
    const section = normalize(normalizeEmptyLike(derived?.section));
    const key = boqId || itemNo || itemCode || (description ? `${description}__${section}` : "");
    const reserved = key ? Number(boqReservedQtyByKey.get(key) || 0) : 0;
    return Math.max(0, baseQty - reserved);
  };


  const attachFileToSample = async (sample, path) => {
    const id = sample.sample_id || sample.id;
    const res = await api.updateSample(id, { sample_file: path });
    if (res.success) {
      await refreshProjectSamples();
      toast({ title: "Attached", description: "Document attached to sample" });
    } else {
      toast({ title: "Attach failed", description: res.error || "Error", variant: "destructive" });
    }
  };

  const uploadSampleFiles = async (files) => {
    if (!files.length) return;
    const res = await api.uploadSampleFiles(files);
    const paths = res.success ? extractUploadedFilePaths(res.data) : [];
    if (paths.length > 0) {
      setUploadFilePaths((prev) => Array.from(new Set([...prev, ...paths])));
      setCreateForm((prev) => ({
        ...prev,
        sample_file: prev.sample_file || paths[0] || "",
      }));
      toast({ title: "Uploaded", description: `${paths.length} file(s) uploaded` });
    } else {
      toast({ title: "Upload failed", description: res.error || "Error", variant: "destructive" });
    }
  };

  const handleSampleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    await uploadSampleFiles(files);
    e.target.value = "";
  };

  const handleAttachmentDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsAttachmentDragActive(false);
    const files = Array.from(e.dataTransfer?.files || []);
    await uploadSampleFiles(files);
  };

  const handleFloorPlanUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      setFloorPlanFile(file);
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFloorPlanPreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else if (file.type === 'application/pdf') {
        // Process PDF to extract diagrams and values
        setProcessingPdf(true);
        setExtractionProgress({ current: 0, total: 0, message: 'Loading PDF...' });
        try {
          // Validate file size (max 50MB)
          if (file.size > 50 * 1024 * 1024) {
            throw new Error('PDF file is too large (max 50MB)');
          }
          
          // Extract images from PDF (optimized: lower scale, fewer pages, parallel processing)
          setExtractionProgress({ current: 0, total: 1, message: 'Extracting diagrams...' });
          let images = [];
          try {
            images = await extractImagesFromPdf(file, { 
              scale: 1.5, // Reduced from 2 for faster processing
              maxPages: 30, // Reduced from 50
              batchSize: 3, // Process 3 pages in parallel
              quality: 0.85 // JPEG quality for smaller files
            });
            setExtractedDiagrams(images);
            console.log(`Extracted ${images.length} diagram pages`);
          } catch (imgError) {
            console.warn('Image extraction failed, continuing with text extraction:', imgError);
            // Continue even if image extraction fails
          }
          
          setExtractionProgress({ current: 1, total: 2, message: 'Extracting text and values...' });
          
          // Extract text and parse CPVC data (optimized: limit pages, parallel processing)
          let text = '';
          try {
            text = await extractTextFromPdf(file, { 
              fullDocument: true, 
              preserveLines: true,
              maxPages: 50, // Limit to 50 pages instead of 150
              batchSize: 5 // Process 5 pages in parallel
            });
            console.log(`Extracted ${text.length} characters of text`);
          } catch (textError) {
            console.error('Text extraction failed:', textError);
            throw new Error(`Text extraction failed: ${textError.message}`);
          }
          
          const cpvcData = extractCPVCData(text);
          setExtractedValues(cpvcData.items);
          console.log(`Parsed ${cpvcData.items.length} CPVC items from text`);
          
          // Update floor count if found in PDF
          if (cpvcData.metadata.totalFloors && !floorCount) {
            setFloorCount(cpvcData.metadata.totalFloors);
          }
          
          // Optionally auto-populate samples from extracted data
          if (cpvcData.items.length > 0) {
            const totalFloors = parseInt(floorCount) || parseInt(cpvcData.metadata.totalFloors) || 1;
            const mappedSamples = mapCPVCItemsToSamples(cpvcData.items, totalFloors);
            if (mappedSamples.length > 0) {
              // Replace mock samples with extracted ones, or merge if we want to keep existing
              const shouldReplace = samples.length === MOCK_SAMPLES.length && 
                                    samples.every((s, i) => s.id === MOCK_SAMPLES[i]?.id);
              
              if (shouldReplace) {
                setSamples(mappedSamples);
              } else {
                // Merge with existing, avoiding duplicates
                const existingIds = new Set(samples.map(s => s.id));
                const newSamples = mappedSamples.filter(s => !existingIds.has(s.id));
                setSamples([...samples, ...newSamples]);
              }
              
              toast({
                title: "CPVC Data Extracted",
                description: `Extracted ${mappedSamples.length} items from CPVC PDF`,
              });
            } else {
              toast({
                title: "No Items Found",
                description: "Could not extract items from CPVC PDF. Please check the PDF format.",
                variant: "destructive",
              });
            }
          } else {
            toast({
              title: "No Items Extracted",
              description: "No CPVC items found in the PDF. The PDF might not contain extractable data.",
              variant: "destructive",
            });
          }
          
          // Set first page as preview - ensure it's set properly
          if (images.length > 0) {
            const firstImage = images[0].imageDataUrl;
            setFloorPlanPreview(firstImage);
            // Force update by setting a small delay to ensure state updates
            setTimeout(() => {
              if (floorPlanPreview !== firstImage) {
                setFloorPlanPreview(firstImage);
              }
            }, 100);
          } else {
            // If no images extracted, show a placeholder or the PDF file icon
            setFloorPlanPreview(null);
          }
          
          // Log extraction results for debugging
          console.log('CPVC Extraction Results:', {
            diagrams: images.length,
            items: cpvcData.items.length,
            metadata: cpvcData.metadata,
            sampleItems: (Array.isArray(cpvcData.items) ? cpvcData.items.length : 0)
          });
          
          setExtractionProgress({ current: 2, total: 2, message: 'Complete!' });
        } catch (error) {
          console.error('Error processing CPVC PDF:', error);
          const errorMessage = error.message || 'Unknown error occurred';
          toast({
            title: "Extraction Error",
            description: `Failed to extract data from CPVC PDF: ${errorMessage}. Please check if the PDF is valid and not corrupted.`,
            variant: "destructive",
          });
          
          // Still set the file so user can proceed
          if (extractedDiagrams.length === 0) {
            setFloorPlanPreview(null);
          }
        } finally {
          setProcessingPdf(false);
          setTimeout(() => setExtractionProgress({ current: 0, total: 0, message: '' }), 1000);
        }
      } else {
        setFloorPlanPreview(null);
      }
    }
  };

  const handleSuspendedWorkUpload = async (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      setSuspendedWorkFile(file);
      // Process suspended work PDF
      setProcessingSuspendedPdf(true);
      setSuspendedExtractionProgress({ current: 0, total: 0, message: 'Loading PDF...' });
      try {
        // Validate file size
        if (file.size > 50 * 1024 * 1024) {
          throw new Error('PDF file is too large (max 50MB)');
        }
        
        // Extract images from PDF (optimized: lower scale, fewer pages, parallel processing)
        setSuspendedExtractionProgress({ current: 0, total: 1, message: 'Extracting diagrams...' });
        let images = [];
        try {
          images = await extractImagesFromPdf(file, { 
            scale: 1.5, // Reduced from 2 for faster processing
            maxPages: 30, // Reduced from 50
            batchSize: 3, // Process 3 pages in parallel
            quality: 0.85 // JPEG quality for smaller files
          });
          setSuspendedDiagrams(images);
          console.log(`Extracted ${images.length} diagram pages from suspended work PDF`);
        } catch (imgError) {
          console.warn('Image extraction failed, continuing with text extraction:', imgError);
          // Continue even if image extraction fails
        }
        
        setSuspendedExtractionProgress({ current: 1, total: 2, message: 'Extracting text and values...' });
        
        // Extract text and parse suspended work data (optimized: limit pages, parallel processing)
        let text = '';
        try {
          text = await extractTextFromPdf(file, { 
            fullDocument: true, 
            preserveLines: true,
            maxPages: 50, // Limit to 50 pages instead of 150
            batchSize: 5 // Process 5 pages in parallel
          });
          console.log(`Extracted ${text.length} characters of text from suspended work PDF`);
        } catch (textError) {
          console.error('Text extraction failed:', textError);
          throw new Error(`Text extraction failed: ${textError.message}`);
        }
        
        const suspendedData = extractSuspendedWorkData(text);
        setSuspendedValues(suspendedData.items);
        console.log(`Parsed ${suspendedData.items.length} suspended work items from text`);
        
        // Update floor count if found in PDF
        if (suspendedData.metadata.totalFloors && !floorCount) {
          setFloorCount(suspendedData.metadata.totalFloors);
        }
        
        // Merge suspended work items with existing samples
        if (suspendedData.items.length > 0) {
          const totalFloors = parseInt(floorCount) || parseInt(suspendedData.metadata.totalFloors) || 1;
          const mappedSuspended = mapSuspendedWorkItemsToSamples(suspendedData.items, totalFloors);
          
          if (mappedSuspended.length > 0) {
            // Combine with existing samples (avoid duplicates)
            const existingIds = new Set(samples.map(s => s.id));
            const newSuspended = mappedSuspended.filter(s => !existingIds.has(s.id));
            setSamples([...samples, ...newSuspended]);
            toast({
              title: "Suspended Work Data Extracted",
              description: `Extracted ${mappedSuspended.length} items from suspended work PDF`,
            });
          } else {
            toast({
              title: "No Items Found",
              description: "Could not extract items from suspended work PDF. Please check the PDF format.",
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "No Items Extracted",
            description: "No suspended work items found in the PDF. The PDF might not contain extractable data.",
            variant: "destructive",
          });
        }
        
        setSuspendedExtractionProgress({ current: 2, total: 2, message: 'Complete!' });
        
        // Log extraction results for debugging
        console.log('Suspended Work Extraction Results:', {
          diagrams: images.length,
          items: suspendedData.items.length,
          metadata: suspendedData.metadata,
          sampleItems: (Array.isArray(suspendedData.items) ? suspendedData.items.length : 0)
        });
      } catch (error) {
        console.error('Error processing suspended work PDF:', error);
        const errorMessage = error.message || 'Unknown error occurred';
        toast({
          title: "Extraction Error",
          description: `Failed to extract data from suspended work PDF: ${errorMessage}. Please check if the PDF is valid and not corrupted.`,
          variant: "destructive",
        });
      } finally {
        setProcessingSuspendedPdf(false);
        setTimeout(() => setSuspendedExtractionProgress({ current: 0, total: 0, message: '' }), 1000);
      }
    } else if (file) {
      setSuspendedWorkFile(file);
      toast({
        title: "Invalid File",
        description: "Please upload a PDF file for suspended work",
        variant: "destructive",
      });
    }
  };

  const handleNext = () => {
    if (step === 1 && floorCount && floorPlanFile) {
      setStep(2);
    }
  };

  const handleBack = () => {
    if (step === 2) {
      setStep(1);
    }
  };

  const handleCheckFloorPlan = () => {
    // Proceed if we have floor plan file (CPVC or image)
    if (floorPlanFile) {
      setIsConfigured(true);
    }
  };

  const resetConfiguration = () => {
    setIsConfigured(false);
    setStep(1);
    setFloorCount("");
    setFloorPlanFile(null);
    setSuspendedWorkFile(null);
    setFloorPlanPreview(null);
    setExtractedDiagrams([]);
    setExtractedValues([]);
    setSuspendedDiagrams([]);
    setSuspendedValues([]);
    setSamples(MOCK_SAMPLES);
    setSearchQuery("");
    setFilterType("all");
  };

  // Filter and search samples
  const filteredSamples = samples.filter(item => {
    const matchesSearch = !searchQuery || 
      item.item.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.unit.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = filterType === "all" || 
      (filterType === "cpvc" && (!item.workType || item.workType !== "Suspended")) ||
      (filterType === "suspended" && item.workType === "Suspended");
    
    return matchesSearch && matchesFilter;
  });

  // Update sample quantity
  const updateSampleQty = (id, newQty) => {
    setSamples(samples.map(item => 
      item.id === id 
        ? { ...item, perFloorQty: parseFloat(newQty) || 0 }
        : item
    ));
  };

  // Add new sample
  const addNewSample = () => {
    const newId = Math.max(...samples.map(s => s.id), 0) + 1;
    const newSample = {
      id: newId,
      item: "New Item",
      unit: "Nos",
      perFloorQty: 0,
      totalFloors: parseInt(floorCount) || 1,
      totalQty: 0,
      status: "Draft",
      workType: "CPVC",
    };
    setSamples([...samples, newSample]);
    toast({
      title: "Item Added",
      description: "New item added to the list",
    });
  };

  // Delete sample
  const deleteSample = (id) => {
    setSamples(samples.filter(item => item.id !== id));
    toast({
      title: "Item Deleted",
      description: "Item removed from the list",
    });
  };

  // Calculate summary statistics
  const summaryStats = {
    totalItems: samples.length,
    cpvcItems: samples.filter(s => !s.workType || s.workType !== "Suspended").length,
    suspendedItems: samples.filter(s => s.workType === "Suspended").length,
    totalQuantity: samples.reduce((sum, item) => {
      const totalFloors = parseInt(floorCount) || item.totalFloors;
      return sum + (item.perFloorQty * totalFloors);
    }, 0),
    lockedItems: samples.filter(s => s.status === "Locked").length,
    draftItems: samples.filter(s => s.status === "Draft").length,
  };

  const availableUploadedFiles = useMemo(() => (
    Array.from(
      new Set(
        [...uploadFilePaths, ...serverSamples.map((s) => s.sample_file)]
          .filter(Boolean)
      )
    )
  ), [uploadFilePaths, serverSamples]);

  // Export to Excel
  const handleExportToExcel = () => {
    try {
      const data = filteredSamples.map(item => ({
        'Item Name': item.item,
        'Work Type': item.workType || 'CPVC',
        'Unit': item.unit,
        'Qty Per Floor': item.perFloorQty,
        'Total Floors': parseInt(floorCount) || item.totalFloors,
        'Total Quantity': (item.perFloorQty * (parseInt(floorCount) || item.totalFloors)),
        'Status': item.status,
        'Dimensions': item.dimensions || '',
        'Specifications': item.specifications || '',
      }));

      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Samples');
      XLSX.writeFile(wb, `Sample_Configuration_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      toast({
        title: "Export Successful",
        description: "Sample data exported to Excel",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (!isConfigured) {
    return (
      <div className="max-w-3xl mx-auto space-y-8 py-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Sample Management Setup</h1>
          <p className="text-muted-foreground">Configure floor plans, CPVC, and suspended work for your project.</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className={`flex flex-col items-center p-4 border rounded-lg ${step >= 1 ? 'border-primary bg-primary/5' : 'border-muted'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>1</div>
            <span className="text-sm font-medium">Floor Plan & Details</span>
          </div>
          <div className={`flex flex-col items-center p-4 border rounded-lg ${step >= 2 ? 'border-primary bg-primary/5' : 'border-muted'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>2</div>
            <span className="text-sm font-medium">Suspended Work</span>
          </div>
        </div>

        <Card>
          {step === 1 && (
            <>
              <CardHeader>
                <CardTitle>Step 1: Project Details</CardTitle>
                <CardDescription>Enter the number of floors and upload the floor plan.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="floor-count">Number of Floors</Label>
                  <Input 
                    id="floor-count" 
                    type="number" 
                    placeholder="Enter total floors (e.g., 117)" 
                    value={floorCount}
                    onChange={(e) => setFloorCount(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="floor-plan">Floor Plan (Image or PDF)</Label>
                  <div className="border-2 border-dashed rounded-lg p-6 hover:bg-muted/50 transition-colors text-center cursor-pointer relative">
                    <Input 
                      id="floor-plan" 
                      type="file" 
                      accept="image/*,application/pdf" 
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={handleFloorPlanUpload}
                    />
                    <div className="flex flex-col items-center gap-2">
                      {processingPdf ? (
                        <>
                          <Loader2 className="h-8 w-8 text-primary animate-spin" />
                          <span className="font-medium">Processing PDF...</span>
                          <span className="text-xs text-muted-foreground">
                            {extractionProgress.message || 'Extracting diagrams and values'}
                          </span>
                          {extractionProgress.total > 0 && (
                            <div className="w-full max-w-xs mt-2">
                              <div className="h-2 bg-muted rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-primary transition-all duration-300"
                                  style={{ width: `${(extractionProgress.current / extractionProgress.total) * 100}%` }}
                                />
                              </div>
                              <span className="text-xs text-muted-foreground mt-1 block text-center">
                                {extractionProgress.current} / {extractionProgress.total}
                              </span>
                            </div>
                          )}
                        </>
                      ) : floorPlanFile ? (
                        <>
                          {floorPlanFile.type.startsWith('image/') ? <ImageIcon className="h-8 w-8 text-primary" /> : <FileText className="h-8 w-8 text-primary" />}
                          <span className="font-medium">{floorPlanFile.name}</span>
                          <span className="text-xs text-muted-foreground">{(floorPlanFile.size / 1024 / 1024).toFixed(2)} MB</span>
                          {extractedDiagrams.length > 0 && (
                            <span className="text-xs text-green-600 mt-1">
                              {extractedDiagrams.length} diagram(s) extracted
                            </span>
                          )}
                        </>
                      ) : (
                        <>
                          <Upload className="h-8 w-8 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Drag and drop or click to upload</span>
                        </>
                      )}
                    </div>
                  </div>
                  {floorPlanPreview && !processingPdf && (
                    <div className="mt-4 border rounded-lg overflow-hidden h-48 w-full bg-muted/20 flex items-center justify-center">
                      <img 
                        src={floorPlanPreview} 
                        alt="PDF Preview" 
                        className="max-w-full max-h-full w-auto h-auto object-contain"
                        onError={(e) => {
                          console.error('Preview image failed to load:', e);
                          setFloorPlanPreview(null);
                        }}
                      />
                    </div>
                  )}
                  {processingPdf && (
                    <div className="mt-4 border rounded-lg p-4 bg-muted/20 flex items-center justify-center h-48">
                      <div className="text-center">
                        <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">{extractionProgress.message || 'Processing...'}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={handleNext} disabled={!floorCount || !floorPlanFile || processingPdf}>
                  Next Step <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </>
          )}

          {step === 2 && (
            <>
              <CardHeader>
                <CardTitle>Step 2: Suspended Work</CardTitle>
                <CardDescription>Upload the suspended work PDF (e.g., 1-4 FLR.pdf).</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="suspended-work">Suspended Work PDF</Label>
                  <div className="border-2 border-dashed rounded-lg p-6 hover:bg-muted/50 transition-colors text-center cursor-pointer relative">
                    <Input 
                      id="suspended-work" 
                      type="file" 
                      accept="application/pdf" 
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={handleSuspendedWorkUpload}
                    />
                    <div className="flex flex-col items-center gap-2">
                      {processingSuspendedPdf ? (
                        <>
                          <Loader2 className="h-8 w-8 text-primary animate-spin" />
                          <span className="font-medium">Processing Suspended Work PDF...</span>
                          <span className="text-xs text-muted-foreground">
                            {suspendedExtractionProgress.message || 'Extracting diagrams and values'}
                          </span>
                          {suspendedExtractionProgress.total > 0 && (
                            <div className="w-full max-w-xs mt-2">
                              <div className="h-2 bg-muted rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-primary transition-all duration-300"
                                  style={{ width: `${(suspendedExtractionProgress.current / suspendedExtractionProgress.total) * 100}%` }}
                                />
                              </div>
                              <span className="text-xs text-muted-foreground mt-1 block text-center">
                                {suspendedExtractionProgress.current} / {suspendedExtractionProgress.total}
                              </span>
                            </div>
                          )}
                        </>
                      ) : suspendedWorkFile ? (
                        <>
                          <FileText className="h-8 w-8 text-primary" />
                          <span className="font-medium">{suspendedWorkFile.name}</span>
                          <span className="text-xs text-muted-foreground">{(suspendedWorkFile.size / 1024 / 1024).toFixed(2)} MB</span>
                          {suspendedDiagrams.length > 0 && (
                            <span className="text-xs text-green-600 mt-1">
                              {suspendedDiagrams.length} diagram(s) extracted
                            </span>
                          )}
                          {suspendedValues.length > 0 && (
                            <span className="text-xs text-green-600">
                              {suspendedValues.length} item(s) extracted
                            </span>
                          )}
                        </>
                      ) : (
                        <>
                          <Upload className="h-8 w-8 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">Drag and drop or click to upload PDF</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={handleBack}>
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back
                </Button>
                <Button onClick={handleCheckFloorPlan} disabled={processingSuspendedPdf}>
                  Check Floor Plan <CheckCircle className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </>
          )}
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Samples</h1>
          <p className="text-muted-foreground mt-2">Manage project samples from the list below.</p>
        </div>
        <div className="flex w-full sm:w-auto">
          {isCreateRoute ? (
            <Button variant="outline" onClick={() => navigate(`/${projectId}/samples`)} className="w-full sm:w-auto">
              <ChevronLeft className="mr-2 h-4 w-4" /> Back to List
            </Button>
          ) : (
            <Button onClick={() => navigate(`/${projectId}/samples/create`)} className="w-full sm:w-auto">
              <Plus className="mr-2 h-4 w-4" /> Create Sample
            </Button>
          )}
        </div>
      </div>

      {showCreateForm && (
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle>Create Sample</CardTitle>
              <CardDescription>Fill the sample details and save them to the system.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="space-y-2">
              <Label>Project ID</Label>
              <Input value={selectedProject ? (selectedProject.project_id || selectedProject.id) : ""} readOnly placeholder="Select a project" />
            </div>
            <div className="space-y-2">
              <Label>Building Name</Label>
              <Input value={createForm.building_name} onChange={(e) => setCreateForm({ ...createForm, building_name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Site Name</Label>
              <Input value={createForm.site_name} onChange={(e) => setCreateForm({ ...createForm, site_name: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="space-y-2">
              <Label>Floors</Label>
              <Input value={createForm.location.floor} onChange={(e) => setCreateForm({ ...createForm, location: { ...createForm.location, floor: e.target.value } })} />
            </div>
            <div className="space-y-2">
              <Label>Block</Label>
              <Input value={createForm.location.block} onChange={(e) => setCreateForm({ ...createForm, location: { ...createForm.location, block: e.target.value } })} />
            </div>
            <div className="space-y-2">
              <Label>Wing</Label>
              <Input value={createForm.location.wing} onChange={(e) => setCreateForm({ ...createForm, location: { ...createForm.location, wing: e.target.value } })} />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">Other documents/diagrams</div>
            </div>
            <div
              className={`border rounded-md p-3 transition-colors ${isAttachmentDragActive ? 'border-primary bg-primary/5' : 'border-dashed'}`}
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsAttachmentDragActive(true);
              }}
              onDragEnter={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsAttachmentDragActive(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsAttachmentDragActive(false);
              }}
              onDrop={handleAttachmentDrop}
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="text-xs text-muted-foreground">
                  Drag and drop files here, or select multiple files
                </div>
                <Label
                  htmlFor="sample-attachments-upload"
                  className="inline-flex h-8 items-center justify-center rounded-md border px-3 text-xs font-medium cursor-pointer hover:bg-muted"
                >
                  Select Files
                </Label>
              </div>
              <Input
                id="sample-attachments-upload"
                type="file"
                multiple
                onChange={handleSampleUpload}
                className="hidden"
              />
              {uploadFilePaths.length > 0 ? (
                <div className="mt-3 space-y-2">
                  <Label className="text-xs">Uploaded files</Label>
                  <Select
                    value={createForm.sample_file || ""}
                    onValueChange={(value) => setCreateForm({ ...createForm, sample_file: value })}
                  >
                    <SelectTrigger className="h-8">
                      <SelectValue placeholder="Select uploaded file" />
                    </SelectTrigger>
                    <SelectContent>
                      {uploadFilePaths.map((path) => (
                        <SelectItem key={path} value={path}>
                          {path.split('/').pop() || path}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : null}
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl border bg-gradient-to-r from-primary/10 via-background to-secondary/20 px-5 py-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between shadow-sm">
              <div className="space-y-1">
                <div className="text-sm font-semibold tracking-wide">Item Description</div>
                <div className="text-xs text-muted-foreground">
                  Curated BOQ rows selected for this sample.
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="secondary" className="h-8 px-3 rounded-full border bg-background/80 backdrop-blur-sm">
                  {createForm.item_description.length} row(s)
                </Badge>
                <Button
                  size="sm"
                  variant="default"
                  className="rounded-full px-4 shadow-sm"
                  type="button"
                  onClick={async () => {
                    if (!getSelectedProjectId()) {
                      toast({ title: "Select project", description: "Choose a project first.", variant: "destructive" });
                      return;
                    }
                    setBoqPickerOpen(true);
                    setLoadingProjectBoqItems(true);
                    try {
                      await refreshProjectBoqItems();
                    } finally {
                      setLoadingProjectBoqItems(false);
                    }
                  }}
                >
                  <Layers className="mr-2 h-4 w-4" />
                  View Items in BOQ
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full px-4"
                  type="button"
                  onClick={addManualSampleItemRow}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Item
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full px-4"
                  type="button"
                  onClick={() => {
                    setCreateForm({ ...createForm, item_description: [] });
                    setInventoryQtyStatus({});
                  }}
                  disabled={createForm.item_description.length === 0}
                >
                  Clear Table
                </Button>
              </div>
            </div>
            <div className="rounded-2xl border bg-card shadow-sm overflow-hidden">
              {createForm.item_description.length === 0 ? (
                <div className="p-10 text-sm text-muted-foreground text-center bg-gradient-to-b from-muted/20 to-background">
                  No items added yet. Use <span className="font-medium">View Items in BOQ</span> and click <span className="font-medium">Add</span>.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/40">
                      {inventoryTableKeys.map((key) => (
                        <TableHead key={key} className="whitespace-nowrap capitalize text-xs font-semibold tracking-wide text-muted-foreground">
                          {key.replace(/_/g, " ")}
                        </TableHead>
                      ))}
                      <TableHead className="w-[90px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {createForm.item_description.map((row, idx) => (
                      <TableRow key={`${idx}-${row?.sr_no || "row"}`}>
                        {inventoryTableKeys.map((key) => {
                          const isManual = String(row?._row_type || "").toLowerCase() === "manual" && !(row.add_fields || []).length;
                          const field = (row.add_fields || []).find((f) => (f?.key || "").trim() === key);
                          const rawValue = (() => {
                            if (key === "description") return row?.description ?? field?.value ?? "-";
                            if (key === "qty") return row?.quantity ?? field?.value ?? "-";
                            if (key === "amount") return row?.value ?? field?.value ?? "-";
                            return field?.value ?? "-";
                          })();
                          const rawText = String(rawValue ?? "").trim();
                          const displayValue = (() => {
                            if (key === "description") return truncateWords(rawText, 14);
                            if (key === "amount") return formatMaybeCurrency(rawText);
                            return rawText || "-";
                          })();
                          return (
                            <TableCell key={`${idx}-${key}`} className="text-sm font-medium">
                              {key === "description" && isManual ? (
                                <div className="space-y-2">
                                  <Input
                                    className="h-9 text-sm"
                                    placeholder="Description"
                                    value={row?.description || ""}
                                    onChange={(e) => updateManualSampleItemRow(idx, { description: e.target.value })}
                                  />
                                  <InventoryPicker
                                    project_id={projectIdForInventory}
                                    initialValue={row?.description || ""}
                                    selectedId={row?.inventory_id}
                                    minQty={Number(row?.quantity) || 0}
                                    onValidityChange={(status) => {
                                      setInventoryQtyStatus((prev) => ({ ...(prev || {}), [idx]: status }));
                                    }}
                                    onSelect={(picked) => {
                                      const qty = Number(row?.quantity);
                                      updateManualSampleItemRow(idx, {
                                        inventory_id: picked.inventory_id,
                                        issued_qty: row?.issued_qty ?? (Number.isFinite(qty) ? qty : null),
                                      });
                                    }}
                                    onClear={() => updateManualSampleItemRow(idx, { inventory_id: null, issued_qty: null })}
                                  />
                                </div>
                              ) : key === "qty" && isManual ? (
                                <Input
                                  className="h-9 text-sm"
                                  placeholder="Qty"
                                  value={row?.quantity || ""}
                                  onChange={(e) => updateManualSampleItemRow(idx, { quantity: e.target.value })}
                                />
                              ) : key === "amount" && isManual ? (
                                <Input
                                  className="h-9 text-sm"
                                  placeholder="Value"
                                  value={row?.value || ""}
                                  onChange={(e) => updateManualSampleItemRow(idx, { value: e.target.value })}
                                />
                              ) : key === "description" ? (
                                <span className="block max-w-[520px] truncate" title={rawText}>
                                  {displayValue}
                                </span>
                              ) : (
                                displayValue
                              )}
                            </TableCell>
                          );
                        })}
                        <TableCell>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="rounded-full text-muted-foreground hover:text-foreground hover:bg-destructive/10"
                            onClick={() => {
                              removeSampleItemRowAt(idx);
                            }}
                          >
                            Remove
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>
          {/* Additional Fields section hidden as requested */}
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={saveCreate} disabled={savingSample}>
            {savingSample ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            {savingSample ? "Saving..." : "Save"}
          </Button>
        </CardFooter>
      </Card>
      )}

      {!isCreateRoute ? (
      <Card className="border-0 shadow-sm ring-1 ring-border/50 overflow-hidden">
        <CardHeader className="border-b bg-muted/20">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle>Sample List</CardTitle>
              <CardDescription>Loaded records {selectedProject ? `(Project ${selectedProject.project_id || selectedProject.id})` : ''}</CardDescription>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Select value={selectedUploadedFile} onValueChange={setSelectedUploadedFile}>
                <SelectTrigger className="w-full sm:w-[280px]">
                  <SelectValue placeholder="Select uploaded file" />
                </SelectTrigger>
                <SelectContent>
                  {availableUploadedFiles.map((p) => (
                    <SelectItem key={p} value={p}>
                      {p.split('/').pop() || p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                disabled={!selectedUploadedFile}
                onClick={() => {
                  if (selectedUploadedFile) {
                    window.open(api.getApiFileUrl(selectedUploadedFile), "_blank", "noopener,noreferrer");
                  }
                }}
              >
                Preview
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loadingServer ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : serverSamples.length === 0 ? (
            <div className="text-muted-foreground py-6">No samples found</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead>ID</TableHead>
                  <TableHead>Building</TableHead>
                  <TableHead>Site</TableHead>
                  <TableHead className="w-[160px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {serverSamples.map((s) => (
                  <TableRow key={s.sample_id || s.id}>
                    <TableCell>{s.sample_id || s.id}</TableCell>
                    <TableCell>{s.building_name || '-'}</TableCell>
	                    <TableCell>{s.site_name || '-'}</TableCell>
	                    <TableCell>
	                      <div className="flex justify-end">
	                        <RowActionsMenu
	                          items={[
	                            {
	                              key: "link",
	                              label: linkingSampleId === (s.sample_id || s.id) ? "Linking..." : "Link to Inventory",
	                              icon: Link2,
	                              disabled: (() => {
	                                const sid = s.sample_id || s.id;
	                                const linked = sid ? linkedSampleIds.has(String(sid)) : false;
	                                const hasLinks = sampleHasInventoryLinks(s);
	                                return linked || hasLinks || linkingSampleId === (s.sample_id || s.id);
	                              })(),
	                              onSelect: () => handleLinkSampleInventory(s),
	                            },
	                            {
	                              key: "attach",
	                              label: "Attach other documents/diagrams",
	                              icon: Paperclip,
	                              disabled: !selectedUploadedFile,
	                              onSelect: () => {
	                                if (!selectedUploadedFile) return;
	                                attachFileToSample(s, selectedUploadedFile);
	                              },
	                            },
	                            { type: "separator" },
	                            { key: "preview", label: "Preview", icon: Eye, onSelect: () => openPreview(s) },
	                            { type: "separator" },
	                            { key: "delete", label: "Delete", icon: Trash2, destructive: true, onSelect: () => removeSample(s) },
	                          ]}
	                        />
	                      </div>
	                    </TableCell>
	                  </TableRow>
	                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      ) : null}

      <Dialog open={itemFieldDialogOpen} onOpenChange={(open) => {
        if (open) {
          setItemFieldDialogOpen(true);
        } else {
          closeItemFieldDialog();
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Item Field</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Key</Label>
              <Input value={itemFieldKey} onChange={(e) => setItemFieldKey(e.target.value)} placeholder="Enter key" />
            </div>
            <div className="space-y-2">
              <Label>Value</Label>
              <Input value={itemFieldValue} onChange={(e) => setItemFieldValue(e.target.value)} placeholder="Enter value" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeItemFieldDialog}>Cancel</Button>
            <Button onClick={addItemFieldToRow}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={boqPickerOpen}
        onOpenChange={(open) => {
          setBoqPickerOpen(open);
          if (!open) setBoqSearch("");
        }}
      >
        <DialogContent className="w-[98vw] max-w-[98vw] sm:!w-[98vw] sm:!max-w-[98vw] h-[94vh] sm:!max-h-[94vh] p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-6 pb-4 border-b bg-gradient-to-r from-primary/10 via-background to-secondary/20">
            <DialogTitle className="text-xl tracking-tight flex items-center gap-2">
              BOQ Items
              {activeBoqClient ? (
                <Badge variant="secondary" className="rounded-full">
                  {activeBoqClient === "lodha" ? "Lodha" : activeBoqClient === "hiranandani" ? "Hiranandani" : activeBoqClient}
                </Badge>
              ) : null}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 p-6 h-[calc(94vh-86px)] overflow-auto">
            <div className="rounded-2xl border bg-card shadow-sm p-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="relative w-full md:max-w-md">
                <Search className="h-4 w-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
                <Input
                  className="pl-9 rounded-full bg-muted/30"
                  placeholder="Search by item no, section, unit, or description"
                  value={boqSearch}
                  onChange={(e) => setBoqSearch(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="rounded-full px-3 h-8">{filteredProjectBoqItems.length} item(s)</Badge>
              <Button
                type="button"
                variant="outline"
                className="rounded-full px-4"
                onClick={async () => {
                  setLoadingProjectBoqItems(true);
                  try {
                    await refreshProjectBoqItems();
                  } finally {
                    setLoadingProjectBoqItems(false);
                  }
                }}
                disabled={loadingProjectBoqItems}
              >
                {loadingProjectBoqItems ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Refresh
              </Button>
              </div>
            </div>

            <div className="rounded-2xl border bg-card shadow-sm overflow-hidden">
            <div className={activeBoqClient ? "overflow-x-auto" : ""}>
            <div className={activeBoqClient ? "min-w-[1200px]" : ""}>
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead className="text-xs tracking-wide">Description</TableHead>
                  <TableHead className="w-[240px] text-xs tracking-wide">Section</TableHead>
                  <TableHead className="w-[120px] text-xs tracking-wide">Item No</TableHead>
                  {activeBoqClient === "lodha" ? (
                    <TableHead className="w-[120px] text-xs tracking-wide">HSN</TableHead>
                  ) : activeBoqClient === "hiranandani" ? (
                    <TableHead className="w-[120px] text-xs tracking-wide">SAC Code</TableHead>
                  ) : (
                    <TableHead className="w-[140px] text-xs tracking-wide">Item Code</TableHead>
                  )}
                  <TableHead className="w-[90px] text-xs tracking-wide">{activeBoqClient === "hiranandani" ? "UOM" : "Unit"}</TableHead>
                  <TableHead className="w-[110px] text-xs tracking-wide">{activeBoqClient === "hiranandani" ? "Order Qty" : "Qty"}</TableHead>
                  {activeBoqClient ? <TableHead className="w-[120px] text-xs tracking-wide text-right">{activeBoqClient === "hiranandani" ? "Unit Price" : "Rate"}</TableHead> : null}
                  {activeBoqClient ? <TableHead className="w-[120px] text-xs tracking-wide text-right">{activeBoqClient === "hiranandani" ? "Value" : "Amount"}</TableHead> : null}
                  <TableHead className="w-[240px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingProjectBoqItems ? (
                  <TableRow>
                    <TableCell colSpan={activeBoqClient ? 9 : 7} className="text-center text-sm text-muted-foreground py-8">
                      <Loader2 className="h-4 w-4 animate-spin inline mr-2" />
                      Loading BOQ items...
                    </TableCell>
                  </TableRow>
                ) : filteredProjectBoqItems.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={activeBoqClient ? 9 : 7} className="text-center text-sm text-muted-foreground py-8">
                      No BOQ items found for this project.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredProjectBoqItems.map((item) => {
                    const key = boqItemKey(item);
                    const derived = deriveBoqFields(item);
                    const availableQty = getBoqRemainingQty(item);
                    const reserveKey = (() => {
                      const normalize = (v) => String(v || "").trim().toLowerCase();
                      const normalizeEmptyLike = (v) => {
                        const t = String(v ?? "").trim();
                        if (!t) return "";
                        const n = t.toLowerCase();
                        if (n === "-" || n === "_" || n === "na" || n === "n/a" || n === "null" || n === "undefined") return "";
                        return t;
                      };
                      const boqId = normalize(normalizeEmptyLike(derived?.id));
                      const itemNo = normalize(normalizeEmptyLike(derived?.item_no));
                      const itemCode = normalize(normalizeEmptyLike(derived?.item_code));
                      const description = normalize(normalizeEmptyLike(derived?.description));
                      const section = normalize(normalizeEmptyLike(derived?.section));
                      return boqId || itemNo || itemCode || (description ? `${description}__${section}` : "");
                    })();
                    const addedQty = reserveKey ? (boqReservedQtyByKey.get(reserveKey) || 0) : 0;
                    return (
                    <TableRow key={key}>
                    <TableCell className="font-medium">
                      <button
                        type="button"
                        className="max-w-[520px] truncate text-left hover:underline"
                        title={String(derived.description || "")}
                        onClick={() =>
                          setBoqDescriptionPreview({
                            item_no: derived.item_no,
                            item_code: derived.item_code,
                            section: derived.section,
                            description: derived.description,
                            unit: derived.unit,
                            qty: derived.qty,
                            rate: derived.rate,
                            amount: derived.amount,
                            hsn: derived.hsn,
                            sac_code: derived.sac_code,
                          })
                        }
                        >
                          {truncateWords(derived.description, 10)}
                        </button>
                      </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{derived.section || "-"}</TableCell>
                    <TableCell className="font-medium">{derived.item_no || derived.item_code || "-"}</TableCell>
                      {activeBoqClient === "lodha" ? (
                        <TableCell className="font-mono text-xs">{derived.hsn || "-"}</TableCell>
                      ) : activeBoqClient === "hiranandani" ? (
                        <TableCell className="font-mono text-xs">{derived.sac_code || "-"}</TableCell>
                      ) : (
                        <TableCell className="font-medium">{derived.item_code || "-"}</TableCell>
                      )}
                      <TableCell className="font-medium">{derived.unit || "-"}</TableCell>
                      <TableCell className="font-medium">
                        {Number.isFinite(availableQty) ? String(availableQty) : "0"}
                      </TableCell>
                      {activeBoqClient ? (
                        <TableCell className="font-medium text-right">{formatMaybeCurrency(derived.rate)}</TableCell>
                      ) : null}
                      {activeBoqClient ? (
                        <TableCell className="font-medium text-right">{formatMaybeCurrency(derived.amount)}</TableCell>
                      ) : null}
                      <TableCell className="w-[240px] text-right">
                        {Object.prototype.hasOwnProperty.call(pendingBoqQty, key) ? (
                          <div className="flex items-center justify-end gap-2 flex-nowrap">
                            <div className="h-9 rounded-full border bg-muted/20 p-1 flex items-center gap-1 shadow-inner">
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 rounded-full"
                                onClick={() => adjustPendingBoqQty(item, -1)}
                                disabled={addingBoqKey === key}
                              >
                                <Minus className="h-3.5 w-3.5" />
                              </Button>
                              <Input
                                type="text"
                                inputMode="numeric"
                                value={pendingBoqQty[key]}
                                onChange={(e) => setPendingBoqQtyValue(item, e.target.value)}
                                onBlur={() => normalizePendingBoqQty(item)}
                                className="h-7 w-14 rounded-full border-0 bg-background text-center text-sm font-semibold px-1 focus-visible:ring-1 focus-visible:ring-primary"
                                disabled={addingBoqKey === key}
                              />
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 rounded-full"
                                onClick={() => adjustPendingBoqQty(item, 1)}
                                disabled={addingBoqKey === key}
                              >
                                <Plus className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                            <Button
                              type="button"
                              size="sm"
                              className="rounded-full px-4 bg-primary text-primary-foreground"
                              onClick={() => confirmAddBoqWithQuantity(item)}
                              disabled={availableQty <= 0 || addingBoqKey === key || !Number(pendingBoqQty[key])}
                            >
                              {addingBoqKey === key ? <Loader2 className="h-4 w-4 animate-spin" /> : "Apply"}
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              className="rounded-full px-3"
                              onClick={() => closeBoqQtySelector(key)}
                              disabled={addingBoqKey === key}
                            >
                              Cancel
                            </Button>
                            {addedQty > 0 ? (
                              <Badge variant="secondary" className="rounded-full px-3 h-8 whitespace-nowrap shrink-0">
                                {addedQty} added
                              </Badge>
                            ) : null}
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-2 flex-nowrap">
                            {addedQty > 0 ? (
                              <Badge variant="secondary" className="rounded-full px-3 h-8 whitespace-nowrap shrink-0">
                                {addedQty} added
                              </Badge>
                            ) : null}
                            <Button
                              type="button"
                              size="sm"
                              className="rounded-full px-4 shrink-0"
                              onClick={() => openBoqQtySelector(item)}
                              disabled={availableQty <= 0 || addingBoqKey === key}
                            >
                              {addingBoqKey === key ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <>
                                  <Plus className="mr-1 h-3.5 w-3.5" />
                                  Add
                                </>
                              )}
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
            </div>
            </div>
            </div>
          </div>
          <DialogFooter className="px-6 py-4 border-t bg-muted/20">
            <Button type="button" variant="outline" className="rounded-full px-5" onClick={() => setBoqPickerOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={!!boqDescriptionPreview} onOpenChange={(open) => !open && setBoqDescriptionPreview(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>BOQ Item Description</DialogTitle>
          </DialogHeader>
          {boqDescriptionPreview ? (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground">Item Code</div>
                  <div className="font-medium">{boqDescriptionPreview.item_code || "-"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Item No</div>
                  <div className="font-medium">{boqDescriptionPreview.item_no || "-"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Section</div>
                  <div className="font-medium">{boqDescriptionPreview.section || "-"}</div>
                </div>
                {activeBoqClient === "lodha" ? (
                  <div>
                    <div className="text-xs text-muted-foreground">HSN</div>
                    <div className="font-medium font-mono">{boqDescriptionPreview.hsn || "-"}</div>
                  </div>
                ) : activeBoqClient === "hiranandani" ? (
                  <div>
                    <div className="text-xs text-muted-foreground">SAC Code</div>
                    <div className="font-medium font-mono">{boqDescriptionPreview.sac_code || "-"}</div>
                  </div>
                ) : null}
                <div>
                  <div className="text-xs text-muted-foreground">Unit</div>
                  <div className="font-medium">{boqDescriptionPreview.unit || "-"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">{activeBoqClient === "hiranandani" ? "Order Qty" : "Qty"}</div>
                  <div className="font-medium">{boqDescriptionPreview.qty || "-"}</div>
                </div>
                {activeBoqClient ? (
                  <div>
                    <div className="text-xs text-muted-foreground">{activeBoqClient === "hiranandani" ? "Unit Price" : "Rate"}</div>
                    <div className="font-medium">{formatMaybeCurrency(boqDescriptionPreview.rate)}</div>
                  </div>
                ) : null}
                {activeBoqClient ? (
                  <div>
                    <div className="text-xs text-muted-foreground">{activeBoqClient === "hiranandani" ? "Value" : "Amount"}</div>
                    <div className="font-medium">{formatMaybeCurrency(boqDescriptionPreview.amount)}</div>
                  </div>
                ) : null}
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Description</div>
                <div className="whitespace-pre-wrap text-sm font-medium">{boqDescriptionPreview.description || "-"}</div>
              </div>
            </div>
          ) : null}
          <DialogFooter>
            <Button variant="outline" onClick={() => setBoqDescriptionPreview(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
