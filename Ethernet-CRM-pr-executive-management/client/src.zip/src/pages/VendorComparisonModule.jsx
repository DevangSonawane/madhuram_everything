import React, { useEffect, useMemo, useRef, useState } from "react";
import { Loader2, Search, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useResolvedProject } from "@/hooks/useResolvedProject";

const ACCEPTED_UPLOAD_TYPES = ".pdf,.csv,.xlsx,.xls";

const normalizeArray = (value) => {
  if (Array.isArray(value)) return value;
  return [];
};

const parseArrayLike = (value, fallback = []) => {
  if (Array.isArray(value)) return value;
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : fallback;
    } catch {
      return fallback;
    }
  }
  if (value && typeof value === "object") {
    if (Array.isArray(value.data)) return value.data;
    if (Array.isArray(value.rows)) return value.rows;
    if (Array.isArray(value.results)) return value.results;
  }
  return fallback;
};

const normalizeText = (value) =>
  String(value ?? "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();

const toNumberOrNull = (value) => {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const cleaned = String(value).replace(/,/g, "").trim();
  if (!cleaned) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
};

const formatMoney = (value) => {
  const n = toNumberOrNull(value);
  if (n === null) return "-";
  return n.toLocaleString("en-IN", { maximumFractionDigits: 2 });
};

const todayISO = () => new Date().toISOString().slice(0, 10);

const isLikelySummaryRow = (description, srNoCell) => {
  const d = normalizeText(description);
  if (!d) return false;
  if (srNoCell !== null && srNoCell !== undefined && String(srNoCell).trim() !== "") return false;
  return (
    d.includes("subtotal") ||
    d.includes("discount") ||
    d.includes("gst") ||
    d.includes("total") ||
    d.includes("delivery") ||
    d.includes("payment") ||
    d.includes("transport")
  );
};

const buildMergeLookup = (merges = []) => {
  const map = new Map();
  merges.forEach((m) => {
    const sr = m?.s?.r ?? null;
    const sc = m?.s?.c ?? null;
    const er = m?.e?.r ?? null;
    const ec = m?.e?.c ?? null;
    if (sr == null || sc == null || er == null || ec == null) return;
    for (let r = sr; r <= er; r += 1) {
      for (let c = sc; c <= ec; c += 1) {
        map.set(`${r}:${c}`, { r: sr, c: sc });
      }
    }
  });
  return map;
};

const sheetCellValue = (ws, mergeLookup, r, c) => {
  const key = `${r}:${c}`;
  const topLeft = mergeLookup.get(key);
  const target = topLeft ?? { r, c };
  const ref = XLSX.utils.encode_cell({ r: target.r, c: target.c });
  const cell = ws?.[ref];
  return cell?.v ?? "";
};

const parseVendorComparisonExcel = async (file) => {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array", cellDates: true });
  const sheetName = wb.SheetNames?.[0];
  if (!sheetName) throw new Error("No sheet found in workbook.");
  const ws = wb.Sheets[sheetName];
  const range = XLSX.utils.decode_range(ws["!ref"] || "A1:A1");
  const merges = ws["!merges"] || [];
  const mergeLookup = buildMergeLookup(merges);

  const get = (r, c) => sheetCellValue(ws, mergeLookup, r, c);
  const maxCol = range.e.c;
  const maxRow = range.e.r;

  const headerBlock = {
    company: get(0, 0),
    project: get(1, 0),
    indentNo: get(2, 0),
    indentDate: get(3, 0),
    comparisonDate: get(4, 0),
  };

  const vendors = [];
  for (let c = 5; c <= maxCol; c += 2) {
    const rawName = get(5, c);
    const name = String(rawName ?? "").trim();
    if (!name) {
      const nextMaybe = String(get(5, c + 2) ?? "").trim();
      if (!nextMaybe) break;
      continue;
    }
    vendors.push(name);
  }

  const rows = [];

  const isNumberedItem = (value) => {
    const n = toNumberOrNull(value);
    if (n === null) return null;
    if (!Number.isInteger(n)) return null;
    if (n <= 0) return null;
    return n;
  };

  for (let r = 7; r <= maxRow; r += 1) {
    const srCell = get(r, 0);
    const hsn = get(r, 1);
    const desc = get(r, 2);
    const qty = get(r, 3);
    const uom = get(r, 4);

    const descText = String(desc ?? "").trim();
    const srNo = isNumberedItem(srCell);

    if (!srNo) {
      // Delivery/Payment/Transportation rows are intentionally ignored.
      if (isLikelySummaryRow(descText, srCell)) continue;
      continue;
    }

    if (!descText || isLikelySummaryRow(descText, srCell)) continue;

    const vendorPrices = vendors.map((vendorName, idx) => {
      const rateCol = 5 + idx * 2;
      const amountCol = rateCol + 1;
      return {
        vendorName,
        rate: toNumberOrNull(get(r, rateCol)),
        amount: toNumberOrNull(get(r, amountCol)),
      };
    });

    rows.push({
      sr_no: srNo,
      hsn_code: String(hsn ?? "").trim(),
      item_description: descText,
      qty: toNumberOrNull(qty) ?? qty,
      unit: String(uom ?? "").trim(),
      vendorPrices,
    });
  }

  return { vendors, rows, headerBlock };
};

const mergeWithPrItems = (excelRows, vendors, prItems) => {
  const prIndex = new Map();
  normalizeArray(prItems).forEach((item) => {
    const key = normalizeText(item?.material_description);
    if (!key) return;
    if (!prIndex.has(key)) prIndex.set(key, item);
  });

  const comparisonRows = excelRows.map((row) => {
    const normalized = normalizeText(row?.item_description);
    const prMatch = prIndex.get(normalized) || null;
    const canonical = prMatch?.material_description || row.item_description;
    const unit = String(prMatch?.unit ?? row?.unit ?? "").trim();

    return {
      sr_no: row.sr_no,
      hsn_code: row.hsn_code,
      material_description: canonical,
      qty: row.qty,
      unit,
      vendorPrices: vendors.map((vendorName) => {
        const found = row.vendorPrices.find((p) => p.vendorName === vendorName) || { vendorName, rate: null, amount: null };
        return { vendorName, rate: found.rate, amount: found.amount };
      }),
    };
  });

  return comparisonRows;
};

const calculateTotals = (comparisonRows, vendors, { discountRate = 0, gstRate = 0.18 } = {}) => {
  const subtotals = vendors.map(() => 0);

  comparisonRows.forEach((row) => {
    row.vendorPrices.forEach((p, idx) => {
      const amount = toNumberOrNull(p.amount);
      const rate = toNumberOrNull(p.rate);
      const qty = toNumberOrNull(row.qty);
      const computed = amount ?? (rate !== null && qty !== null ? rate * qty : 0);
      subtotals[idx] += computed || 0;
    });
  });

  const discount = subtotals.map((s) => s * discountRate);
  const afterDiscount = subtotals.map((s, idx) => s - discount[idx]);
  const gst = afterDiscount.map((s) => s * gstRate);
  const total = afterDiscount.map((s, idx) => s + gst[idx]);

  return { subtotals, discount, gst, total, discountRate, gstRate };
};

const pickLatestComparison = (rows = []) => {
  const list = normalizeArray(rows);
  if (list.length === 0) return null;
  const score = (row) => {
    const updated = row?.updated_at ?? row?.updatedAt ?? row?.created_at ?? row?.createdAt ?? null;
    const t = updated ? new Date(updated).getTime() : 0;
    return Number.isFinite(t) ? t : 0;
  };
  return [...list].sort((a, b) => score(b) - score(a))[0] || null;
};

const getPricelistRows = (comparison) =>
  parseArrayLike(
    comparison?.pricelist ?? comparison?.price_list ?? comparison?.priceList ?? comparison?.items,
    []
  );

const getUniqueVendorsFromPricelist = (pricelist) =>
  Array.from(
    new Set(
      (Array.isArray(pricelist) ? pricelist : [])
        .map((row) => String(row?.vendor_name ?? row?.vendorName ?? row?.vendor ?? "").trim())
        .filter(Boolean)
    )
  );

const buildPricelistFromRows = (comparisonRows) =>
  (Array.isArray(comparisonRows) ? comparisonRows : [])
    .flatMap((row) => {
      const qtyRaw = row?.qty ?? "";
      const qty = qtyRaw == null ? null : qtyRaw;
      const unit = String(row?.unit ?? "").trim();
      const hsn = String(row?.hsn_code ?? "").trim();
      const itemDescription = String(row?.material_description ?? row?.item_description ?? "").trim();
      if (!itemDescription) return [];
      const vendorPrices = Array.isArray(row?.vendorPrices) ? row.vendorPrices : [];
      return vendorPrices
        .map((vp) => {
          const vendorName = String(vp?.vendorName ?? "").trim();
          if (!vendorName) return null;
          return {
            vendor_name: vendorName,
            item_description: itemDescription,
            total_qty: qty,
            unit,
            hsn,
            rate: vp?.rate ?? null,
            amount: vp?.amount ?? null,
          };
        })
        .filter(Boolean);
    })
    .filter(Boolean);

const getComparisonIdValue = (comparison) =>
  comparison?.id ?? comparison?.comparison_id ?? comparison?.vendor_comparison_id ?? comparison?.comparisonId ?? null;

const buildComparisonFromPricelist = (comparison) => {
  const pricelist = parseArrayLike(comparison?.pricelist ?? comparison?.price_list ?? comparison?.priceList, []);
  if (!Array.isArray(pricelist) || pricelist.length === 0) {
    return { vendors: [], comparisonRows: [] };
  }

  const vendorSet = new Set();
  const itemMap = new Map();

  const getVendor = (row) => String(row?.vendor_name ?? row?.vendorName ?? row?.vendor ?? "").trim();
  const getDesc = (row) =>
    String(row?.item_description ?? row?.itemDescription ?? row?.description ?? row?.item_name ?? "").trim();
  const getHsn = (row) => String(row?.hsn ?? row?.hsn_code ?? row?.hsnCode ?? "").trim();
  const getUnit = (row) => String(row?.unit ?? row?.uom ?? row?.UOM ?? "").trim();

  pricelist.forEach((row) => {
    const vendorName = getVendor(row);
    const desc = getDesc(row) || "Unnamed Item";
    const hsn = getHsn(row);
    const unit = getUnit(row);
    const qty = toNumberOrNull(row?.total_qty ?? row?.qty ?? row?.quantity) ?? row?.total_qty ?? row?.qty ?? row?.quantity ?? null;
    const rate = toNumberOrNull(row?.rate);
    const amount = toNumberOrNull(row?.amount);

    if (vendorName) vendorSet.add(vendorName);

    const key = `${normalizeText(desc)}||${normalizeText(hsn)}||${normalizeText(unit)}`;
    if (!itemMap.has(key)) {
      itemMap.set(key, {
        material_description: desc,
        hsn_code: hsn,
        unit,
        qtys: [],
        byVendor: new Map(),
      });
    }
    const entry = itemMap.get(key);
    if (qty !== null && qty !== undefined && qty !== "") entry.qtys.push(qty);
    if (vendorName) entry.byVendor.set(vendorName, { vendorName, rate, amount });
  });

  const vendors = Array.from(vendorSet);
  const comparisonRows = Array.from(itemMap.values()).map((item, index) => {
    const qtyNumeric = item.qtys.map((v) => toNumberOrNull(v)).filter((v) => v !== null);
    const qty = qtyNumeric.length > 0 ? Math.max(...qtyNumeric) : item.qtys.find((v) => v !== null && v !== undefined) ?? null;
    return {
      sr_no: index + 1,
      hsn_code: item.hsn_code,
      material_description: item.material_description,
      qty,
      unit: item.unit,
      vendorPrices: vendors.map((vendorName) => {
        const hit = item.byVendor.get(vendorName) || { vendorName, rate: null, amount: null };
        return { vendorName, rate: hit.rate ?? null, amount: hit.amount ?? null };
      }),
    };
  });

  return { vendors, comparisonRows };
};

const buildExportWorkbook = ({ pr, vendors, comparisonRows }) => {
  const companyLine = "Company Name:- Madhuram Enterprises";
  const projectLine = `Project Name:- ${pr?.project_name || ""}`;
  const indentNoLine = `Indent No:- ${pr?.workorder_no || ""}`;
  const indentDateLine = `Indent Date:- ${pr?.date || ""}`;
  const comparisonDateLine = `Comparison Date:- ${todayISO()}`;

  const totals = calculateTotals(comparisonRows, vendors);

  const vendorHeaderRow = ["", "", "", "", ""];
  vendors.forEach((name) => {
    vendorHeaderRow.push(name);
    vendorHeaderRow.push("");
  });

  const columnHeaderRow = ["Sr. No", "HSN Code", "Item Description", "Qty", "UOM"];
  vendors.forEach(() => {
    columnHeaderRow.push("Rate");
    columnHeaderRow.push("Amount");
  });

  const itemRows = comparisonRows.map((row) => {
    const base = [
      row.sr_no,
      row.hsn_code,
      row.material_description,
      row.qty,
      row.unit,
    ];
    vendors.forEach((vendorName) => {
      const p = row.vendorPrices.find((x) => x.vendorName === vendorName) || {};
      base.push(p.rate ?? "");
      base.push(p.amount ?? "");
    });
    return base;
  });

  const subtotalRow = ["", "", "Subtotal", "", ""];
  totals.subtotals.forEach((v) => {
    subtotalRow.push("");
    subtotalRow.push(v);
  });
  const discountRow = ["", "", `Discount (${Math.round(totals.discountRate * 100)}%)`, "", ""];
  totals.discount.forEach((v) => {
    discountRow.push("");
    discountRow.push(v);
  });
  const gstRow = ["", "", `GST (${Math.round(totals.gstRate * 100)}%)`, "", ""];
  totals.gst.forEach((v) => {
    gstRow.push("");
    gstRow.push(v);
  });
  const totalRow = ["", "", "Total Value", "", ""];
  totals.total.forEach((v) => {
    totalRow.push("");
    totalRow.push(v);
  });

  const rows = [
    [companyLine],
    [projectLine],
    [indentNoLine],
    [indentDateLine],
    [comparisonDateLine],
    vendorHeaderRow,
    columnHeaderRow,
    ...itemRows,
    subtotalRow,
    discountRow,
    gstRow,
    totalRow,
  ];

  const ws = XLSX.utils.aoa_to_sheet(rows);

  const mergeRanges = [];
  vendors.forEach((_, idx) => {
    mergeRanges.push({ s: { r: 5, c: 5 + idx * 2 }, e: { r: 5, c: 6 + idx * 2 } });
  });
  ws["!merges"] = mergeRanges;

  const lastCol = 4 + vendors.length * 2;
  ws["!cols"] = [
    { wch: 8 },
    { wch: 12 },
    { wch: 60 },
    { wch: 10 },
    { wch: 10 },
    ...Array.from({ length: vendors.length * 2 }, (_, idx) => ({ wch: idx % 2 === 0 ? 14 : 16 })),
  ];

  const headerFill = { fgColor: { rgb: "1F4E79" } };
  const headerFont = { bold: true, color: { rgb: "FFFFFF" } };
  const border = {
    top: { style: "thin", color: { rgb: "9AA7B2" } },
    bottom: { style: "thin", color: { rgb: "9AA7B2" } },
    left: { style: "thin", color: { rgb: "9AA7B2" } },
    right: { style: "thin", color: { rgb: "9AA7B2" } },
  };
  const centered = { horizontal: "center", vertical: "center", wrapText: true };
  const leftWrap = { horizontal: "left", vertical: "center", wrapText: true };

  const applyCellStyle = (r, c, style) => {
    const ref = XLSX.utils.encode_cell({ r, c });
    if (!ws[ref]) ws[ref] = { t: "s", v: "" };
    ws[ref].s = { ...(ws[ref].s || {}), ...style };
  };

  const range = XLSX.utils.decode_range(ws["!ref"]);
  for (let r = range.s.r; r <= range.e.r; r += 1) {
    for (let c = range.s.c; c <= range.e.c; c += 1) {
      const ref = XLSX.utils.encode_cell({ r, c });
      if (!ws[ref]) continue;
      applyCellStyle(r, c, { border });
    }
  }

  for (let r = 0; r <= 4; r += 1) {
    applyCellStyle(r, 0, { font: { bold: true }, alignment: leftWrap });
  }

  for (let c = 0; c <= lastCol; c += 1) {
    applyCellStyle(5, c, { font: headerFont, fill: headerFill, alignment: centered });
    applyCellStyle(6, c, { font: headerFont, fill: headerFill, alignment: centered });
  }

  for (let r = 7; r < 7 + itemRows.length; r += 1) {
    applyCellStyle(r, 0, { alignment: centered });
    applyCellStyle(r, 1, { alignment: centered });
    applyCellStyle(r, 2, { alignment: leftWrap });
    applyCellStyle(r, 3, { alignment: centered });
    applyCellStyle(r, 4, { alignment: centered });
    for (let c = 5; c <= lastCol; c += 1) {
      applyCellStyle(r, c, { alignment: centered });
    }
  }

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Vendor Comparison");
  return wb;
};

export default function VendorComparisonModule() {
  const { toast } = useToast();
  const resolvedProject = useResolvedProject();
  const API_BASE_URL = useMemo(
    () => String(import.meta.env.VITE_API_BASE_URL || "https://api.madhuram.enterprises").replace(/\/$/, ""),
    []
  );
  const projectId = useMemo(() => {
    const raw = resolvedProject?.projectId;
    if (!raw) return null;
    const n = Number(raw);
    if (!Number.isFinite(n) || !Number.isInteger(n) || n <= 0) return null;
    return n;
  }, [resolvedProject?.projectId]);

  const [searchText, setSearchText] = useState("");
  const [loadingPrs, setLoadingPrs] = useState(false);
  const [prOptions, setPrOptions] = useState([]);
  const [selectedPrId, setSelectedPrId] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);

  const [prItems, setPrItems] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [comparisonRows, setComparisonRows] = useState([]);
  const [headerInfo, setHeaderInfo] = useState({});
  const [step, setStep] = useState("select");
  const [creatingComparison, setCreatingComparison] = useState(false);
  const [createdComparisonId, setCreatedComparisonId] = useState(null);
  const [existingComparison, setExistingComparison] = useState(null);
  const [loadingExisting, setLoadingExisting] = useState(false);
  const [useExisting, setUseExisting] = useState(true);
  const [selectedApprovedVendor, setSelectedApprovedVendor] = useState("");
  const [approvedVendorName, setApprovedVendorName] = useState("");
  const [approvalTargetId, setApprovalTargetId] = useState(null);

  const [loadingPrDetails, setLoadingPrDetails] = useState(false);
  const [parsingExcel, setParsingExcel] = useState(false);

  const fileInputRef = useRef(null);
  const fullPrRef = useRef(null);

  useEffect(() => {
    let cancelled = false;

    const loadPrs = async () => {
      if (!projectId) {
        setPrOptions([]);
        setSelectedPrId("");
        return;
      }

      setLoadingPrs(true);
      try {
        const result = await api.getPrsByProject(projectId);
        const rows = result?.success ? normalizeArray(result.data) : [];
        if (!cancelled) setPrOptions(rows);
      } catch {
        if (!cancelled) setPrOptions([]);
      } finally {
        if (!cancelled) setLoadingPrs(false);
      }
    };

    loadPrs();
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  const filteredPrOptions = useMemo(() => {
    const term = searchText.trim().toLowerCase();
    if (!term) return prOptions;

    return prOptions.filter((row) => {
      const id = row?.pr_id ?? row?.id ?? "";
      const prNo = row?.pr_no ?? row?.pr_number ?? "";
      const vendor = row?.vendor_name ?? row?.vendor ?? "";
      const title = row?.title ?? row?.subject ?? "";
      const projectName = row?.project_name ?? "";
      const hay = [id, prNo, vendor, title, projectName].map((x) => String(x ?? "").toLowerCase());
      return hay.some((value) => value.includes(term));
    });
  }, [prOptions, searchText]);

  const selectedPr = useMemo(() => {
    if (!selectedPrId) return null;
    return prOptions.find((row) => String(row?.pr_id ?? row?.id ?? "") === selectedPrId) || null;
  }, [prOptions, selectedPrId]);

  useEffect(() => {
    let cancelled = false;

    const loadFullPr = async () => {
      if (!selectedPrId) {
        fullPrRef.current = null;
        setPrItems([]);
        setHeaderInfo({});
        setVendors([]);
        setComparisonRows([]);
        setStep("select");
        setExistingComparison(null);
        setUseExisting(true);
        setSelectedApprovedVendor("");
        setApprovedVendorName("");
        setApprovalTargetId(null);
        return;
      }

      setLoadingPrDetails(true);
      try {
        const result = await api.getPrById(selectedPrId);
        if (!result?.success) {
          throw new Error(result?.error || "Failed to load PR");
        }
        const pr = result?.data || null;
        fullPrRef.current = pr;
        const items = normalizeArray(pr?.items);
        if (!cancelled) {
          setPrItems(items);
          setHeaderInfo((prev) => ({
            ...prev,
            project_name: pr?.project_name ?? prev.project_name,
            indent_no: pr?.workorder_no ?? prev.indent_no,
            indent_date: pr?.date ?? prev.indent_date,
          }));
          toast({ title: "PR loaded", description: `Loaded ${items.length} items.` });
        }

        const prNoRaw = pr?.pr_no ?? pr?.pr_number ?? pr?.prNo ?? selectedPr?.pr_no ?? selectedPr?.pr_number ?? null;
        const prNo = prNoRaw != null && prNoRaw !== "" ? Number(prNoRaw) : null;
        if (!cancelled && projectId && Number.isFinite(prNo)) {
          setLoadingExisting(true);
          try {
            const existingResult = await api.listVendorComparisons({ project_id: projectId, pr_no: prNo });
            const existingRows = existingResult?.success ? parseArrayLike(existingResult.data, []) : [];
            const list = normalizeArray(existingRows);
            const score = (row) => {
              const updated = row?.updated_at ?? row?.updatedAt ?? row?.created_at ?? row?.createdAt ?? null;
              const t = updated ? new Date(updated).getTime() : 0;
              return Number.isFinite(t) ? t : 0;
            };
            const sorted = [...list].sort((a, b) => score(b) - score(a));

            let approvedComparison = null;
            let approvedName = "";
            let rawComparison = null;

            for (const row of sorted) {
              let data = row;
              let pricelist = getPricelistRows(data);
              if (pricelist.length === 0) {
                const id = getComparisonIdValue(data);
                if (id != null && id !== "") {
                  try {
                    const detail = await api.getVendorComparisonById(id);
                    if (detail?.success) data = detail.data || data;
                    pricelist = getPricelistRows(data);
                  } catch {
                    // ignore
                  }
                }
              }
              if (!Array.isArray(pricelist) || pricelist.length === 0) continue;
              const unique = getUniqueVendorsFromPricelist(pricelist);
              if (unique.length === 1 && !approvedComparison) {
                approvedComparison = data;
                approvedName = unique[0] || "";
              } else if (unique.length > 1 && !rawComparison) {
                rawComparison = data;
              }
              if (approvedComparison && rawComparison) break;
            }

            if (approvedComparison && approvedName) {
              const targetId = getComparisonIdValue(approvedComparison);
              setApprovalTargetId(targetId != null ? String(targetId) : null);
              setApprovedVendorName(approvedName);
              setSelectedApprovedVendor(approvedName);
              setUseExisting(true);

              const tableComparison = rawComparison || approvedComparison;
              setExistingComparison(tableComparison);

              const built = buildComparisonFromPricelist(tableComparison);
              setVendors(built.vendors);
              setComparisonRows(built.comparisonRows);
              setHeaderInfo((prev) => ({ ...prev, comparison_date: todayISO() }));
              setCreatedComparisonId(targetId != null ? String(targetId) : null);
              setStep("preview");
              setSelectedFile(null);
            } else {
              setExistingComparison(null);
              setUseExisting(false);
              setApprovedVendorName("");
              setApprovalTargetId(null);
              setSelectedApprovedVendor("");
              setVendors([]);
              setComparisonRows([]);
              setCreatedComparisonId(null);
              setStep("select");
              setSelectedFile(null);
            }
          } catch {
            setExistingComparison(null);
          } finally {
            setLoadingExisting(false);
          }
        } else {
          if (!cancelled) setExistingComparison(null);
        }
      } catch (e) {
        if (!cancelled) {
          fullPrRef.current = null;
          setPrItems([]);
          setStep("select");
          setExistingComparison(null);
          setSelectedApprovedVendor("");
          setApprovedVendorName("");
          setApprovalTargetId(null);
          setVendors([]);
          setComparisonRows([]);
          setCreatedComparisonId(null);
          toast({
            title: "Failed to load PR",
            description: e?.message || "Could not fetch PR details.",
            variant: "destructive",
          });
        }
      } finally {
        if (!cancelled) setLoadingPrDetails(false);
      }
    };

    loadFullPr();
    return () => {
      cancelled = true;
    };
  }, [projectId, selectedPr, selectedPrId, toast]);

  useEffect(() => {
    if (!existingComparison) return;
    if (!useExisting) return;
    if (!approvalTargetId) return;
    const built = buildComparisonFromPricelist(existingComparison);
    setVendors(built.vendors);
    setComparisonRows(built.comparisonRows);
    setHeaderInfo((prev) => ({ ...prev, comparison_date: todayISO() }));
    setCreatedComparisonId(
      String(
        existingComparison?.id ??
          existingComparison?.comparison_id ??
          existingComparison?.vendor_comparison_id ??
          existingComparison?.comparisonId ??
          ""
      ) || null
    );
    const unique = getUniqueVendorsFromPricelist(getPricelistRows(existingComparison));
    setSelectedApprovedVendor(unique.length === 1 ? unique[0] : "");
    setSelectedFile(null);
    setStep("preview");
  }, [approvalTargetId, existingComparison, useExisting]);

  useEffect(() => {
    if (useExisting) return;
    if (!existingComparison) return;
    setVendors([]);
    setComparisonRows([]);
    setSelectedFile(null);
    setCreatedComparisonId(null);
    setStep("select");
  }, [existingComparison, useExisting]);

  const handlePickFile = () => {
    if (!fileInputRef.current) return;
    fileInputRef.current.click();
  };

  const clearFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setVendors([]);
    setComparisonRows([]);
    setStep("select");
    setCreatedComparisonId(null);
    setSelectedApprovedVendor("");
    if (existingComparison && useExisting) setUseExisting(false);
  };

  const disableUpload = Boolean(approvalTargetId && useExisting);

  const parseSelectedExcel = async (file) => {
    if (!file) return;
    if (!selectedPrId) {
      toast({ title: "Select PR first", description: "Please select a PR before uploading.", variant: "destructive" });
      return;
    }
    if (disableUpload) {
      toast({
        title: "Existing comparison found",
        description: "This PR already has a vendor comparison. Click “Upload new instead” to upload a new sheet.",
        variant: "destructive",
      });
      return;
    }
    if (!fullPrRef.current) {
      toast({ title: "PR not ready", description: "PR details are still loading.", variant: "destructive" });
      return;
    }

    const name = String(file.name || "").toLowerCase();
    const isExcel = name.endsWith(".xlsx") || name.endsWith(".xls") || name.endsWith(".csv");
    const isPdf = name.endsWith(".pdf");
    if (isPdf) {
      toast({ title: "PDF not supported", description: "Please upload the vendor comparison Excel file.", variant: "destructive" });
      return;
    }
    if (!isExcel) {
      toast({ title: "Unsupported file", description: "Upload .xlsx / .xls / .csv", variant: "destructive" });
      return;
    }

    setParsingExcel(true);
    try {
      const parsed = await parseVendorComparisonExcel(file);
      const merged = mergeWithPrItems(parsed.rows, parsed.vendors, fullPrRef.current?.items);
      setSelectedFile(file);
      setVendors(parsed.vendors);
      setComparisonRows(merged);
      setHeaderInfo((prev) => ({
        ...prev,
        excel_company: parsed.headerBlock.company,
        excel_project: parsed.headerBlock.project,
        excel_indent_no: parsed.headerBlock.indentNo,
        excel_indent_date: parsed.headerBlock.indentDate,
        excel_comparison_date: parsed.headerBlock.comparisonDate,
        comparison_date: todayISO(),
      }));
      setCreatedComparisonId(null);
      setStep("preview");
      toast({ title: "Excel parsed", description: `Vendors: ${parsed.vendors.length}, Items: ${merged.length}` });
    } catch (e) {
      toast({ title: "Parse failed", description: e?.message || "Could not parse Excel.", variant: "destructive" });
      setVendors([]);
      setComparisonRows([]);
      setStep("select");
    } finally {
      setParsingExcel(false);
    }
  };

  const handleFileChange = (event) => {
    const file = event.target.files?.[0] ?? null;
    if (!file) return;
    parseSelectedExcel(file);
  };

  const totals = useMemo(() => calculateTotals(comparisonRows, vendors), [comparisonRows, vendors]);

  const totalValueExtremes = useMemo(() => {
    const values = Array.isArray(totals?.total) ? totals.total : [];
    const numeric = values
      .map((v, idx) => ({ idx, value: toNumberOrNull(v) }))
      .filter((entry) => entry.value !== null);
    if (numeric.length === 0) return { minIdx: -1, maxIdx: -1 };
    numeric.sort((a, b) => a.value - b.value);
    return { minIdx: numeric[0].idx, maxIdx: numeric[numeric.length - 1].idx };
  }, [totals]);

  const handleDownloadExcel = () => {
    const pr = fullPrRef.current || selectedPr || {};
    if (!pr || vendors.length === 0 || comparisonRows.length === 0) {
      toast({ title: "Nothing to export", description: "Select PR and upload Excel first.", variant: "destructive" });
      return;
    }
    try {
      const wb = buildExportWorkbook({ pr, vendors, comparisonRows });
      const fileName = `Vendor_Comparison_${pr?.workorder_no || pr?.pr_id || "export"}_${todayISO()}.xlsx`;
      XLSX.writeFile(wb, fileName, { bookType: "xlsx", compression: true, cellStyles: true });
      toast({ title: "Downloaded", description: fileName });
    } catch (e) {
      toast({ title: "Export failed", description: e?.message || "Could not generate Excel.", variant: "destructive" });
    }
  };

  const handleCreateComparison = async () => {
    if (creatingComparison) return;
    if (disableUpload) {
      toast({ title: "Use Save Approval", description: "This PR already has a vendor comparison record.", variant: "destructive" });
      return;
    }
    if (!selectedApprovedVendor) {
      toast({ title: "Select vendor", description: "Pick the approved vendor before saving.", variant: "destructive" });
      return;
    }
    if (!selectedFile) {
      toast({ title: "No file", description: "Upload the vendor comparison Excel first.", variant: "destructive" });
      return;
    }
    if (!projectId) {
      toast({ title: "No project", description: "Project is required to create a comparison record.", variant: "destructive" });
      return;
    }

    setCreatingComparison(true);
    try {
      const uploadResult = await api.uploadVendorComparisonFiles([selectedFile]);
      if (!uploadResult?.success) {
        toast({ title: "Upload failed", description: uploadResult?.error || "Unable to upload file.", variant: "destructive" });
        return;
      }
      const uploadedFiles = Array.isArray(uploadResult.data) ? uploadResult.data : Array.isArray(uploadResult.data?.data) ? uploadResult.data.data : [];
      const primary = uploadedFiles[0] || null;
      const fileUrl = primary?.file_url || primary?.url || "";
      const fileName = primary?.file_name || primary?.name || selectedFile?.name || "";
      if (!fileUrl) {
        toast({ title: "Upload error", description: "Server did not return file_url.", variant: "destructive" });
        return;
      }

      const fullPricelist = buildPricelistFromRows(comparisonRows);
      const pricelist = fullPricelist.filter((row) => String(row?.vendor_name || "").trim() === selectedApprovedVendor);
      if (pricelist.length === 0) {
        toast({ title: "No items", description: "No items found for the selected vendor.", variant: "destructive" });
        return;
      }

      const prForPayload = fullPrRef.current || selectedPr || {};
      const prNoForPayload = prForPayload?.pr_no ?? prForPayload?.pr_number ?? prForPayload?.prNo ?? null;
      const prNameForPayload = prForPayload?.project_name ?? prForPayload?.pr_name ?? prForPayload?.name ?? null;
      const prNoNumeric = (() => {
        if (prNoForPayload == null || prNoForPayload === "") return null;
        const n = Number(prNoForPayload);
        return Number.isFinite(n) ? n : null;
      })();

      const createResult = await api.createVendorComparison({
        project_id: Number(projectId),
        // Backend expects `pr_no` (PR number). Some environments used PR id here by mistake.
        pr_no: prNoNumeric != null ? prNoNumeric : selectedPrId ? Number(selectedPrId) : null,
        pr_name: prNameForPayload ? String(prNameForPayload) : undefined,
        pricelist,
        upload_document: [
          {
            file_name: fileName,
            file_url: fileUrl,
          },
        ],
      });
      if (!createResult?.success) {
        toast({ title: "Create failed", description: createResult?.error || "Unable to create vendor comparison.", variant: "destructive" });
        return;
      }

      const created = createResult.data || {};
      const id = created?.id ?? created?.vendor_comparison_id ?? created?.comparison_id ?? created?.comparisonId ?? null;
      setCreatedComparisonId(id != null ? String(id) : null);
      setApprovalTargetId(id != null ? String(id) : null);
      setApprovedVendorName(selectedApprovedVendor);
      setUseExisting(true);
      toast({ title: "Created", description: id != null ? `Comparison ID: ${id}` : "Vendor comparison record created." });
    } catch (e) {
      toast({ title: "Create failed", description: e?.message || "Unable to create vendor comparison.", variant: "destructive" });
    } finally {
      setCreatingComparison(false);
    }
  };

  const handleSaveApproval = async () => {
    if (creatingComparison) return;
    if (!disableUpload) {
      toast({ title: "Create first", description: "No existing vendor comparison to update for this PR.", variant: "destructive" });
      return;
    }
    if (!approvalTargetId) {
      toast({ title: "Missing comparison id", description: "Could not determine comparison id for update.", variant: "destructive" });
      return;
    }
    if (!selectedApprovedVendor) {
      toast({ title: "Select vendor", description: "Pick the approved vendor before saving.", variant: "destructive" });
      return;
    }

    setCreatingComparison(true);
    try {
      const fullPricelist = buildPricelistFromRows(comparisonRows);
      const pricelist = fullPricelist.filter((row) => String(row?.vendor_name || "").trim() === selectedApprovedVendor);
      if (pricelist.length === 0) {
        toast({ title: "No items", description: "No items found for the selected vendor.", variant: "destructive" });
        return;
      }
      const result = await api.updateVendorComparison(approvalTargetId, { pricelist });
      if (!result?.success) {
        toast({ title: "Save failed", description: result?.error || "Unable to save approval.", variant: "destructive" });
        return;
      }
      setApprovedVendorName(selectedApprovedVendor);
      toast({ title: "Saved", description: `Approved vendor saved: ${selectedApprovedVendor}` });
    } catch (e) {
      toast({ title: "Save failed", description: e?.message || "Unable to save approval.", variant: "destructive" });
    } finally {
      setCreatingComparison(false);
    }
  };

  const lowestRateByRow = useMemo(() => {
    const map = new Map();
    comparisonRows.forEach((row) => {
      const rates = row.vendorPrices.map((p) => toNumberOrNull(p.rate)).filter((v) => v !== null);
      const min = rates.length > 0 ? Math.min(...rates) : null;
      map.set(row.sr_no, min);
    });
    return map;
  }, [comparisonRows]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Vendor Comparison</h1>
          <p className="text-muted-foreground mt-2">Select a PR, upload vendor comparison Excel, preview, and download.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Search</CardTitle>
          <CardDescription>Search purchase requests by PR no, vendor, title, or project.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-muted-foreground" />
            <Input value={searchText} onChange={(event) => setSearchText(event.target.value)} className="pl-9" placeholder="Search PRs..." />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Purchase Request</CardTitle>
          <CardDescription>Pick a PR first, then upload an Excel/PDF for comparison.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>PR</Label>
              <Select
                value={selectedPrId || undefined}
                onValueChange={(value) => setSelectedPrId(value)}
                disabled={!projectId || loadingPrs}
              >
                <SelectTrigger>
                  <SelectValue placeholder={!projectId ? "Select project first" : loadingPrs ? "Loading PRs..." : "Select PR"} />
                </SelectTrigger>
                <SelectContent>
                  {loadingPrs ? (
                    <SelectItem value="__loading" disabled>
                      Loading...
                    </SelectItem>
                  ) : null}
                  {!loadingPrs && filteredPrOptions.length === 0 ? (
                    <SelectItem value="__empty" disabled>
                      No PRs found.
                    </SelectItem>
                  ) : null}
                  {filteredPrOptions.map((row) => {
                    const id = row?.pr_id ?? row?.id;
                    const prNo = row?.pr_no ?? row?.pr_number ?? "";
                    const label = prNo ? `${id} - ${prNo}` : `${id}`;
                    if (id == null) return null;
                    return (
                      <SelectItem key={`vendor-comp-pr-${id}`} value={String(id)}>
                        {label}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              {loadingPrDetails ? (
                <div className="text-xs text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading PR details...
                </div>
              ) : null}
              {loadingExisting ? (
                <div className="text-xs text-muted-foreground flex items-center gap-2">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" /> Checking existing vendor comparison...
                </div>
              ) : null}
              {!loadingExisting && selectedPrId && approvalTargetId && useExisting ? (
                <div className="rounded-md border bg-emerald-50/60 p-3 text-xs text-emerald-900">
                  <div className="font-medium">✓ Approved: {approvedVendorName || "-"}</div>
                  <div className="mt-1 text-emerald-900/80">Approval record: {approvalTargetId}</div>
                </div>
              ) : null}
            </div>

            {!disableUpload ? (
            <div className="space-y-2">
              <Label>Upload (Excel/PDF)</Label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input ref={fileInputRef} type="file" accept={ACCEPTED_UPLOAD_TYPES} className="hidden" onChange={handleFileChange} />
                <Button
                  type="button"
                  variant="outline"
                  onClick={handlePickFile}
                  className="w-full sm:w-auto"
                  disabled={!selectedPrId || loadingPrDetails || parsingExcel || disableUpload}
                >
                  {parsingExcel ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />} Choose File
                </Button>
                <Button type="button" variant="ghost" onClick={clearFile} className="w-full sm:w-auto" disabled={!selectedFile && step !== "preview"}>
                  Remove
                </Button>
              </div>
              <div className="text-xs text-muted-foreground">
                Accepted: PDF / Excel / CSV. {selectedFile ? `Selected: ${selectedFile.name}` : ""}
              </div>
            </div>
            ) : null}
          </div>

          {selectedPr ? (
            <div className="rounded-lg border p-4 text-sm">
              <div className="font-medium">Selected PR</div>
              <div className="mt-2 grid gap-1 text-muted-foreground">
                <div>PR ID: {selectedPr?.pr_id ?? selectedPr?.id ?? "-"}</div>
                <div>PR No: {selectedPr?.pr_no ?? selectedPr?.pr_number ?? "-"}</div>
                <div>Vendor: {selectedPr?.vendor_name ?? selectedPr?.vendor ?? "-"}</div>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {step === "preview" ? (
        <Card>
          <CardHeader>
            <CardTitle>Preview</CardTitle>
            <CardDescription>
              Vendors: {vendors.length} | Items: {comparisonRows.length} | PR Items: {prItems.length} | GST:{" "}
              {Math.round(totals.gstRate * 100)}% | Discount: {Math.round(totals.discountRate * 100)}%
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {approvedVendorName ? (
              <div className="flex items-center">
                <span className="inline-flex items-center rounded-md bg-emerald-600 px-3 py-1 text-sm font-medium text-white">
                  ✓ Approved: {approvedVendorName}
                </span>
              </div>
            ) : null}

            <div className="grid gap-3 rounded-lg border p-4 text-sm md:grid-cols-2">
              <div className="space-y-1">
                <div className="font-medium">Header</div>
                <div className="text-muted-foreground">Company: Madhuram Enterprises</div>
                <div className="text-muted-foreground">Project: {headerInfo.project_name || "-"}</div>
                <div className="text-muted-foreground">Indent No: {headerInfo.indent_no || "-"}</div>
                <div className="text-muted-foreground">Indent Date: {headerInfo.indent_date || "-"}</div>
                <div className="text-muted-foreground">Comparison Date: {headerInfo.comparison_date || todayISO()}</div>
              </div>
              <div className="space-y-1">
                <div className="font-medium">From Excel</div>
                <div className="text-muted-foreground">Company: {headerInfo.excel_company || "-"}</div>
                <div className="text-muted-foreground">Project: {headerInfo.excel_project || "-"}</div>
                <div className="text-muted-foreground">Indent No: {headerInfo.excel_indent_no || "-"}</div>
                <div className="text-muted-foreground">Indent Date: {headerInfo.excel_indent_date || "-"}</div>
                <div className="text-muted-foreground">Comparison Date: {headerInfo.excel_comparison_date || "-"}</div>
              </div>
            </div>

            <div className="overflow-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">Sr. No</TableHead>
                    <TableHead className="whitespace-nowrap">HSN Code</TableHead>
                    <TableHead className="min-w-[320px]">Item Description</TableHead>
                    <TableHead className="whitespace-nowrap text-right">Qty</TableHead>
                    <TableHead className="whitespace-nowrap">UOM</TableHead>
                    {vendors.map((vendorName) => (
                      <React.Fragment key={`vendor-head-${vendorName}`}>
                        <TableHead className="whitespace-nowrap text-right">{vendorName} Rate</TableHead>
                        <TableHead className="whitespace-nowrap text-right">{vendorName} Amount</TableHead>
                      </React.Fragment>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {comparisonRows.map((row) => {
                    const lowestRate = lowestRateByRow.get(row.sr_no) ?? null;
                    return (
                      <TableRow key={`comp-row-${row.sr_no}`}>
                        <TableCell className="whitespace-nowrap">{row.sr_no}</TableCell>
                        <TableCell className="whitespace-nowrap">{row.hsn_code || "-"}</TableCell>
                        <TableCell className="min-w-[320px]">{row.material_description}</TableCell>
                        <TableCell className="whitespace-nowrap text-right">{row.qty ?? "-"}</TableCell>
                        <TableCell className="whitespace-nowrap">{row.unit || "-"}</TableCell>
                        {row.vendorPrices.map((p) => {
                          const rate = toNumberOrNull(p.rate);
                          const isLowest = lowestRate !== null && rate !== null && rate === lowestRate;
                          return (
                            <React.Fragment key={`cell-${row.sr_no}-${p.vendorName}`}>
                              <TableCell className={`whitespace-nowrap text-right ${isLowest ? "bg-green-50 text-green-800 font-semibold" : ""}`}>
                                {rate === null ? "-" : formatMoney(rate)}
                              </TableCell>
                              <TableCell className="whitespace-nowrap text-right">{p.amount === null ? "-" : formatMoney(p.amount)}</TableCell>
                            </React.Fragment>
                          );
                        })}
                      </TableRow>
                    );
                  })}

                  <TableRow>
                    <TableCell colSpan={5} className="font-medium">
                      Subtotal
                    </TableCell>
                    {totals.subtotals.map((value, idx) => (
                      <React.Fragment key={`subtotal-${idx}`}>
                        <TableCell className="text-right">-</TableCell>
                        <TableCell className="text-right font-medium">{formatMoney(value)}</TableCell>
                      </React.Fragment>
                    ))}
                  </TableRow>
                  <TableRow>
                    <TableCell colSpan={5} className="font-medium">
                      Discount ({Math.round(totals.discountRate * 100)}%)
                    </TableCell>
                    {totals.discount.map((value, idx) => (
                      <React.Fragment key={`discount-${idx}`}>
                        <TableCell className="text-right">-</TableCell>
                        <TableCell className="text-right font-medium">{formatMoney(value)}</TableCell>
                      </React.Fragment>
                    ))}
                  </TableRow>
                  <TableRow>
                    <TableCell colSpan={5} className="font-medium">
                      GST ({Math.round(totals.gstRate * 100)}%)
                    </TableCell>
                    {totals.gst.map((value, idx) => (
                      <React.Fragment key={`gst-${idx}`}>
                        <TableCell className="text-right">-</TableCell>
                        <TableCell className="text-right font-medium">{formatMoney(value)}</TableCell>
                      </React.Fragment>
                    ))}
                  </TableRow>
                  <TableRow>
                    <TableCell colSpan={5} className="font-semibold">
                      Total Value
                    </TableCell>
                    {totals.total.map((value, idx) => (
                      <React.Fragment key={`total-${idx}`}>
                        <TableCell className="text-right">-</TableCell>
                        <TableCell
                          className={`text-right font-semibold ${
                            idx === totalValueExtremes.minIdx
                              ? "bg-emerald-100 text-emerald-900"
                              : idx === totalValueExtremes.maxIdx
                                ? "bg-rose-100 text-rose-900"
                                : ""
                          }`}
                        >
                          {formatMoney(value)}
                        </TableCell>
                      </React.Fragment>
                    ))}
                  </TableRow>
                </TableBody>
              </Table>
            </div>

            <div className="rounded-lg border p-4 text-sm">
              <div className="font-medium">Approve Vendor</div>
              <div className="text-muted-foreground mt-1">
                Selecting a vendor and clicking “Save Approval” saves a vendor comparison record with only that vendor’s items in `pricelist`.
                Any record that still contains multiple vendors is treated as a draft.
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {vendors.length === 0 ? (
                  <div className="text-muted-foreground">No vendors found in this sheet.</div>
                ) : (
                  vendors.map((vendorName) => {
                    const isSelected = selectedApprovedVendor === vendorName;
                    return (
                      <Button
                        key={`approve-${vendorName}`}
                        type="button"
                        variant={isSelected ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedApprovedVendor(vendorName)}
                      >
                        {vendorName}
                      </Button>
                    );
                  })
                )}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 w-full sm:justify-end">
              <Button type="button" variant="outline" onClick={clearFile} className="w-full sm:w-auto">
                Clear
              </Button>
              {!disableUpload ? (
                <Button type="button" onClick={handleCreateComparison} className="w-full sm:w-auto" disabled={creatingComparison}>
                  {creatingComparison ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Save Approval
                </Button>
              ) : (
                <>
                  <Button type="button" onClick={handleSaveApproval} className="w-full sm:w-auto" disabled={creatingComparison}>
                    {creatingComparison ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Save Approval
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setUseExisting(false);
                      setExistingComparison(existingComparison);
                      setVendors([]);
                      setComparisonRows([]);
                      setCreatedComparisonId(null);
                      setSelectedApprovedVendor("");
                      setStep("select");
                    }}
                    className="w-full sm:w-auto"
                  >
                    Upload new instead
                  </Button>
                </>
              )}
              <Button type="button" onClick={handleDownloadExcel} className="w-full sm:w-auto">
                Download Excel
              </Button>
            </div>

            {createdComparisonId ? (
              <div className="rounded-lg border bg-muted/30 p-4 text-sm">
                <div className="font-medium">{disableUpload ? "Loaded" : "Created"}</div>
                <div className="mt-1 text-muted-foreground">
                  Vendor comparison record ID: {createdComparisonId}
                  {disableUpload ? " (existing)" : ""}
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
